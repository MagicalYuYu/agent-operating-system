from .util import DataManager, check_permission, get_group_data_path
from typing import Any
from .data.loader import DataLoader
from .core import (
    DiceRoller, Character, AbilityScores, CharacterFactory,
    SkillChecker, CombatSystem, SpellDatabase,
    ClassDatabase, RaceDatabase, BackgroundDatabase,
    CharacterCreator, CreationStep,
    TownSystem, MenuSystem, NPCDatabase,
    DailySystem, BackpackSystem, ShopSystem, PartySystem,
    BattleArena, Difficulty, WATERDEEP_ARENA_MONSTERS, ARENA_INSTANCE,
    CombatAdapter, MONSTER_TEMPLATES
)
from .core.full_combat_system import (
    CombatContext, CombatFighter, CombatPhase, CombatCommand,
    CombatManager, COMBAT_MANAGER
)
from astrbot.core.utils.astrbot_path import get_astrbot_data_path


class DNDZeroPlugin(Star):
    """DND/Zero TRPG 插件主类"""

    def __init__(self, context: Context, config: AstrBotConfig):
        super().__init__(context)
        self.context = context
        self.config = config
        plugin_data_path = Path(get_astrbot_data_path()) / "plugin_data" / "astrbot_plugin_dnd_zero"
        plugin_data_path.mkdir(parents=True, exist_ok=True)
        self.plugin_data_dir = plugin_data_path
        self.backup_dir = self.plugin_data_dir / "backup"
        self.backup_dir.mkdir(parents=True, exist_ok=True)
        self.data_manager = DataManager(self.plugin_data_dir)
        self.data_loader = DataLoader(self.plugin_data_dir)
        self.skill_checker = SkillChecker()
        self.combat_system = CombatSystem()
        self.character_creator = CharacterCreator()
        self.characters: Dict[str, Character] = {}
        
        # 战斗训练场
        self.battle_arena = ARENA_INSTANCE
        
        # 战斗场状态缓存（用于恢复角色状态）
        self.arena_char_states: Dict[str, Dict] = {}
        
        # 全局战斗管理器
        self.combat_manager = COMBAT_MANAGER
        
        # 管理员模式状态
        self.admin_modes: Dict[str, Dict] = {}

        # 城镇和菜单系统初始化
        self.town_system = TownSystem()
        self.npc_database = NPCDatabase()
        self.menu_system = MenuSystem(self.town_system, self.npc_database)
        self.daily_system = DailySystem()
        self.backpack_system = BackpackSystem()
        self.shop_system = ShopSystem()
        self.party_system = PartySystem()
        
        # 属性映射常量
        self.ABILITY_CN_TO_EN = {
            "力量": "strength", "敏捷": "dexterity", "体质": "constitution",
            "智力": "intelligence", "感知": "wisdom", "魅力": "charisma"
        }
        self.ABILITY_EN_TO_CN = {v: k for k, v in self.ABILITY_CN_TO_EN.items()}
        self.ABILITY_EMOJI = {
            "strength": "💪", "dexterity": "🏃", "constitution": "❤️",
            "intelligence": "📚", "wisdom": "👁", "charisma": "✨"
        }
        
        # 职业预设属性
        self.CLASS_PRESETS = {
            "战士": {"strength": 15, "constitution": 14, "dexterity": 13, 
                    "intelligence": 10, "wisdom": 10, "charisma": 8},
            "法师": {"intelligence": 15, "dexterity": 14, "constitution": 13, 
                    "charisma": 10, "wisdom": 10, "strength": 8},
            "盗贼": {"dexterity": 15, "intelligence": 14, "charisma": 13, 
                    "constitution": 10, "wisdom": 10, "strength": 8},
            "牧师": {"wisdom": 15, "charisma": 14, "constitution": 13, 
                    "intelligence": 10, "dexterity": 10, "strength": 8},
            "游侠": {"dexterity": 15, "wisdom": 14, "constitution": 13, 
                    "intelligence": 10, "charisma": 10, "strength": 8},
            "圣武士": {"strength": 15, "charisma": 14, "constitution": 13, 
                    "wisdom": 10, "intelligence": 10, "dexterity": 8},
            "吟游诗人": {"charisma": 15, "dexterity": 14, "constitution": 13, 
                    "wisdom": 10, "intelligence": 10, "strength": 8},
            "野蛮人": {"strength": 15, "constitution": 14, "dexterity": 13, 
                    "wisdom": 10, "charisma": 10, "intelligence": 8},
            "僧侣": {"dexterity": 15, "strength": 14, "constitution": 13, 
                    "wisdom": 10, "intelligence": 10, "charisma": 8},
            "德鲁伊": {"wisdom": 15, "intelligence": 14, "constitution": 13, 
                    "dexterity": 10, "charisma": 10, "strength": 8},
            "术士": {"charisma": 15, "constitution": 14, "dexterity": 13, 
                    "wisdom": 10, "intelligence": 10, "strength": 8},
            "奇械师": {"intelligence": 15, "constitution": 14, "dexterity": 13, 
                    "wisdom": 10, "charisma": 10, "strength": 8}
        }
        
        # 职业攻击类型
        self.CLASS_ATTACK_TYPES = {
            "战士": {"damage_dice": "1d8", "attack_range": "melee", "primary_ability": "strength"},
            "法师": {"damage_dice": "1d10", "attack_range": "ranged", "primary_ability": "intelligence"},
            "盗贼": {"damage_dice": "1d8", "attack_range": "melee", "primary_ability": "dexterity"},
            "牧师": {"damage_dice": "1d8", "attack_range": "melee", "primary_ability": "wisdom"},
            "游侠": {"damage_dice": "1d8", "attack_range": "ranged", "primary_ability": "dexterity"},
            "圣武士": {"damage_dice": "1d8", "attack_range": "melee", "primary_ability": "strength"},
            "吟游诗人": {"damage_dice": "1d8", "attack_range": "ranged", "primary_ability": "charisma"},
            "野蛮人": {"damage_dice": "1d12", "attack_range": "melee", "primary_ability": "strength"},
            "僧侣": {"damage_dice": "1d8", "attack_range": "melee", "primary_ability": "dexterity"},
            "德鲁伊": {"damage_dice": "1d8", "attack_range": "melee", "primary_ability": "wisdom"},
            "术士": {"damage_dice": "1d6", "attack_range": "ranged", "primary_ability": "charisma"},
            "奇械师": {"damage_dice": "1d8", "attack_range": "ranged", "primary_ability": "intelligence"}
        }
        
        logger.info("DND/Zero 插件初始化完成")
