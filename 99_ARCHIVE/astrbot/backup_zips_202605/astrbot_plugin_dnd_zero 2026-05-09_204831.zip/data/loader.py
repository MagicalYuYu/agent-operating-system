"""
D&D 5e 数据加载器
从 5etools中文站 (https://5e.kiwee.top/) 加载游戏数据
"""
import json
import httpx
from pathlib import Path
from typing import Optional, Dict, List, Any
from datetime import datetime
import asyncio


class DataLoader:
    """D&D 5e 数据加载器"""

    BASE_URL = "https://raw.githubusercontent.com/tjliqy/5etools-mirror-2.github.io/cn2.0/data"

    def __init__(self, cache_dir: Path):
        self.cache_dir = cache_dir / "dnd_data"
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self._memory_cache: Dict[str, Any] = {}

    async def _fetch_json(self, filename: str) -> Dict:
        """从网络获取JSON数据"""
        url = f"{self.BASE_URL}/{filename}"
        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                response = await client.get(url)
                response.raise_for_status()
                return response.json()
        except httpx.HTTPError as e:
            print(f"从网络加载 {filename} 失败: {e}")
            return {}

    def _load_from_cache(self, filename: str) -> Optional[Dict]:
        """从本地缓存加载"""
        cache_file = self.cache_dir / filename
        if cache_file.exists():
            try:
                with open(cache_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except Exception as e:
                print(f"读取缓存 {filename} 失败: {e}")
        return None

    def _save_to_cache(self, filename: str, data: Dict):
        """保存到本地缓存"""
        cache_file = self.cache_dir / filename
        try:
            with open(cache_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"保存缓存 {filename} 失败: {e}")

    async def load_data(
        self,
        filename: str,
        use_cache: bool = True,
        force_refresh: bool = False
    ) -> Dict:
        """加载数据（带缓存）"""
        if filename in self._memory_cache and not force_refresh:
            return self._memory_cache[filename]

        if use_cache and not force_refresh:
            cached_data = self._load_from_cache(filename)
            if cached_data:
                self._memory_cache[filename] = cached_data
                return cached_data

        data = await self._fetch_json(filename)

        if data:
            self._save_to_cache(filename, data)
            self._memory_cache[filename] = data

        return data

    async def get_classes(self) -> List[Dict]:
        """获取职业数据"""
        data = await self.load_data("classes.json")
        return data.get("class", [])

    async def get_races(self) -> List[Dict]:
        """获取种族数据"""
        data = await self.load_data("races.json")
        return data.get("race", [])

    async def get_backgrounds(self) -> List[Dict]:
        """获取背景数据"""
        data = await self.load_data("backgrounds.json")
        return data.get("background", [])

    async def get_feats(self) -> List[Dict]:
        """获取专长数据"""
        data = await self.load_data("feats.json")
        return data.get("feat", [])

    async def get_skills(self) -> List[Dict]:
        """获取技能数据"""
        data = await self.load_data("skills.json")
        return data.get("skill", [])

    async def get_items(self) -> List[Dict]:
        """获取物品数据"""
        data = await self.load_data("items.json")
        return data.get("item", [])

    async def get_spells(self, level: Optional[int] = None) -> List[Dict]:
        """获取法术数据"""
        if level is not None:
            filename = f"spells/spelllist-{level}.json"
            data = await self.load_data(filename)
            return data.get("spell", [])
        else:
            data = await self.load_data("spells.json")
            return data.get("spell", [])

    async def get_monsters(self) -> List[Dict]:
        """获取怪物数据"""
        data = await self.load_data("bestiary/bestiary.json")
        return data.get("monster", [])

    async def get_conditions(self) -> List[Dict]:
        """获取状态条件数据"""
        data = await self.load_data("conditionsdiseases.json")
        return data.get("condition", [])

    def clear_cache(self):
        """清空缓存"""
        self._memory_cache.clear()
        for file in self.cache_dir.glob("*.json"):
            file.unlink()
