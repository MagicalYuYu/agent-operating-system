"""
D&D 5e 战斗系统
回合制战斗流程、攻击、伤害计算
"""
from dataclasses import dataclass, field
from typing import List, Optional
from .dice import DiceRoller, DiceRollResult, AdvantageType
from .character import Character
from .skill import AttackResult


@dataclass
class CombatAction:
    """战斗动作"""
    name: str
    action_type: str
    description: str = ""
    damage_dice: str = ""
    attack_bonus: int = 0
    damage_bonus: int = 0


@dataclass
class CombatTurn:
    """战斗回合"""
    turn_number: int
    character: Character
    actions_taken: List[str] = field(default_factory=list)
    bonus_action_used: bool = False
    reaction_used: bool = False


@dataclass
class DamageResult:
    """伤害结果"""
    base_damage: int
    rolls: List[int]
    modifier: int
    total: int
    is_critical: bool = False
    damage_type: str = "physical"

    def __str__(self) -> str:
        roll_str = "+".join(map(str, self.rolls))
        result = f"💥 伤害: [{roll_str}]"
        if self.modifier != 0:
            result += f" + {self.modifier}"
        result += f" = **{self.total}**"
        if self.is_critical:
            result += " (暴击!)"
        result += f" [{self.damage_type}]"
        return result


@dataclass
class CombatResult:
    """战斗结果"""
    attacker: Character
    defender: Character
    attack_result: AttackResult
    damage_result: Optional[DamageResult]
    hit: bool = False
    critical_hit: bool = False

    def __str__(self) -> str:
        result = f"\n⚔️ **{self.attacker.name}** 攻击 **{self.defender.name}**\n"
        result += f"{str(self.attack_result)}\n"

        if self.hit and self.damage_result:
            result += f"\n{str(self.damage_result)}\n"
            result += f"💔 **{self.defender.name}** 剩余HP: {self.defender.hit_points}/{self.defender.max_hit_points}\n"

        if self.defender.is_unconscious():
            result += f"\n💀 **{self.defender.name}** 陷入昏迷！\n"
        elif self.defender.is_dead():
            result += f"\n☠️ **{self.defender.name}** 死亡！\n"

        return result


@dataclass
class CombatEncounter:
    """战斗遭遇"""
    name: str
    participants: List[Character] = field(default_factory=list)
    current_turn: int = 0
    round_number: int = 1
    initiative_order: List[Character] = field(default_factory=list)
    is_active: bool = False

    def next_turn(self):
        """下一回合"""
        self.current_turn += 1
        if self.current_turn >= len(self.initiative_order):
            self.current_turn = 0
            self.round_number += 1

    def get_current_character(self) -> Optional[Character]:
        """获取当前回合的角色"""
        if self.initiative_order:
            return self.initiative_order[self.current_turn]
        return None


class CombatSystem:
    """D&D 5e 战斗系统"""

    def __init__(self):
        pass

    def calculate_armor_class(self, character: Character) -> int:
        """计算护甲等级"""
        base_ac = 10
        dex_mod = character.abilities.get_modifier("dexterity")

        armor_bonus = 0
        has_armor = False

        for equip in character.equipment:
            if hasattr(equip, 'armor_class') and equip.armor_class > 0:
                armor_bonus += equip.armor_class
                has_armor = True

        if has_armor:
            con_or_dex_mod = dex_mod
            if hasattr(character, 'heavy_armor'):
                con_or_dex_mod = 0
            return base_ac + armor_bonus + con_or_dex_mod
        else:
            return base_ac + dex_mod

    def roll_initiative(self, participants: List[Character]) -> List[tuple]:
        """先攻排序

        Returns:
            List[tuple]: [(角色, 先攻值), ...] 按先攻值降序排列
        """
        initiatives = []
        for character in participants:
            dex_mod = character.abilities.get_modifier("dexterity")
            init_result = DiceRoller.roll_initiative(dex_mod)
            initiatives.append((character, init_result.total))

        return sorted(initiatives, key=lambda x: x[1], reverse=True)

    def process_attack(
        self,
        attacker: Character,
        defender: Character,
        weapon_damage: str = "1d6",
        attack_bonus: int = None,
        advantage_type: AdvantageType = AdvantageType.NONE
    ) -> CombatResult:
        """处理攻击

        Args:
            attacker: 攻击方
            defender: 防御方
            weapon_damage: 武器伤害骰（如 "1d6"）
            attack_bonus: 攻击加值（默认使用角色攻击加值）
            advantage_type: 优势类型

        Returns:
            CombatResult: 战斗结果
        """
        if attack_bonus is None:
            attack_bonus = attacker.get_attack_bonus()

        defender_ac = self.calculate_armor_class(defender)

        attack_result = DiceRoller.roll_attack(attack_bonus, advantage_type)

        hit = False
        critical_hit = False
        damage_result = None

        if attack_result.roll == 20:
            hit = True
            critical_hit = True
        elif attack_result.roll == 1:
            hit = False
        else:
            hit = attack_result.total >= defender_ac

        if hit:
            dice_result = DiceRoller.roll_from_notation(weapon_damage)

            modifier = attacker.abilities.get_modifier("strength")

            if critical_hit:
                crit_rolls = DiceRoller.roll_from_notation(weapon_damage)
                dice_result.total += crit_rolls.total
                dice_result.rolls.extend(crit_rolls.rolls)

            damage_result = DamageResult(
                base_damage=dice_result.total,
                rolls=dice_result.rolls,
                modifier=modifier,
                total=dice_result.total + modifier,
                is_critical=critical_hit,
                damage_type="physical"
            )

            defender.take_damage(damage_result.total)

        return CombatResult(
            attacker=attacker,
            defender=defender,
            attack_result=AttackResult(
                attack_bonus=attack_bonus,
                roll=attack_result.roll,
                total=attack_result.total,
                target_ac=defender_ac,
                hit=hit,
                critical_hit=critical_hit,
                critical_fumble=(attack_result.roll == 1)
            ),
            damage_result=damage_result,
            hit=hit,
            critical_hit=critical_hit
        )

    def process_spell_attack(
        self,
        caster: Character,
        target: Character,
        spell_damage: str,
        spell_save_dc: int = None,
        ability_to_save: str = "dexterity",
        advantage_type: AdvantageType = AdvantageType.NONE
    ) -> CombatResult:
        """处理法术攻击

        Args:
            caster: 施法者
            target: 目标
            spell_damage: 法术伤害（如 "8d6"）
            spell_save_dc: 法术豁免DC
            ability_to_save: 豁免属性
            advantage_type: 优势类型

        Returns:
            CombatResult: 战斗结果
        """
        if spell_save_dc is None:
            spell_save_dc = caster.get_spell_save_dc()

        target_save = DiceRoller.roll_saving_throw(
            target.abilities.get_modifier(ability_to_save),
            advantage_type
        )

        target_ac = self.calculate_armor_class(target)

        attack_bonus = caster.get_spell_attack_bonus()
        attack_result = DiceRoller.roll_attack(attack_bonus, advantage_type)

        hit = attack_result.roll == 20 or (attack_result.roll != 1 and attack_result.total >= target_ac)
        save_failed = target_save.total < spell_save_dc

        damage_result = None
        if hit and save_failed:
            dice_result = DiceRoller.roll_from_notation(spell_damage)
            damage_result = DamageResult(
                base_damage=dice_result.total,
                rolls=dice_result.rolls,
                modifier=0,
                total=dice_result.total,
                damage_type="spell"
            )
            target.take_damage(damage_result.total)

        return CombatResult(
            attacker=caster,
            defender=target,
            attack_result=AttackResult(
                attack_bonus=attack_bonus,
                roll=attack_result.roll,
                total=attack_result.total,
                target_ac=target_ac,
                hit=hit,
                critical_hit=(attack_result.roll == 20),
                critical_fumble=(attack_result.roll == 1)
            ),
            damage_result=damage_result,
            hit=hit
        )

    def apply_condition(self, character: Character, condition: str, duration: int = -1):
        """施加状态"""
        if not hasattr(character, 'conditions'):
            character.conditions = []
        character.conditions.append({
            "name": condition,
            "duration": duration
        })

    def remove_condition(self, character: Character, condition: str):
        """移除状态"""
        if hasattr(character, 'conditions'):
            character.conditions = [
                c for c in character.conditions if c['name'] != condition
            ]

    def check_combat_end(self, encounter: CombatEncounter) -> bool:
        """检查战斗是否结束"""
        alive_count = sum(1 for p in encounter.participants if not p.is_dead())
        return alive_count <= 1

    def get_standard_actions(self) -> List[CombatAction]:
        """获取标准动作列表"""
        return [
            CombatAction("攻击", "action", "进行一次近战或远程攻击"),
            CombatAction("协助", "action", "给予目标优势"),
            CombatAction("撤离", "action", "移动至多等于你的速度"),
            CombatAction("躲藏", "action", "尝试进行隐匿检定"),
            CombatAction("准备", "action", "准备一个动作"),
        ]

    def get_standard_bonus_actions(self) -> List[CombatAction]:
        """获取附赠动作列表"""
        return [
            CombatAction("施法", "bonus_action", "施展一个环阶为戏法的法术"),
            CombatAction("攻击", "bonus_action", "进行一次轻武器攻击"),
            CombatAction("撤退", "bonus_action", "移动half speed"),
        ]
