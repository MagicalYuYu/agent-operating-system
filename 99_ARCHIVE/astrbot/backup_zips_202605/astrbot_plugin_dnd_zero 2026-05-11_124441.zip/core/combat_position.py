"""
D&D/Zero 战斗系统核心
4号位站位系统 + 攻击范围系统
"""
from dataclasses import dataclass, field
from typing import List, Optional, Dict, Tuple
from enum import Enum


class ActionType(Enum):
    """动作类型"""
    STANDARD_ACTION = "action"
    BONUS_ACTION = "bonus_action"
    REACTION = "reaction"
    FREE_ACTION = "free_action"
    MOVEMENT = "movement"


class ConditionType(Enum):
    """状态效果类型"""
    BLINDED = "目盲"
    CHARMED = "魅惑"
    DEAFENED = "耳聋"
    FRIGHTENED = "恐惧"
    GRAPPLED = "擒抱"
    INCAPACITATED = "虚弱"
    INVISIBLE = "隐形"
    PARALYZED = "麻痹"
    PETRIFIED = "石化"
    POISONED = "中毒"
    PRONE = "倒地"
    RESTRAINED = "束缚"
    STUNNED = "震慑"
    UNCONSCIOUS = "昏迷"
    EXHAUSTION = "力竭"


class AttackRange:
    """攻击范围（极简数值版）

    核心设计：只用两个数值定义攻击范围
    - range: 可攻击的位置数量
    - start: 从第几个位置开始（可选，默认1）

    判定逻辑：
        可攻击位置 = [start, start+1, ..., start+range-1]

    示例：
        普通攻击: range=2, start=1 → 可攻击 [1, 2]
        远程攻击: range=4, start=1 → 可攻击 [1, 2, 3, 4]
        突进斩: range=2, start=3 → 可攻击 [3, 4]
    """
    def __init__(self, range: int = 2, start: int = 1):
        self.range = range
        self.start = start

    def can_attack(self, combat_position: int, alive_count: int) -> bool:
        """判断是否可以攻击指定战斗位置"""
        if combat_position > alive_count:
            return False

        return self.start <= combat_position <= self.start + self.range - 1

    def get_attackable_positions(self, alive_count: int) -> List[int]:
        """获取所有可攻击的战斗位置"""
        positions = []
        end_pos = min(self.start + self.range - 1, alive_count)

        for pos in range(self.start, end_pos + 1):
            positions.append(pos)

        return positions

    def __repr__(self):
        return f"AttackRange(range={self.range}, start={self.start})"


MELEE_RANGE = AttackRange(range=2, start=1)
RANGED_RANGE = AttackRange(range=4, start=1)
PIERCE_RANGE = AttackRange(range=2, start=3)


@dataclass
class PositionManager:
    """站位管理器 - 简化版：存活单位压缩"""

    def __init__(self):
        self.ally_positions: Dict[int, Optional['CombatUnit']] = {
            1: None, 2: None, 3: None, 4: None
        }
        self.enemy_positions: Dict[int, Optional['CombatUnit']] = {
            1: None, 2: None, 3: None, 4: None
        }

    def get_alive_units(self, is_ally: bool) -> List['CombatUnit']:
        """获取所有存活单位（按位置排序）"""
        positions = self.ally_positions if is_ally else self.enemy_positions
        alive_units = []

        for pos in [1, 2, 3, 4]:
            unit = positions.get(pos)
            if unit and not unit.is_dead and not unit.is_unconscious:
                alive_units.append(unit)

        return alive_units

    def get_alive_positions(self, is_ally: bool) -> List[int]:
        """获取所有存活单位的位置列表"""
        positions = self.ally_positions if is_ally else self.enemy_positions
        alive_positions = []

        for pos in [1, 2, 3, 4]:
            unit = positions.get(pos)
            if unit and not unit.is_dead and not unit.is_unconscious:
                alive_positions.append(pos)

        return alive_positions

    def get_combat_position(self, actual_position: int, is_ally: bool) -> int:
        """将实际位置转换为战斗位置"""
        alive_positions = self.get_alive_positions(is_ally)

        if not alive_positions:
            return 0

        if actual_position not in alive_positions:
            return 0

        return alive_positions.index(actual_position) + 1

    def get_unit_at(self, position: int, is_ally: bool = None) -> Optional['CombatUnit']:
        """获取指定位置的单位"""
        if is_ally is True:
            return self.ally_positions.get(position)
        elif is_ally is False:
            return self.enemy_positions.get(position)
        else:
            return self.ally_positions.get(position) or self.enemy_positions.get(position)

    def can_attack_position(self, attacker: 'CombatUnit', target_combat_pos: int,
                            attack_range: AttackRange, target_is_ally: bool = False) -> bool:
        """判定是否可以攻击某战斗位置"""
        alive_positions = self.get_alive_positions(target_is_ally)

        if not alive_positions:
            return False

        if target_combat_pos > len(alive_positions):
            return False

        return attack_range.can_attack(target_combat_pos, len(alive_positions))

    def get_unit_at_combat_position(self, combat_pos: int,
                                    is_ally: bool) -> Optional['CombatUnit']:
        """根据战斗位置获取单位"""
        alive_positions = self.get_alive_positions(is_ally)

        if not alive_positions or combat_pos > len(alive_positions):
            return None

        actual_pos = alive_positions[combat_pos - 1]
        return self.get_unit_at(actual_pos, is_ally)

    def get_valid_targets(self, attacker: 'CombatUnit',
                         attack_range: AttackRange,
                         target_is_ally: bool = False) -> List['CombatUnit']:
        """获取有效目标列表"""
        alive_units = self.get_alive_units(target_is_ally)
        valid_targets = []

        for i, unit in enumerate(alive_units):
            combat_pos = i + 1

            if self.can_attack_position(attacker, combat_pos, attack_range, target_is_ally):
                valid_targets.append(unit)

        return valid_targets

    def assign_position(self, unit: 'CombatUnit', position: int,
                       is_ally: bool = None) -> bool:
        """分配单位到指定位置"""
        if position not in [1, 2, 3, 4]:
            return False

        if is_ally is None:
            is_ally = (unit.unit_type == "player")

        unit.position = position
        unit.original_position = position

        if is_ally:
            self.ally_positions[position] = unit
        else:
            self.enemy_positions[position] = unit

        return True

    def swap_positions(self, unit: 'CombatUnit', new_position: int) -> bool:
        """交换位置（可与空位交换）"""
        if new_position not in [1, 2, 3, 4]:
            return False

        if unit.is_dead or unit.is_unconscious:
            return False

        current_position = unit.position
        is_ally = (unit.unit_type == "player")
        occupant = self.get_unit_at(new_position, is_ally)

        if occupant and not occupant.is_dead and not occupant.is_unconscious:
            if occupant.unit_type == unit.unit_type:
                occupant.position = current_position
                if is_ally:
                    self.ally_positions[current_position] = occupant
                else:
                    self.enemy_positions[current_position] = occupant
            else:
                return False

        if is_ally:
            self.ally_positions[current_position] = None
            self.ally_positions[new_position] = unit
        else:
            self.enemy_positions[current_position] = None
            self.enemy_positions[new_position] = unit

        unit.swap_to_position(new_position)
        return True

    def force_position_change(self, target_unit: 'CombatUnit',
                             new_position: int) -> Tuple[bool, str]:
        """强制改变单位位置（用于敌人拉人等技能）"""
        if target_unit.is_dead or target_unit.is_unconscious:
            return False, "目标无法移动"

        is_ally = (target_unit.unit_type == "player")
        current_pos = target_unit.position

        occupant = self.get_unit_at(new_position, is_ally)

        if occupant and not occupant.is_dead and not occupant.is_unconscious:
            occupant.position = current_pos
            if is_ally:
                self.ally_positions[current_pos] = occupant
            else:
                self.enemy_positions[current_pos] = occupant
        else:
            if is_ally:
                self.ally_positions[current_pos] = None
            else:
                self.enemy_positions[current_pos] = None

        if is_ally:
            self.ally_positions[new_position] = target_unit
        else:
            self.enemy_positions[new_position] = target_unit

        target_unit.swap_to_position(new_position)

        return True, f"{target_unit.name} 被移动到{new_position}号位"

    def get_battlefield_display(self, is_ally: bool) -> Dict:
        """获取战斗显示数据（简化版，只显示存活单位）"""
        positions = self.ally_positions if is_ally else self.enemy_positions
        alive_units = []

        for pos in [1, 2, 3, 4]:
            unit = positions.get(pos)
            if unit and not unit.is_dead and not unit.is_unconscious:
                hp_ratio = unit.current_hp / unit.max_hp
                alive_units.append({
                    "position": pos,
                    "name": unit.name,
                    "hp_ratio": hp_ratio,
                    "conditions": unit.conditions.copy()
                })

        return {
            "alive_count": len(alive_units),
            "units": alive_units
        }
