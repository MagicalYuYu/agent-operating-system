# AstrBot DND/TRPG 插件 v0.1.0 Demo

> **项目名称**: astrbot_plugin_dnd_zero
> **版本**: v0.1.0 Demo
> **规则基础**: D&D 5e
> **数据来源**: 5etools中文站
> **创建日期**: 2026-05-09

---

## 📋 项目概述

AstrBot DND/TRPG 插件是一款基于简化D&D 5e规则的轻量化群组跑团插件，专为QQ群聊场景设计。

### 核心特性

- ✅ **D20核心系统**: 完整的D20掷骰引擎
- ✅ **角色系统**: 职业、种族、属性完整实现
- ✅ **技能检定**: 18项技能全覆盖
- ✅ **战斗系统**: 回合制战斗流程
- ✅ **法术系统**: 核心法术数据库
- ✅ **中文界面**: 友好的中文交互
- ✅ **AstrBot集成**: 标准插件架构

---

## 🎯 功能列表

### 基础指令

| 命令 | 功能 | 说明 |
|------|------|------|
| `/dnd menu` | 显示菜单 | 显示完整帮助菜单 |
| `/dnd help` | 获取帮助 | 同上 |

### 骰子系统

| 命令 | 功能 | 示例 |
|------|------|------|
| `/dnd roll <骰子>` | 掷骰 | `/dnd roll d20`, `/dnd roll 2d6+3` |
| `/dnd init` | 先攻检定 | 自动使用敏捷调整值 |

### 角色系统

| 命令 | 功能 | 说明 |
|------|------|------|
| `/dnd create` | 创建角色 | 自动分配标准属性 |
| `/dnd status` | 查看状态 | 显示角色完整信息 |
| `/dnd abilities` | 查看属性 | 显示详细属性面板 |

### 检定系统

| 命令 | 功能 | 示例 |
|------|------|------|
| `/dnd skill <技能>` | 技能检定 | `/dnd skill 运动` |
| `/dnd save <属性>` | 豁免检定 | `/dnd save 敏捷` |

### 战斗系统

| 命令 | 功能 | 说明 |
|------|------|------|
| `/dnd attack <目标>` | 攻击检定 | 对抗AC 15 |
| `/dnd dmg <伤害骰>` | 伤害掷骰 | `/dnd dmg 1d8+3` |

### 法术系统

| 命令 | 功能 | 说明 |
|------|------|------|
| `/dnd spells` | 法术列表 | 显示所有已知法术 |
| `/dnd spell <名称>` | 法术详情 | 显示法术详细信息 |

### 娱乐功能

| 命令 | 功能 | 说明 |
|------|------|------|
| `/dnd quote` | 随机名言 | 随机显示DND名言 |

### 管理员指令

| 命令 | 功能 | 权限 |
|------|------|------|
| `/dnd admin reload` | 重载配置 | 超级管理员 |
| `/dnd admin status` | 查看状态 | 超级管理员 |

---

## 📁 项目结构

```
astrbot_plugin_dnd_zero/
├── main.py                      # 插件主文件 ⭐
├── metadata.yaml                # 插件元数据
├── _conf_schema.json            # 配置定义
├── requirements.txt            # 依赖列表
├── backup/                    # 备份目录
├── core/                      # 核心模块 ⭐
│   ├── __init__.py
│   ├── dice.py               # D20掷骰引擎
│   ├── character.py          # 角色系统
│   ├── skill.py             # 技能检定
│   ├── combat.py            # 战斗系统
│   └── spell.py             # 法术系统
├── data/                      # 数据层
│   ├── __init__.py
│   └── loader.py            # 5etools数据加载器
└── util/                     # 工具模块
    └── __init__.py          # 数据管理器
```

---

## 🔧 技术架构

### 核心技术栈

| 组件 | 选择 | 说明 |
|------|------|------|
| **主语言** | Python 3.10+ | AstrBot框架要求 |
| **数据格式** | JSON | 轻量、易解析 |
| **HTTP客户端** | httpx | 异步推荐库 |
| **数据源** | 5etools中文站 | 中文、免费、完整 |

### 核心模块说明

#### 1. core/dice.py - D20掷骰引擎

提供完整的D&D掷骰系统：
- `DiceRoller.roll()` - 通用掷骰
- `DiceRoller.roll_d20()` - D20核心掷骰
- `DiceRoller.roll_attack()` - 攻击检定
- `DiceRoller.roll_from_notation()` - 解析骰子记号
- `AbilityCalculator` - 属性计算器

#### 2. core/character.py - 角色系统

完整的角色数据模型：
- `AbilityScores` - 六大属性
- `Character` - 角色核心类
- `Skills` - 技能定义
- `CharacterFactory` - 角色工厂

#### 3. core/skill.py - 技能检定

D&D 5e技能检定系统：
- `SkillChecker.roll_skill_check()` - 技能检定
- `SkillChecker.roll_saving_throw()` - 豁免检定
- `SkillChecker.roll_attack_check()` - 攻击检定

#### 4. core/combat.py - 战斗系统

回合制战斗流程：
- `CombatSystem.process_attack()` - 攻击处理
- `CombatSystem.calculate_armor_class()` - AC计算
- `CombatSystem.roll_initiative()` - 先攻排序

#### 5. core/spell.py - 法术系统

法术数据库和施法：
- `SpellDatabase` - 法术数据库
- `Spell` - 法术数据模型
- `Spellcasting` - 施法能力

#### 6. data/loader.py - 数据加载器

从5etools中文站加载数据：
- `DataLoader.get_classes()` - 加载职业
- `DataLoader.get_races()` - 加载种族
- `DataLoader.get_spells()` - 加载法术

---

## 🚀 安装与使用

### 1. 安装插件

1. 将插件文件夹复制到 AstrBot 的 `data/plugins/` 目录
2. 重启 AstrBot 或在 WebUI 中点击"重载插件"

### 2. 配置插件

在 AstrBot WebUI 中配置：
- 添加超级管理员 QQ 号
- 设置是否启用白名单模式
- 配置白名单群组 ID

### 3. 快速开始

```
1. /dnd create          # 创建角色
2. /dnd status          # 查看角色
3. /dnd roll d20        # 掷D20
4. /dnd skill 运动       # 技能检定
5. /dnd attack 哥布林    # 攻击
```

---

## 📊 数据来源

### 5etools中文站

- **网址**: https://5e.kiwee.top/
- **GitHub**: https://github.com/tjliqy/5etools-mirror-2.github.io
- **许可证**: Creative Commons
- **更新**: 2026年4月30日 v2.28.0

### 数据覆盖

- ✅ 12个职业 + 子职业
- ✅ 种族 + 亚种
- ✅ 背景系统
- ✅ 专长系统
- ✅ 18项技能
- ✅ 0-9环法术
- ✅ 怪物图鉴
- ✅ 物品装备

---

## 🔄 更新计划

### v0.1.0 Demo (当前版本)
- ✅ 基础骰子系统
- ✅ 角色创建
- ✅ 技能检定
- ✅ 战斗系统
- ✅ 法术系统

### v0.2.0 (计划中)
- [ ] 完整的角色创建向导
- [ ] 组队系统
- [ ] 副本系统
- [ ] 装备系统
- [ ] 经济系统

### v0.3.0 (计划中)
- [ ] LLM DM 集成
- [ ] 动态剧情生成
- [ ] 多人协作
- [ ] 日常任务
- [ ] 成就系统

---

## ⚠️ 注意事项

1. **版权说明**: 使用5etools数据需注明来源
2. **网络依赖**: Demo版本需要网络连接加载数据
3. **中文翻译**: 部分内容可能为机翻
4. **规则简化**: Demo版本做了适当简化

---

## 📞 技术支持

- **GitHub**: https://github.com/MagicalYu/astrbot_plugin_dnd_zero
- **AstrBot**: https://astrbot.app/
- **5etools中文站**: https://5e.kiwee.top/

---

## 📄 许可证

本插件遵循 MIT 许可证。
D&D 5e 规则版权归 Wizards of the Coast 所有。
数据翻译版权归 5etools中文站汉化组所有。

---

**版本**: v0.1.0 Demo
**状态**: ✅ 已完成
**下一步**: 等待用户反馈，持续迭代
