"""
D&D 5e 种族数据库
包含全部9个基础种族及其亚种的完整数据
"""
from dataclasses import dataclass, field
from typing import List, Optional, Dict


@dataclass
class Subrace:
    """亚种"""
    name_cn: str
    name_en: str
    ability_bonus: Dict[str, int] = field(default_factory=dict)
    traits: List[str] = field(default_factory=list)
    description: str = ""


@dataclass
class DNRace:
    """D&D 种族"""
    name_cn: str
    name_en: str
    speed: int
    darkvision: int
    ability_bonus: Dict[str, int] = field(default_factory=dict)
    traits: List[str] = field(default_factory=list)
    languages: List[str] = field(default_factory=list)
    subraces: List[Subrace] = field(default_factory=list)
    description: str = ""


class RaceDatabase:
    """种族数据库"""

    RACES: Dict[str, DNRace] = {
        "人类": DNRace(
            name_cn="人类",
            name_en="Human",
            speed=30,
            ability_bonus={"力量": 1, "敏捷": 1, "体质": 1, "智力": 1, "感知": 1, "魅力": 1},
            darkvision=0,
            traits=["适应力: 额外获得一项自选技能熟练"],
            languages=["通用语", "一项自选语言"],
            description="充满可能性的种族，在各个领域都有杰出代表。"
        ),
        "精灵": DNRace(
            name_cn="精灵",
            name_en="Elf",
            speed=30,
            ability_bonus={"敏捷": 2, "魅力": 1},
            darkvision=60,
            traits=["精类血统", "感知敏锐: 感知检定获得优势", "休息不需要睡眠"],
            languages=["通用语", "精灵语"],
            subraces=[
                Subrace(
                    name_cn="高等精灵",
                    name_en="High Elf",
                    ability_bonus={"智力": 1},
                    traits=["额外语言: 一项自选语言", "精灵魔法: 识破隐形"],
                    description="擅长奥术魔法的精灵分支。"
                ),
                Subrace(
                    name_cn="木精灵",
                    name_en="Wood Elf",
                    ability_bonus={"感知": 1},
                    traits=["轻潜行", "隐匿: 在户外自然区域躲藏", "木精灵武器: 长弓、短弓等"],
                    description="与森林和谐共处的精灵分支。"
                ),
                Subrace(
                    name_cn="黑暗精灵",
                    name_en="Drow",
                    ability_bonus={"魅力": 1},
                    traits=["超级黑暗视觉: 120尺", "日照敏感", "黑暗精灵魔法: 妖火等"],
                    description="居住在地下的精灵分支，肤色深黑。"
                )
            ],
            description="优雅、长寿、与魔法有着天然联系的种族。"
        ),
        "矮人": DNRace(
            name_cn="矮人",
            name_en="Dwarf",
            speed=25,
            ability_bonus={"体质": 2, "魅力": 1},
            darkvision=60,
            traits=["矮人坚韧", "毒素抗性", "武器训练: 战斧、重锤等", "石头感应"],
            languages=["通用语", "矮人语"],
            subraces=[
                Subrace(
                    name_cn="山矮人",
                    name_en="Mountain Dwarf",
                    ability_bonus={"力量": 2},
                    traits=["护甲训练: 轻甲、中甲"],
                    description="擅长战斗和工艺的矮人分支。"
                ),
                Subrace(
                    name_cn="丘陵矮人",
                    name_en="Hill Dwarf",
                    ability_bonus={"感知": 1},
                    traits=["矮人韧性: 最大生命值+1每级"],
                    description="生活在丘陵地带的矮人分支。"
                )
            ],
            description="坚韧、技艺精湛、居住在地下的种族。"
        ),
        "半身人": DNRace(
            name_cn="半身人",
            name_en="Halfling",
            speed=30,
            ability_bonus={"魅力": 2, "敏捷": 1},
            darkvision=0,
            traits=["半身人幸运: 1时重投", "勇气", "灵巧"],
            languages=["通用语", "半身人语"],
            subraces=[
                Subrace(
                    name_cn="轻足半身人",
                    name_en="Lightfoot",
                    ability_bonus={"魅力": 1},
                    traits=["自然隐身: 大型生物身后躲藏"],
                    description="善于隐藏和交际的半身人分支。"
                ),
                Subrace(
                    name_cn="强心半身人",
                    name_en="Stout",
                    ability_bonus={"体质": 1},
                    traits=["毒素抗性"],
                    description="坚韧强壮的半身人分支。"
                )
            ],
            description="小巧、幸运、热爱和平的种族。"
        ),
        "兽人": DNRace(
            name_cn="兽人",
            name_en="Orc",
            speed=30,
            ability_bonus={"力量": 2, "敏捷": 1, "体质": 1},
            darkvision=60,
            traits=["兽类血统", "残暴: 关键时刻额外伤害骰"],
            languages=["通用语", "兽人语"],
            description="勇猛、强悍、与自然紧密联系的种族。"
        ),
        "龙裔": DNRace(
            name_cn="龙裔",
            name_en="Dragonborn",
            speed=30,
            ability_bonus={"力量": 2, "魅力": 1},
            darkvision=0,
            traits=["龙族血统", "呼吸武器", "元素抗性"],
            languages=["通用语", "龙语"],
            description="拥有龙之血脉的威严种族。"
        ),
        "侏儒": DNRace(
            name_cn="侏儒",
            name_en="Gnome",
            speed=25,
            ability_bonus={"智力": 2, "敏捷": 1},
            darkvision=60,
            traits=["侏儒狡黠", "密术认知"],
            languages=["通用语", "侏儒语"],
            subraces=[
                Subrace(
                    name_cn="森林侏儒",
                    name_en="Forest Gnome",
                    ability_bonus={"敏捷": 1},
                    traits=["自然隐身", "侏儒魔法: 戏法"],
                    description="与森林生物交流的侏儒分支。"
                ),
                Subrace(
                    name_cn="岩侏儒",
                    name_en="Rock Gnome",
                    ability_bonus={"体质": 1},
                    traits=["工匠技艺"],
                    description="擅长发明创造的侏儒分支。"
                )
            ],
            description="小巧、聪明、充满好奇心的种族。"
        ),
        "提夫林": DNRace(
            name_cn="提夫林",
            name_en="Tiefling",
            speed=30,
            ability_bonus={"魅力": 2, "智力": 1},
            darkvision=60,
            traits=["地狱血脉", "炼狱魔法", "语言"],
            languages=["通用语", "深渊语/炼狱语"],
            description="拥有炼狱血统的神秘种族。"
        ),
        "半兽人": DNRace(
            name_cn="半兽人",
            name_en="Half-Orc",
            speed=30,
            ability_bonus={"力量": 2, "体质": 1},
            darkvision=60,
            traits=["兽类血统", "残暴: 关键时刻额外伤害骰"],
            languages=["通用语", "兽人语"],
            description="兼具人类与兽人血脉的坚韧种族。"
        )
    }

    @classmethod
    def get_all_races(cls) -> List[str]:
        """获取所有种族名称"""
        return list(cls.RACES.keys())

    @classmethod
    def get_race(cls, name: str) -> Optional[DNRace]:
        """获取种族数据"""
        name = name.strip()
        if name in cls.RACES:
            return cls.RACES[name]
        for cn, race_data in cls.RACES.items():
            if race_data.name_en.lower() == name.lower():
                return race_data
        return None

    @classmethod
    def get_subrace(cls, race_name: str, subrace_name: str) -> Optional[Subrace]:
        """获取亚种数据"""
        race = cls.get_race(race_name)
        if not race:
            return None
        for subrace in race.subraces:
            if subrace.name_cn == subrace_name or subrace.name_en.lower() == subrace_name.lower():
                return subrace
        return None

    @classmethod
    def get_all_subraces(cls, race_name: str) -> List[Subrace]:
        """获取种族所有亚种"""
        race = cls.get_race(race_name)
        return race.subraces if race else []

    @classmethod
    def has_subraces(cls, race_name: str) -> bool:
        """检查种族是否有亚种"""
        race = cls.get_race(race_name)
        return bool(race.subraces) if race else False

    @classmethod
    def get_race_info(cls, name: str) -> Optional[str]:
        """获取种族信息文本"""
        race = cls.get_race(name)
        if not race:
            return None

        info = f"🌍 {race.name_cn} ({race.name_en})\n"
        info += f"━━━━━━━━━━━━━━━━━━━━\n"
        info += f"📖 {race.description}\n\n"
        info += f"🏃 速度: {race.speed}尺\n"

        if race.darkvision > 0:
            info += f"👁 黑暗视觉: {race.darkvision}尺\n"

        bonus_str = ", ".join([f"{k}+{v}" for k, v in race.ability_bonus.items()])
        info += f"📊 属性加成: {bonus_str}\n"

        if race.traits:
            info += f"✨ 特性: {', '.join(race.traits)}\n"

        if race.languages:
            info += f"📜 语言: {', '.join(race.languages)}\n"

        if race.subraces:
            info += f"\n🌿 亚种选项:\n"
            for i, subrace in enumerate(race.subraces, 1):
                sub_bonus = ", ".join([f"{k}+{v}" for k, v in subrace.ability_bonus.items()])
                info += f"  {i}. {subrace.name_cn}: {sub_bonus}\n"
                if subrace.traits:
                    info += f"     {', '.join(subrace.traits)}\n"

        return info

    @classmethod
    def apply_race_bonus(cls, race_name: str, abilities: Dict[str, int], subrace_name: str = None) -> Dict[str, int]:
        """应用种族属性加成"""
        race = cls.get_race(race_name)
        if not race:
            return abilities

        result = abilities.copy()

        for attr, bonus in race.ability_bonus.items():
            if attr in result:
                result[attr] = result[attr] + bonus

        if subrace_name:
            subrace = cls.get_subrace(race_name, subrace_name)
            if subrace:
                for attr, bonus in subrace.ability_bonus.items():
                    if attr in result:
                        result[attr] = result[attr] + bonus

        return result
