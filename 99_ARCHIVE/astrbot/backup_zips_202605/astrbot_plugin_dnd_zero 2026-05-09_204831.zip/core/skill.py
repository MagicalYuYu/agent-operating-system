"""
D&D 5e 技能检定系统
支持攻击检定、技能检定、豁免检定
"""
from dataclasses import dataclass
from typing import Optional, List
from .dice import DiceRoller, D20RollResult, AdvantageType, AbilityCalculator
from .character import Character, Skills


@dataclass
class SkillCheckResult:
    """技能检定结果"""
    skill_name: str
    ability_name: str
    roll: int
    ability_modifier: int
    proficiency_bonus: int
    total: int
    dc: Optional[int] = None
    success: bool = False
    is_critical: bool = False
    is_fumble: bool = False

    def __str__(self) -> str:
        result = f"🎲 **{self.skill_name}** 检定\n"
        result += f"━━━━━━━━━━━━━━━━━━━━\n"
        result += f"D20: **{self.roll}**\n"
        result += f"属性调整: {self._format_mod(self.ability_modifier)}\n"

        if self.proficiency_bonus > 0:
            result += f"熟练加值: +{self.proficiency_bonus}\n"

        result += f"━━━━━━━━━━━━━━━━━━━━\n"
        result += f"总计: **{self.total}**"

        if self.dc is not None:
            result += f" vs DC {self.dc}\n"
            if self.success:
                result += "✨ **成功！**"
            else:
                result += "❌ **失败！**"

        if self.is_critical:
            result += "\n🌟 **大成功！**"
        elif self.is_fumble:
            result += "\n💀 **大失败！**"

        return result

    @staticmethod
    def _format_mod(mod: int) -> str:
        return f"+{mod}" if mod >= 0 else str(mod)


@dataclass
class SavingThrowResult:
    """豁免检定结果"""
    ability_name: str
    roll: int
    modifier: int
    proficiency_bonus: int
    total: int
    dc: Optional[int] = None
    success: bool = False
    is_critical: bool = False
    is_fumble: bool = False

    def __str__(self) -> str:
        result = f"🛡️ **{self.ability_name}** 豁免\n"
        result += f"━━━━━━━━━━━━━━━━━━━━\n"
        result += f"D20: **{self.roll}**\n"
        result += f"属性调整: {self._format_mod(self.modifier)}\n"

        if self.proficiency_bonus > 0:
            result += f"熟练加值: +{self.proficiency_bonus}\n"

        result += f"━━━━━━━━━━━━━━━━━━━━\n"
        result += f"总计: **{self.total}**"

        if self.dc is not None:
            result += f" vs DC {self.dc}\n"
            if self.success:
                result += "✨ **成功！**"
            else:
                result += "❌ **失败！**"

        return result

    @staticmethod
    def _format_mod(mod: int) -> str:
        return f"+{mod}" if mod >= 0 else str(mod)


@dataclass
class AttackResult:
    """攻击检定结果"""
    attack_bonus: int
    roll: int
    total: int
    target_ac: int
    hit: bool = False
    critical_hit: bool = False
    critical_fumble: bool = False

    def __str__(self) -> str:
        result = f"⚔️ 攻击检定\n"
        result += f"━━━━━━━━━━━━━━━━━━━━\n"
        result += f"D20: **{self.roll}** + {self.attack_bonus} = **{self.total}**\n"
        result += f"目标AC: {self.target_ac}\n"
        result += f"━━━━━━━━━━━━━━━━━━━━\n"

        if self.critical_hit:
            result += "🎯 **暴击！自动命中！**"
        elif self.critical_fumble:
            result += "💀 **大失败！攻击失手！**"
        elif self.hit:
            result += "✅ **命中！**"
        else:
            result += "❌ **未命中！**"

        return result


class SkillChecker:
    """技能检定系统"""

    SKILL_CHINESE_TO_ABILITY = Skills.SKILL_ABILITY_MAP

    def __init__(self):
        pass

    def roll_skill_check(
        self,
        character: Character,
        skill_name: str,
        dc: Optional[int] = None,
        advantage_type: AdvantageType = AdvantageType.NONE
    ) -> SkillCheckResult:
        """执行技能检定

        Args:
            character: 角色
            skill_name: 技能名称（中文或英文）
            dc: 难度等级
            advantage_type: 优势类型

        Returns:
            SkillCheckResult: 检定结果
        """
        skill_name_cn = self._normalize_skill_name(skill_name)
        ability_name = self.SKILL_CHINESE_TO_ABILITY.get(skill_name_cn, "strength")

        ability_mod = character.abilities.get_modifier(ability_name)

        proficiency_bonus = 0
        if skill_name_cn in character.skill_proficiencies:
            proficiency_bonus = character.proficiency_bonus

        d20_result = DiceRoller.roll_d20(advantage_type)

        total = d20_result.roll + ability_mod + proficiency_bonus

        success = True
        if dc is not None:
            success = total >= dc

        return SkillCheckResult(
            skill_name=skill_name_cn,
            ability_name=ability_name,
            roll=d20_result.roll,
            ability_modifier=ability_mod,
            proficiency_bonus=proficiency_bonus,
            total=total,
            dc=dc,
            success=success,
            is_critical=d20_result.is_critical,
            is_fumble=d20_result.is_fumble
        )

    def roll_saving_throw(
        self,
        character: Character,
        ability_name: str,
        dc: int,
        advantage_type: AdvantageType = AdvantageType.NONE
    ) -> SavingThrowResult:
        """执行豁免检定

        Args:
            character: 角色
            ability_name: 属性名称
            dc: 难度等级
            advantage_type: 优势类型

        Returns:
            SavingThrowResult: 检定结果
        """
        ability_name = ability_name.lower()
        modifier = character.abilities.get_modifier(ability_name)

        proficiency_bonus = 0
        saving_throw_abilities = {
            "strength": "力量",
            "dexterity": "敏捷",
            "constitution": "体质",
            "intelligence": "智力",
            "wisdom": "感知",
            "charisma": "魅力"
        }

        ability_cn = saving_throw_abilities.get(ability_name, ability_name)
        if ability_cn in getattr(character, 'saving_throws', []):
            proficiency_bonus = character.proficiency_bonus

        d20_result = DiceRoller.roll_d20(advantage_type)
        total = d20_result.roll + modifier + proficiency_bonus

        return SavingThrowResult(
            ability_name=ability_name.capitalize(),
            roll=d20_result.roll,
            modifier=modifier,
            proficiency_bonus=proficiency_bonus,
            total=total,
            dc=dc,
            success=total >= dc,
            is_critical=d20_result.is_critical,
            is_fumble=d20_result.is_fumble
        )

    def roll_attack_check(
        self,
        character: Character,
        target_ac: int,
        weapon_bonus: int = None,
        advantage_type: AdvantageType = AdvantageType.NONE
    ) -> AttackResult:
        """执行攻击检定

        Args:
            character: 角色
            target_ac: 目标护甲等级
            weapon_bonus: 武器攻击加值
            advantage_type: 优势类型

        Returns:
            AttackResult: 检定结果
        """
        if weapon_bonus is None:
            weapon_bonus = character.get_attack_bonus()

        d20_result = DiceRoller.roll_attack(weapon_bonus, advantage_type)

        hit = False
        if d20_result.is_critical:
            hit = True
        elif d20_result.is_fumble:
            hit = False
        else:
            hit = d20_result.total >= target_ac

        return AttackResult(
            attack_bonus=weapon_bonus,
            roll=d20_result.roll,
            total=d20_result.total,
            target_ac=target_ac,
            hit=hit,
            critical_hit=d20_result.is_critical,
            critical_fumble=d20_result.is_fumble
        )

    def get_all_skills(self) -> List[str]:
        """获取所有技能列表"""
        return list(self.SKILL_CHINESE_TO_ABILITY.keys())

    def _normalize_skill_name(self, skill_name: str) -> str:
        """标准化技能名称（英文转中文）"""
        if skill_name in Skills.ENGLISH_TO_CHINESE:
            return Skills.ENGLISH_TO_CHINESE[skill_name]

        for cn, en in Skills.ENGLISH_TO_CHINESE.items():
            if skill_name.lower() == en.lower():
                return cn

        return skill_name

    def get_skill_info(self, skill_name: str) -> dict:
        """获取技能信息"""
        skill_name = self._normalize_skill_name(skill_name)
        ability = self.SKILL_CHINESE_TO_ABILITY.get(skill_name, "strength")

        ability_cn_map = {
            "strength": "力量",
            "dexterity": "敏捷",
            "constitution": "体质",
            "intelligence": "智力",
            "wisdom": "感知",
            "charisma": "魅力"
        }

        return {
            "name": skill_name,
            "ability": ability_cn_map.get(ability, ability),
            "description": f"使用{ability_cn_map.get(ability, ability)}进行检定"
        }
