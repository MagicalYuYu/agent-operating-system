"""
背包系统模块 - 管理物品和使用逻辑
"""
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional


@dataclass
class BackpackItem:
    """背包物品"""
    item_id: str
    name: str
    item_type: str
    rarity: str = "common"
    description: str = ""
    quantity: int = 1
    effects: Dict[str, Any] = field(default_factory=dict)


class BackpackSystem:
    """背包系统"""

    MAX_CAPACITY = 20

    ITEM_TEMPLATES = {
        "小血瓶": {
            "name": "小血瓶",
            "item_type": "consumable",
            "rarity": "common",
            "description": "恢复 1d4+1 点生命值",
            "effects": {"heal": {"dice": "1d4+1"}}
        },
        "中血瓶": {
            "name": "中血瓶",
            "item_type": "consumable",
            "rarity": "uncommon",
            "description": "恢复 2d4+2 点生命值",
            "effects": {"heal": {"dice": "2d4+2"}}
        },
        "大血瓶": {
            "name": "大血瓶",
            "item_type": "consumable",
            "rarity": "rare",
            "description": "恢复 4d4+4 点生命值",
            "effects": {"heal": {"dice": "4d4+4"}}
        },
        "解毒药水": {
            "name": "解毒药水",
            "item_type": "consumable",
            "rarity": "uncommon",
            "description": "解除中毒状态",
            "effects": {"cure_poison": True}
        },
        "隐身药水": {
            "name": "隐身药水",
            "item_type": "consumable",
            "rarity": "rare",
            "description": "使用者隐身 1 小时",
            "effects": {"invisibility": {"duration": 60}}
        },
        "治疗卷轴": {
            "name": "治疗卷轴",
            "item_type": "scroll",
            "rarity": "uncommon",
            "description": "使用后恢复 2d4+2 点生命值",
            "effects": {"heal": {"dice": "2d4+2"}}
        },
        "防护卷轴": {
            "name": "防护卷轴",
            "item_type": "scroll",
            "rarity": "uncommon",
            "description": "使用后获得 +2 AC 持续 1 小时",
            "effects": {"ac_bonus": {"bonus": 2, "duration": 60}}
        },
        "绳索": {
            "name": "绳索（50尺）",
            "item_type": "tool",
            "rarity": "common",
            "description": "攀爬、捆绑必备",
            "effects": {}
        },
        "火把": {
            "name": "火把",
            "item_type": "tool",
            "rarity": "common",
            "description": "照明 1 小时",
            "effects": {"light": {"duration": 60}}
        },
        "陷阱工具": {
            "name": "陷阱探测工具",
            "item_type": "tool",
            "rarity": "uncommon",
            "description": "用于探测和解除陷阱",
            "effects": {}
        },
    }

    def __init__(self):
        pass

    def add_item(self, inventory: List[Dict[str, Any]], item_name: str, quantity: int = 1,
                 item_data: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """添加物品到背包

        Args:
            inventory: 当前背包列表
            item_name: 物品名称
            quantity: 数量
            item_data: 物品完整数据（可选，如果不提供则从模板查找）

        Returns:
            操作结果
        """
        if len(inventory) >= self.MAX_CAPACITY and not self._has_item(inventory, item_name):
            return {
                "success": False,
                "message": f"背包已满（{self.MAX_CAPACITY}/{self.MAX_CAPACITY}），无法添加更多物品"
            }

        if item_data:
            template = item_data.copy()
        else:
            template = self.ITEM_TEMPLATES.get(item_name)

        if not template:
            return {
                "success": False,
                "message": f"未知的物品：{item_name}"
            }

        if self._has_item(inventory, item_name):
            for item in inventory:
                if item.get("name") == item_name:
                    item["quantity"] = item.get("quantity", 1) + quantity
                    break
            return {
                "success": True,
                "message": f"获得 {item_name} ×{quantity}",
                "item": template
            }
        else:
            new_item = template.copy()
            new_item["quantity"] = quantity
            inventory.append(new_item)
            return {
                "success": True,
                "message": f"获得 {item_name} ×{quantity}",
                "item": new_item
            }

    def remove_item(self, inventory: List[Dict[str, Any]], item_name: str, quantity: int = 1) -> Dict[str, Any]:
        """从背包移除物品

        Args:
            inventory: 当前背包列表
            item_name: 物品名称
            quantity: 数量

        Returns:
            操作结果
        """
        if not self._has_item(inventory, item_name):
            return {
                "success": False,
                "message": f"背包中没有 {item_name}"
            }

        for i, item in enumerate(inventory):
            if item.get("name") == item_name:
                current_qty = item.get("quantity", 1)
                if current_qty <= quantity:
                    inventory.pop(i)
                    return {
                        "success": True,
                        "message": f"丢弃了 {item_name} ×{current_qty}"
                    }
                else:
                    item["quantity"] = current_qty - quantity
                    return {
                        "success": True,
                        "message": f"丢弃了 {item_name} ×{quantity}"
                    }

        return {
            "success": False,
            "message": f"操作失败"
        }

    def use_item(self, inventory: List[Dict[str, Any]], item_name: str) -> Dict[str, Any]:
        """使用物品

        Args:
            inventory: 当前背包列表
            item_name: 物品名称

        Returns:
            使用结果
        """
        if not self._has_item(inventory, item_name):
            return {
                "success": False,
                "message": f"背包中没有 {item_name}"
            }

        template = self.ITEM_TEMPLATES.get(item_name)
        if not template:
            return {
                "success": False,
                "message": f"无法使用 {item_name}，物品数据不存在"
            }

        item_type = template.get("item_type")
        effects = template.get("effects", {})

        result_message = self._generate_use_message(item_name, item_type, effects)

        self.remove_item(inventory, item_name, 1)

        return {
            "success": True,
            "message": result_message,
            "effects": effects
        }

    def _generate_use_message(self, item_name: str, item_type: str, effects: Dict[str, Any]) -> str:
        """生成使用物品的消息"""
        if "heal" in effects:
            heal_effect = effects["heal"]
            dice = heal_effect.get("dice", "1d4+1")
            messages = [
                f"你饮用了{item_name}，感觉体力恢复了不少！",
                f"咕嘟咕嘟～{item_name}的味道还不错！",
                f"喝下{item_name}后，身体充满了力量！",
                f"嗯～{item_name}的效果不错，感觉好多了！"
            ]
            import random
            base_msg = random.choice(messages)
            return f"{base_msg}\n\n💚 恢复了 {dice} 点生命值"
        elif "cure_poison" in effects:
            return f"你饮用了{item_name}，体内的毒素被清除了！\n\n✨ 中毒状态已解除"
        elif "invisibility" in effects:
            return f"你喝下{item_name}，身体渐渐变得透明...\n\n👻 进入隐身状态 1 小时"
        elif "ac_bonus" in effects:
            return f"你使用了{item_name}，一层淡淡的魔法护盾笼罩全身！\n\n🛡️ AC +2，持续 1 小时"
        elif "light" in effects:
            return f"你点燃了{item_name}，周围被照亮了！\n\n🔦 照明 1 小时"
        else:
            return f"你使用了{item_name}"

    def _has_item(self, inventory: List[Dict[str, Any]], item_name: str) -> bool:
        """检查背包中是否有指定物品"""
        return any(item.get("name") == item_name for item in inventory)

    def get_item(self, inventory: List[Dict[str, Any]], item_name: str) -> Optional[Dict[str, Any]]:
        """获取背包中的物品"""
        for item in inventory:
            if item.get("name") == item_name:
                return item
        return None

    def get_inventory_display(self, inventory: List[Dict[str, Any]]) -> str:
        """获取背包显示文本"""
        if not inventory:
            return "🎒 背包空空如也，快去商店买点什么吧！"

        rarity_emojis = {
            "common": "⚪",
            "uncommon": "🟢",
            "rare": "🔵",
            "very_rare": "🟣",
            "legendary": "🟡"
        }

        items_by_type = {}
        for item in inventory:
            item_type = item.get("item_type", "misc")
            if item_type not in items_by_type:
                items_by_type[item_type] = []
            items_by_type[item_type].append(item)

        type_names = {
            "consumable": "💊 消耗品",
            "scroll": "📜 卷轴",
            "tool": "🔧 工具",
            "weapon": "⚔️ 武器",
            "armor": "🛡️ 防具",
            "misc": "📦 杂物"
        }

        lines = []
        for item_type, items in items_by_type.items():
            type_name = type_names.get(item_type, item_type)
            lines.append(f"\n{type_name}")
            for item in items:
                emoji = rarity_emojis.get(item.get("rarity", "common"), "⚪")
                name = item.get("name", "")
                qty = item.get("quantity", 1)
                qty_str = f" ×{qty}" if qty > 1 else ""
                desc = item.get("description", "")
                lines.append(f"  {emoji} {name}{qty_str}")

        used_capacity = len(inventory)
        header = f"🎒 背包（{used_capacity}/{self.MAX_CAPACITY}）"
        content = "\n".join(lines)

        return f"""
{'='*60}
              {header}
{'='*60}

{content}

{'='*60}
"""
