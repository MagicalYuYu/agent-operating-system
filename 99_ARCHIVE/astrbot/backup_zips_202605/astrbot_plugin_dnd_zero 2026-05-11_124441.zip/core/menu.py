"""
菜单系统模块 - 生成主菜单界面、区域菜单、功能子菜单
"""
import random
from typing import Dict, List, Optional, Any
from .town import TownSystem
from .npc import NPCDatabase


class MenuSystem:
    """菜单系统 - 生成游戏界面"""

    def __init__(self, town_system: TownSystem, npc_database: NPCDatabase):
        self.town_system = town_system
        self.npc_database = npc_database

    def get_main_menu(self, player_data: Dict[str, Any]) -> str:
        """生成城镇主菜单"""
        gold = player_data.get("gold", 0)
        daily_sign = player_data.get("daily_sign", {})
        sign_days = daily_sign.get("total_days", 0) if daily_sign else 0
        party_id = player_data.get("party_id")
        location_name = self.town_system.get_full_location_name()
        party_status = "无" if not party_id else f"小队 #{party_id[:6]}"

        menu_text = f"""🌆 {location_name} · 城镇大厅

「穿过石桥，踏入{self.town_system.town_data.region_name_cn}的石板街道，{self._generate_atmosphere_text()}」

━━━━━━━━ 功能 ━━━━━━━━
👤 角色   背包   商店
📜 副本   冒险小队   每日签到

━━━━━━━━ 状态 ━━━━━━━━
💰 金币: {gold}  |  📅 签到: {sign_days}天  |  👥 {party_status}

💡 /dnd 区域 - 查看地点  |  /dnd NPC - 与NPC对话"""
        return menu_text

    def _generate_atmosphere_text(self) -> str:
        """根据概率生成氛围文本片段"""
        texts = {
            "relaxed": [
                "烤肉香与铁匠铺的叮当声迎面而来",
                "阳光温暖地洒在石板路上",
                "街边的灯笼在微风中轻轻摇曳"
            ],
            "mysterious": [
                "空气中似乎弥漫着一种说不清的气息",
                "远处的阴影似乎在默默注视着来往的人群",
                "灯笼的光芒在某些角落显得格外昏暗"
            ],
            "comedic": [
                "一位商人正在大声吆喝：'三角形的帽子！'",
                "街角有个告示牌写着：'前方施工，请左转——右转'",
                "一只会说话的猫正在向路人推销保险"
            ]
        }
        style = self._select_style()
        return random.choice(texts.get(style, texts["relaxed"]))

    def _select_style(self) -> str:
        """随机选择文本风格"""
        rand = random.random()
        if rand < 0.50:
            return "relaxed"
        elif rand < 0.75:
            return "mysterious"
        else:
            return "comedic"

    def get_area_menu(self) -> str:
        """生成区域菜单"""
        areas = self.town_system.get_all_areas()
        location_name = self.town_system.get_full_location_name()

        area_list = []
        for i, area in enumerate(areas, 1):
            name = area["name"]
            features = area["features"]
            feature_text = f"（{features}）" if features else ""
            area_list.append(f"{i}. {name} {feature_text}")

        areas_text = "\n".join(area_list)

        menu_text = f"""🗺️ {location_name} · 区域地图

{self.town_system.town_data.region_description}

━━━━━━━━ 地点 ━━━━━━━━
{areas_text}

💡 /dnd 区域 <数字/名称> - 查看详情"""
        return menu_text

    def get_area_detail(self, area_id: str) -> str:
        """生成指定区域的详细信息"""
        area_info = self.town_system.get_area_info(area_id)
        if not area_info:
            return "❌ 未找到该区域"

        description = self.town_system.get_area_description(area_id)

        npcs_in_area = self.npc_database.get_npcs_by_location(area_id)
        npc_texts = []
        for npc in npcs_in_area:
            npc_texts.append(f"• {npc.name}（{npc.title}）")

        npc_section = "\n".join(npc_texts) if npc_texts else "暂无常驻NPC"

        menu_text = f"""📍 {area_info['name']}

{description}

地点特色：{area_info['features']}

常驻NPC：
{npc_section}

💡 /dnd NPC <名称> - 与NPC对话"""
        return menu_text

    def get_npc_menu(self) -> str:
        """生成NPC列表菜单"""
        npcs = self.npc_database.get_all_npcs()
        location_name = self.town_system.get_full_location_name()

        npc_list = []
        for i, npc in enumerate(npcs, 1):
            area_name = self.town_system.get_area_name(npc.location) or ""
            npc_list.append(f"{i}. {npc.name}（{npc.title}）- {area_name}")

        npcs_text = "\n".join(npc_list)

        menu_text = f"""👤 {location_name} · NPC列表

在这里你可以与各种NPC交谈，打听消息，购买物品，或者接受任务。

{npcs_text}

💡 /dnd NPC <名称> - 与NPC对话"""
        return menu_text

    def get_npc_dialogue(self, npc_name: str) -> str:
        """生成NPC对话"""
        npc = self.npc_database.get_npc_by_name(npc_name)
        if not npc:
            return f"❌ 未找到名为「{npc_name}」的NPC\n\n💡 /dnd NPC 列表 - 查看所有NPC"

        dialogue = self.npc_database.get_dialogue(npc.npc_id)
        area_name = self.town_system.get_area_name(npc.location) or ""

        menu_text = f"""👤 {npc.name}
{npc.title}

{npc.personality}

「{dialogue}」

📍 所在地点：{area_name}

💡 /dnd NPC {npc.name} - 再次对话"""
        return menu_text

    def get_backpack_display(self, inventory: List[Dict[str, Any]]) -> str:
        """生成背包显示"""
        max_capacity = 20
        used = len(inventory)

        if not inventory:
            return f"""🎒 背包（{used}/{max_capacity}）

背包空空如也，快去商店买点什么吧！"""

        rarity_emojis = {
            "common": "⚪",
            "uncommon": "🟢",
            "rare": "🔵",
            "very_rare": "🟣",
            "legendary": "🟡"
        }

        items_display = []
        for item in inventory:
            emoji = rarity_emojis.get(item.get("rarity", "common"), "⚪")
            name = item.get("name", "")
            qty = item.get("quantity", 1)
            qty_str = f" ×{qty}" if qty > 1 else ""
            items_display.append(f"{emoji} {name}{qty_str}")

        items_text = "\n".join(items_display)

        menu_text = f"""🎒 背包（{used}/{max_capacity}）

{items_text}

💡 /dnd 背包 使用 <物品> - 使用物品
💡 /dnd 背包 丢弃 <物品> - 丢弃物品"""
        return menu_text

    def get_shop_menu(self) -> str:
        """生成商店菜单"""
        menu_text = """🛒 南区集市

━━━━━━━━ 商品分类 ━━━━━━━━
🗡️ 武器  🛡️ 防具  🧪 药水
📜 卷轴  📦 杂货

━━━━━━━━ 操作 ━━━━━━━━
/dnd 商店 分类 <类型> - 查看商品
/dnd 商店 购买 <物品> - 购买物品

例：/dnd 商店 分类 武器"""
        return menu_text

    def get_shop_category(self, category_id: str) -> str:
        """获取商店分类商品"""
        from .shop import ShopDatabase
        db = ShopDatabase()
        category = db.get_category(category_id)

        if not category:
            return "❌ 无效的分类\n\n💡 /dnd 商店 - 返回商店"

        rarity_emojis = {
            "common": "⚪",
            "uncommon": "🟢",
            "rare": "🔵",
            "very_rare": "🟣",
            "legendary": "🟡"
        }

        item_lines = []
        for item in category.items:
            emoji = rarity_emojis.get(item.rarity, "⚪")
            item_lines.append(f"{emoji} {item.name} - {item.price}💰\n   {item.description}")

        items_text = "\n\n".join(item_lines)

        return f"""{category.name}

{items_text}

━━━━━━━━ 操作 ━━━━━━━━
/dnd 商店 购买 <物品> - 购买物品
/dnd 商店 - 返回商店"""

    def get_party_menu(self) -> str:
        """生成冒险小队菜单"""
        menu_text = """👥 冒险小队

在D&D的世界里，冒险者们通常以小队的形式踏上征程。

━━━━━━━━ 操作 ━━━━━━━━
/dnd 冒险小队 创建 - 创建新小队
/dnd 冒险小队 邀请 <玩家> - 邀请成员
/dnd 冒险小队 接受 - 接受邀请
/dnd 冒险小队 离开 - 离开小队
/dnd 冒险小队 状态 - 查看小队

💡 小队最多4人，队长可邀请成员"""
        return menu_text

    def get_party_status_display(self, party_data: Dict[str, Any]) -> str:
        """格式化小队状态显示"""
        party_name = party_data.get("party_name", "未知小队")
        members = party_data.get("members", [])
        member_count = party_data.get("member_count", 0)
        max_members = party_data.get("max_members", 4)

        member_lines = []
        for member in members:
            role_emoji = "👑" if member.get("role") == "leader" else "⚔️"
            member_lines.append(f"{role_emoji} {member.get('player_name', '未知')}")

        members_text = "\n".join(member_lines) if member_lines else "暂无成员"

        return f"""👥 {party_name}

成员（{member_count}/{max_members}）：
{members_text}

━━━━━━━━ 操作 ━━━━━━━━
/dnd 冒险小队 邀请 <玩家> - 邀请成员
/dnd 冒险小队 离开 - 离开小队"""

    def get_daily_sign_result(self, success: bool, total_days: int, gold_reward: int,
                             items_reward: List[Dict], already_signed: bool = False) -> str:
        """生成签到结果消息"""
        if already_signed or not success:
            return f"""✨ 今日已签到

累计签到：{total_days} 天

💡 明天再来签到，获取更丰厚奖励！"""

        items_text = ""
        if items_reward:
            items_text = "\n🎁 获得物品："
            for item in items_reward:
                if item:
                    items_text += f"\n• {item.get('name', '')}"

        return f"""✨ 签到成功！

━━━━━━━━ 签到奖励 ━━━━━━━━
💰 金币 +{gold_reward}
   当前累计：{total_days} 天{items_text}

💡 明天再来签到，获取更丰厚奖励！"""

    def get_dungeon_menu(self) -> str:
        """生成副本菜单"""
        menu_text = """📜 副本入口

━━━━━━━━ 可探索副本 ━━━━━━━━
🌲 森林秘境（Lv.1-5）
   难度：★☆☆☆☆ | 新手副本

💀 地下墓穴（Lv.5-10）
   难度：★★☆☆☆ | 亡灵主题

⛏️ 矮人遗迹（Lv.5-10）
   难度：★★☆☆☆ | 机关解谜

🗼 法师塔（Lv.10-15）
   难度：★★★☆☆ | 魔法战斗

🐉 龙穴（Lv.15-20）
   难度：★★★★★ | 终极副本

💡 建议先组建冒险小队，再挑战副本"""
        return menu_text
