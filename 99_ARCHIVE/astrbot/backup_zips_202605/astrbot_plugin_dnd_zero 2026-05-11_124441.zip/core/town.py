"""
城镇系统模块 - 管理深水城南区区域数据和文本生成
"""
import json
import random
from dataclasses import dataclass, field
from typing import List, Dict, Optional
from pathlib import Path


@dataclass
class TownLocation:
    """城镇区域"""
    area_id: str
    name: str
    name_en: str
    npcs: List[str] = field(default_factory=list)
    features: List[str] = field(default_factory=list)
    descriptions: Dict[str, List[str]] = field(default_factory=dict)


@dataclass
class TownData:
    """城镇完整数据"""
    city_id: str
    city_name_cn: str
    city_name_en: str
    city_description: str
    region_id: str
    region_name_cn: str
    region_name_en: str
    region_description: str
    atmosphere: str
    areas: Dict[str, TownLocation] = field(default_factory=dict)
    area_order: List[str] = field(default_factory=list)


class TownSystem:
    """城镇系统 - 管理深水城南区"""

    def __init__(self, data_path: Optional[str] = None):
        self.data_path = data_path or self._get_default_data_path()
        self.town_data: Optional[TownData] = None
        self._load_data()

    def _get_default_data_path(self) -> str:
        """获取默认数据路径"""
        current_dir = Path(__file__).parent.parent
        return str(current_dir / "data" / "town_data.json")

    def _load_data(self) -> None:
        """加载城镇数据"""
        try:
            with open(self.data_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            self._parse_data(data)
        except FileNotFoundError:
            raise FileNotFoundError(f"城镇数据文件未找到: {self.data_path}")
        except json.JSONDecodeError as e:
            raise ValueError(f"城镇数据 JSON 解析错误: {e}")

    def _parse_data(self, data: dict) -> None:
        """解析城镇数据"""
        areas = {}
        for area_id, area_data in data.get("areas", {}).items():
            areas[area_id] = TownLocation(
                area_id=area_id,
                name=area_data.get("name", ""),
                name_en=area_data.get("name_en", ""),
                npcs=area_data.get("npcs", []),
                features=area_data.get("features", []),
                descriptions=area_data.get("descriptions", {})
            )

        self.town_data = TownData(
            city_id=data.get("city_id", ""),
            city_name_cn=data.get("city_name_cn", ""),
            city_name_en=data.get("city_name_en", ""),
            city_description=data.get("city_description", ""),
            region_id=data.get("region_id", ""),
            region_name_cn=data.get("region_name_cn", ""),
            region_name_en=data.get("region_name_en", ""),
            region_description=data.get("region_description", ""),
            atmosphere=data.get("atmosphere", ""),
            areas=areas,
            area_order=data.get("area_order", [])
        )

    def get_town_info(self) -> Dict[str, str]:
        """获取城镇基本信息"""
        if not self.town_data:
            return {}
        return {
            "city_name_cn": self.town_data.city_name_cn,
            "city_name_en": self.town_data.city_name_en,
            "city_description": self.town_data.city_description,
            "region_name_cn": self.town_data.region_name_cn,
            "region_name_en": self.town_data.region_name_en,
            "region_description": self.town_data.region_description,
        }

    def get_all_areas(self) -> List[Dict[str, str]]:
        """获取所有区域列表"""
        if not self.town_data:
            return []

        result = []
        for area_id in self.town_data.area_order:
            area = self.town_data.areas.get(area_id)
            if area:
                result.append({
                    "area_id": area_id,
                    "name": area.name,
                    "name_en": area.name_en,
                    "features": "、".join(area.features) if area.features else ""
                })
        return result

    def get_area_info(self, area_id: str) -> Optional[Dict[str, str]]:
        """获取指定区域信息"""
        if not self.town_data:
            return None

        area = self.town_data.areas.get(area_id)
        if not area:
            return None

        return {
            "area_id": area.area_id,
            "name": area.name,
            "name_en": area.name_en,
            "features": "、".join(area.features) if area.features else "",
            "npcs": "、".join(area.npcs) if area.npcs else ""
        }

    def get_area_description(self, area_id: str, style: Optional[str] = None) -> Optional[str]:
        """获取区域描述

        Args:
            area_id: 区域 ID
            style: 文本风格（relaxed/mysterious/comedic），如果为 None 则随机选择

        Returns:
            区域描述文本
        """
        if not self.town_data:
            return None

        area = self.town_data.areas.get(area_id)
        if not area:
            return None

        if style is None:
            style = self._select_text_style()

        descriptions = area.descriptions.get(style, [])
        if not descriptions:
            descriptions = area.descriptions.get("relaxed", [])
        if not descriptions:
            return ""

        return random.choice(descriptions)

    def get_area_description_multi_style(self, area_id: str, max_styles: int = 2) -> List[Dict[str, str]]:
        """获取多个风格的区域描述

        Args:
            area_id: 区域 ID
            max_styles: 最大返回的风格数量

        Returns:
            包含风格和描述的列表
        """
        if not self.town_data:
            return []

        area = self.town_data.areas.get(area_id)
        if not area:
            return []

        styles = ["relaxed", "mysterious", "comedic"]
        selected_styles = random.sample(styles, min(max_styles, len(styles)))

        result = []
        style_names = {
            "relaxed": "☀️ 轻松治愈",
            "mysterious": "🌙 惊悚灵异",
            "comedic": "🎭 搞笑无厘头"
        }

        for style in selected_styles:
            descriptions = area.descriptions.get(style, [])
            if descriptions:
                result.append({
                    "style": style,
                    "style_name": style_names.get(style, style),
                    "description": random.choice(descriptions)
                })

        return result

    def _select_text_style(self) -> str:
        """随机选择文本风格

        概率分布:
        - 轻松治愈 (relaxed): 50%
        - 惊悚灵异 (mysterious): 25%
        - 搞笑无厘头 (comedic): 25%
        """
        rand = random.random()
        if rand < 0.50:
            return "relaxed"
        elif rand < 0.75:
            return "mysterious"
        else:
            return "comedic"

    def get_city_name(self) -> str:
        """获取城市名称"""
        if not self.town_data:
            return "未知城市"
        return f"{self.town_data.city_name_cn}"

    def get_region_name(self) -> str:
        """获取区域名称"""
        if not self.town_data:
            return "未知区域"
        return f"{self.town_data.region_name_cn}"

    def get_full_location_name(self) -> str:
        """获取完整地点名称"""
        if not self.town_data:
            return "未知地点"
        return f"{self.town_data.city_name_cn} · {self.town_data.region_name_cn}"

    def get_area_name(self, area_id: str) -> Optional[str]:
        """获取指定区域的名称"""
        if not self.town_data:
            return None
        area = self.town_data.areas.get(area_id)
        if not area:
            return None
        return area.name

    def area_exists(self, area_id: str) -> bool:
        """检查区域是否存在"""
        if not self.town_data:
            return False
        return area_id in self.town_data.areas
