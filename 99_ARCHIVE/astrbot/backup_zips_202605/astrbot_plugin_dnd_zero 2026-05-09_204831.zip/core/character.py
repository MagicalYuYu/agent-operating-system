"""
D&D 5e 角色系统
角色创建、属性管理、职业和种族系统
"""
from dataclasses import dataclass, field
from typing import List, Optional, Dict
from enum import Enum
from .dice import AbilityCalculator, DiceRoller


class Ability(Enum):
    """六大属性"""
    STRENGTH = "strength"
    DEXTERITY = "dexterity"
    CONSTITUTION = "constitution"
    INTELLIGENCE = "intelligence"
    WISDOM = "wisdom"
    CHARISMA = "charisma"


@dataclass
class AbilityScores:
    """属性值"""
    strength: int = 10
    dexterity: int = 10
    constitution: int = 10
    intelligence: int = 10
    wisdom: int = 10
    charisma: int = 10

    def get_modifier(self, ability: str) -> int:
        """获取属性调整值"""
        return AbilityCalculator.get_modifier(getattr(self, ability))

    def get_all_modifiers(self) -> Dict[str, int]:
        """获取所有属性调整值"""
        return {
            "strength": self.get_modifier("strength"),
            "dexterity": self.get_modifier("dexterity"),
            "constitution": self.get_modifier("constitution"),
            "intelligence": self.get_modifier("intelligence"),
            "wisdom": self.get_modifier("wisdom"),
            "charisma": self.get_modifier("charisma")
        }

    def total_bonus(self) -> int:
        """总属性加值"""
        mods = self.get_all_modifiers()
        return sum(mods.values())


@dataclass
class SkillProficiency:
    """技能熟练"""
    name: str
    is_proficient: bool = False
    is_expertise: bool = False

    @property
    def bonus(self) -> int:
        """熟练加值"""
        if self.is_expertise:
            return 2
        elif self.is_proficient:
            return 1
        return 0


class Skills:
    """技能列表及对应的属性"""

    SKILL_ABILITY_MAP = {
        "运动": "strength",
        "杂技": "dexterity",
        "巧手": "dexterity",
        "隐匿": "dexterity",
        "奥秘": "intelligence",
        "历史": "intelligence",
        "调查": "intelligence",
        "自然": "intelligence",
        "宗教": "intelligence",
        "驯兽": "wisdom",
        "洞察": "wisdom",
        "医药": "wisdom",
        "察觉": "wisdom",
        "求生": "wisdom",
        "欺瞒": "charisma",
        "威吓": "charisma",
        "表演": "charisma",
        "说服": "charisma"
    }

    ENGLISH_TO_CHINESE = {
        "athletics": "运动",
        "acrobatics": "杂技",
        "sleight_of_hand": "巧手",
        "stealth": "隐匿",
        "arcana": "奥秘",
        "history": "历史",
        "investigation": "调查",
        "nature": "自然",
        "religion": "宗教",
        "animal_handling": "驯兽",
        "insight": "洞察",
        "medicine": "医药",
        "perception": "察觉",
        "survival": "求生",
        "deception": "欺瞒",
        "intimidation": "威吓",
        "performance": "表演",
        "persuasion": "说服"
    }

    @classmethod
    def get_all_skills(cls) -> List[str]:
        """获取所有技能名称"""
        return list(cls.SKILL_ABILITY_MAP.keys())

    @classmethod
    def get_ability_for_skill(cls, skill: str) -> str:
        """获取技能对应的属性"""
        return cls.SKILL_ABILITY_MAP.get(skill, "strength")


@dataclass
class CharacterClass:
    """职业"""
    name: str
    hit_die: int = 8
    primary_ability: List[str] = field(default_factory=list)
    saving_throws: List[str] = field(default_factory=list)
    armor_proficiencies: List[str] = field(default_factory=list)
    weapon_proficiencies: List[str] = field(default_factory=list)
    tool_proficiencies: List[str] = field(default_factory=list)
    skill_choices: int = 2
    available_skills: List[str] = field(default_factory=list)


@dataclass
class CharacterRace:
    """种族"""
    name: str
    speed: int = 30
    ability_score_increases: Dict[str, int] = field(default_factory=dict)
    darkvision: int = 0
    resistances: List[str] = field(default_factory=list)
    languages: List[str] = field(default_factory=list)
    racial_traits: List[str] = field(default_factory=list)


@dataclass
class CharacterBackground:
    """背景"""
    name: str
    skill_proficiencies: List[str] = field(default_factory=list)
    tool_proficiencies: List[str] = field(default_factory=list)
    languages: List[str] = field(default_factory=list)
    feature: str = ""
    suggested_characteristics: Dict = field(default_factory=dict)


@dataclass
class Equipment:
    """装备"""
    name: str
    category: str = ""
    armor_class: int = 0
    strength_requirement: int = 0
    stealth_disadvantage: bool = False
    damage: str = ""
    weight: float = 0.0
    properties: List[str] = field(default_factory=list)


@dataclass
class Character:
    """角色"""
    name: str
    player_id: str
    level: int = 1
    experience: int = 0

    abilities: AbilityScores = field(default_factory=AbilityScores)

    class_name: str = ""
    subclass: str = ""
    race: str = ""
    background: str = ""

    hit_points: int = 10
    max_hit_points: int = 10
    temporary_hit_points: int = 0
    armor_class: int = 10

    proficiency_bonus: int = 2

    skill_proficiencies: List[str] = field(default_factory=list)

    equipment: List[Equipment] = field(default_factory=list)

    spells_known: List[str] = field(default_factory=list)

    def __post_init__(self):
        """初始化后处理"""
        self.proficiency_bonus = AbilityCalculator.get_proficiency_bonus(self.level)

    def level_up(self, hit_die: int = 8) -> int:
        """升级，返回获得的HP"""
        self.level += 1
        self.proficiency_bonus = AbilityCalculator.get_proficiency_bonus(self.level)

        con_mod = self.abilities.get_modifier("constitution")
        roll = DiceRoller.roll_hit_dice(1, hit_die)
        gained_hp = roll + con_mod

        self.max_hit_points += max(1, gained_hp)
        self.hit_points = self.max_hit_points

        return gained_hp

    def add_experience(self, xp: int):
        """增加经验值"""
        self.experience += xp
        while self.experience >= self.xp_for_next_level() and self.level < 20:
            self.level_up()

    def xp_for_next_level(self) -> int:
        """下一级所需经验值"""
        xp_table = [0, 300, 900, 2700, 6500, 14000, 23000, 34000, 48000, 64000,
                    85000, 100000, 120000, 140000, 165000, 195000, 225000, 265000, 305000, 355000]
        if self.level >= 20:
            return float('inf')
        return xp_table[self.level]

    def heal(self, amount: int):
        """治疗"""
        self.hit_points = min(self.max_hit_points, self.hit_points + amount)

    def take_damage(self, damage: int):
        """受到伤害"""
        if self.temporary_hit_points > 0:
            temp_damage = min(self.temporary_hit_points, damage)
            self.temporary_hit_points -= temp_damage
            damage -= temp_damage

        self.hit_points = max(0, self.hit_points - damage)

    def is_unconscious(self) -> bool:
        """是否昏迷"""
        return self.hit_points <= 0

    def is_dead(self) -> bool:
        """是否死亡"""
        return self.hit_points <= -(self.max_hit_points)

    def get_attack_bonus(self) -> int:
        """获取攻击加值"""
        primary_ability = "strength"
        if self.class_name in ["法师", "术士", "吟游诗人"]:
            primary_ability = "charisma"
        elif self.class_name in ["德鲁伊", "游侠", "武僧"]:
            primary_ability = "wisdom"

        ability_mod = self.abilities.get_modifier(primary_ability)
        return ability_mod + self.proficiency_bonus

    def get_spell_attack_bonus(self) -> int:
        """获取法术攻击加值"""
        spell_ability = "intelligence"
        if self.class_name in ["牧师", "德鲁伊", "游侠"]:
            spell_ability = "wisdom"
        elif self.class_name in ["术士", "吟游诗人", "邪术师"]:
            spell_ability = "charisma"

        ability_mod = self.abilities.get_modifier(spell_ability)
        return ability_mod + self.proficiency_bonus

    def get_spell_save_dc(self) -> int:
        """获取法术豁免DC"""
        spell_ability = "intelligence"
        if self.class_name in ["牧师", "德鲁伊", "游侠"]:
            spell_ability = "wisdom"
        elif self.class_name in ["术士", "吟游诗人", "邪术师"]:
            spell_ability = "charisma"

        ability_mod = self.abilities.get_modifier(spell_ability)
        return 8 + self.proficiency_bonus + ability_mod

    def to_summary(self) -> str:
        """角色摘要"""
        modifiers = self.abilities.get_all_modifiers()
        mods_str = "\n".join([
            f"💪 力量: {self.abilities.strength} ({self._format_mod(modifiers['strength'])})",
            f"🏃 敏捷: {self.abilities.dexterity} ({self._format_mod(modifiers['dexterity'])})",
            f"💚 体质: {self.abilities.constitution} ({self._format_mod(modifiers['constitution'])})",
            f"📚 智力: {self.abilities.intelligence} ({self._format_mod(modifiers['intelligence'])})",
            f"👁️ 感知: {self.abilities.wisdom} ({self._format_mod(modifiers['wisdom'])})",
            f"✨ 魅力: {self.abilities.charisma} ({self._format_mod(modifiers['charisma'])})"
        ])

        return f"""
╔════════════════════════════════════╗
║       🎭 {self.name} 🎭              ║
╠════════════════════════════════════╣
║ 职业: {self.race} {self.class_name} ({self.subclass or '基础'})     ║
║ 等级: {self.level} ({self.experience}/{self.xp_for_next_level()} XP)    ║
╠════════════════════════════════════╣
║ ❤️ HP: {self.hit_points}/{self.max_hit_points}              ║
║ 🛡️ AC: {self.armor_class}                    ║
║ ⚔️ 攻击加值: +{self.get_attack_bonus()}              ║
╠════════════════════════════════════╣
║ 📊 属性值                         ║
{mods_str}
╚════════════════════════════════════╝
        """.strip()

    @staticmethod
    def _format_mod(modifier: int) -> str:
        """格式化调整值"""
        return f"+{modifier}" if modifier >= 0 else str(modifier)


class CharacterFactory:
    """角色工厂"""

    @staticmethod
    def create_by_point_buy() -> AbilityScores:
        """点买规则创建属性

        27点池，每项属性最低8，最高15
        """
        print("\n🎯 属性点买系统")
        print("你有27点可用。属性最低8，最高15。")
        print("每个属性初始10，每提高1点消耗1点，每降低1点获得1点。\n")

        abilities = {
            "力量": 10,
            "敏捷": 10,
            "体质": 10,
            "智力": 10,
            "感知": 10,
            "魅力": 10
        }

        points = 27

        while points > 0:
            print(f"\n剩余点数: {points}")
            print("\n当前属性:")
            for name, value in abilities.items():
                cost = value - 10 if value > 10 else 0
                print(f"  {name}: {value} (调整值: {(value-10)//2:+d}, 提升需{cost}点)")

            choice = input("选择要调整的属性 (1-6): ").strip()
            ability_names = list(abilities.keys())

            if choice.isdigit() and 1 <= int(choice) <= 6:
                ability = ability_names[int(choice) - 1]
                current = abilities[ability]

                if current >= 15:
                    print("已达到最大值15！")
                    continue

                cost = current - 10 if current > 10 else 1

                if points < cost:
                    print(f"点数不足！需要{cost}点，你只有{points}点。")
                    continue

                abilities[ability] += 1
                points -= cost

        return AbilityScores(
            strength=abilities["力量"],
            dexterity=abilities["敏捷"],
            constitution=abilities["体质"],
            intelligence=abilities["智力"],
            wisdom=abilities["感知"],
            charisma=abilities["魅力"]
        )

    @staticmethod
    def create_by_standard_array() -> AbilityScores:
        """标准数组创建属性

        从 [15, 14, 13, 12, 10, 8] 中分配
        """
        print("\n🎯 标准数组系统")
        print("从以下数组中选择并分配: 15, 14, 13, 12, 10, 8")
        print("对应属性: 力量, 敏捷, 体质, 智力, 感知, 魅力\n")

        array = [15, 14, 13, 12, 10, 8]
        abilities = {
            "力量": None,
            "敏捷": None,
            "体质": None,
            "智力": None,
            "感知": None,
            "魅力": None
        }

        remaining = array.copy()

        for ability in abilities.keys():
            print(f"\n可选数值: {remaining}")
            print(f"选择 {ability} 的数值:")

            while True:
                try:
                    choice = int(input("> "))
                    if choice in remaining:
                        abilities[ability] = choice
                        remaining.remove(choice)
                        break
                    else:
                        print("请选择列表中的数值！")
                except ValueError:
                    print("请输入数字！")

        return AbilityScores(
            strength=abilities["力量"],
            dexterity=abilities["敏捷"],
            constitution=abilities["体质"],
            intelligence=abilities["智力"],
            wisdom=abilities["感知"],
            charisma=abilities["魅力"]
        )
