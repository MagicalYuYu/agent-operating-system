"""
DND/TRPG 插件工具模块
提供数据管理、配置处理等通用功能
"""
import json
from pathlib import Path
from typing import Any, Dict, Optional
from datetime import datetime


class DataManager:
    """数据管理器，处理插件数据的持久化"""

    def __init__(self, data_dir: Path):
        self.data_dir = data_dir
        self.data_dir.mkdir(parents=True, exist_ok=True)

    def load_json(self, filename: str) -> Optional[Dict[str, Any]]:
        """加载 JSON 文件"""
        filepath = self.data_dir / filename
        if not filepath.exists():
            return None
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            print(f"加载 {filename} 失败: {e}")
            return None

    def save_json(self, filename: str, data: Dict[str, Any]) -> bool:
        """保存 JSON 文件"""
        filepath = self.data_dir / filename
        try:
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=4)
            return True
        except Exception as e:
            print(f"保存 {filename} 失败: {e}")
            return False

    def backup_file(self, filepath: Path, backup_dir: Path) -> Optional[Path]:
        """备份文件到 backup 目录"""
        if not filepath.exists():
            return None

        backup_dir.mkdir(parents=True, exist_ok=True)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_name = f"{filepath.stem}_{timestamp}{filepath.suffix}"
        backup_path = backup_dir / backup_name

        try:
            import shutil
            shutil.copy2(filepath, backup_path)
            return backup_path
        except Exception as e:
            print(f"备份文件失败: {e}")
            return None


def format_dice_result(dice_type: int, rolls: list, modifier: int = 0) -> str:
    """格式化掷骰结果"""
    roll_str = '+'.join(map(str, rolls))
    total = sum(rolls) + modifier
    modifier_str = f"+{modifier}" if modifier > 0 else (str(modifier) if modifier < 0 else "")
    return f"🎲 {dice_type}面骰: [{roll_str}] {modifier_str} = {total}"


def check_permission(user_id: str, admin_list: list) -> bool:
    """检查用户权限"""
    return str(user_id) in [str(admin) for admin in admin_list]


def get_group_data_path(base_path: Path, group_id: str) -> Path:
    """获取群组数据路径"""
    group_data_dir = base_path / "groups" / str(group_id)
    group_data_dir.mkdir(parents=True, exist_ok=True)
    return group_data_dir
