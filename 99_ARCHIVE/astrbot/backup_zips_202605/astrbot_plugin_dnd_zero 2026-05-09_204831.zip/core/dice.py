"""
D&D 5e D20掷骰系统
核心掷骰引擎，支持各种骰子类型和检定
"""
import random
from dataclasses import dataclass
from typing import List, Optional
from enum import Enum


class AdvantageType(Enum):
    """优势类型"""
    NONE = "none"
    ADVANTAGE = "advantage"
    DISADVANTAGE = "disadvantage"


@dataclass
class DiceRollResult:
    """掷骰结果"""
    rolls: List[int]
    total: int
    modifier: int = 0
    dice_count: int = 1
    dice_type: int = 20

    def __str__(self) -> str:
        roll_str = "+".join(map(str, self.rolls))
        if self.modifier != 0:
            modifier_str = f"+{self.modifier}" if self.modifier > 0 else str(self.modifier)
            return f"[{roll_str}] {modifier_str} = {self.total}"
        else:
            return f"[{roll_str}] = {self.total}"


@dataclass
class D20RollResult:
    """D20检定结果"""
    roll: int
    total: int
    is_critical: bool = False
    is_fumble: bool = False
    advantage_type: AdvantageType = AdvantageType.NONE

    def __str__(self) -> str:
        result = f"🎲 D20: **{self.roll}**"
        if self.advantage_type != AdvantageType.NONE:
            result += f" ({self.advantage_type.value})"
        result += f" + 加成 = {self.total}"
        if self.is_critical:
            result += " ✨ 暴击！"
        elif self.is_fumble:
            result += " 💀 大失败！"
        return result


class DiceRoller:
    """D20系统掷骰器"""

    @staticmethod
    def roll(dice_type: int, dice_count: int = 1, modifier: int = 0) -> DiceRollResult:
        """通用掷骰方法

        Args:
            dice_type: 骰子面数 (如 4, 6, 8, 10, 12, 20)
            dice_count: 骰子数量
            modifier: 加值/减值

        Returns:
            DiceRollResult: 掷骰结果
        """
        rolls = [random.randint(1, dice_type) for _ in range(dice_count)]
        total = sum(rolls) + modifier

        return DiceRollResult(
            rolls=rolls,
            total=total,
            modifier=modifier,
            dice_count=dice_count,
            dice_type=dice_type
        )

    @staticmethod
    def roll_d20(advantage_type: AdvantageType = AdvantageType.NONE) -> D20RollResult:
        """标准D20掷骰

        Args:
            advantage_type: 优势类型

        Returns:
            D20RollResult: D20检定结果
        """
        if advantage_type == AdvantageType.NONE:
            roll = random.randint(1, 20)
        elif advantage_type == AdvantageType.ADVANTAGE:
            roll1 = random.randint(1, 20)
            roll2 = random.randint(1, 20)
            roll = max(roll1, roll2)
        else:  # DISADVANTAGE
            roll1 = random.randint(1, 20)
            roll2 = random.randint(1, 20)
            roll = min(roll1, roll2)

        return D20RollResult(
            roll=roll,
            total=roll,
            is_critical=(roll == 20),
            is_fumble=(roll == 1),
            advantage_type=advantage_type
        )

    @staticmethod
    def roll_attack(
        attack_bonus: int,
        advantage_type: AdvantageType = AdvantageType.NONE
    ) -> D20RollResult:
        """攻击检定

        Args:
            attack_bonus: 攻击加值
            advantage_type: 优势类型

        Returns:
            D20RollResult: 攻击检定结果
        """
        d20_result = DiceRoller.roll_d20(advantage_type)
        d20_result.total = d20_result.roll + attack_bonus
        return d20_result

    @staticmethod
    def roll_skill_check(
        ability_modifier: int,
        proficiency_bonus: int = 0,
        advantage_type: AdvantageType = AdvantageType.NONE
    ) -> D20RollResult:
        """技能检定

        Args:
            ability_modifier: 属性调整值
            proficiency_bonus: 熟练加值
            advantage_type: 优势类型

        Returns:
            D20RollResult: 技能检定结果
        """
        d20_result = DiceRoller.roll_d20(advantage_type)
        d20_result.total = d20_result.roll + ability_modifier + proficiency_bonus
        return d20_result

    @staticmethod
    def roll_saving_throw(
        saving_throw_bonus: int,
        advantage_type: AdvantageType = AdvantageType.NONE
    ) -> D20RollResult:
        """豁免检定

        Args:
            saving_throw_bonus: 豁免加值
            advantage_type: 优势类型

        Returns:
            D20RollResult: 豁免检定结果
        """
        d20_result = DiceRoller.roll_d20(advantage_type)
        d20_result.total = d20_result.roll + saving_throw_bonus
        return d20_result

    @staticmethod
    def roll_damage(dice_count: int, dice_type: int, modifier: int = 0) -> DiceRollResult:
        """伤害掷骰

        Args:
            dice_count: 骰子数量
            dice_type: 骰子面数
            modifier: 加值/减值

        Returns:
            DiceRollResult: 伤害结果
        """
        return DiceRoller.roll(dice_type, dice_count, modifier)

    @staticmethod
    def roll_initiative(dex_modifier: int) -> D20RollResult:
        """先攻检定

        Args:
            dex_modifier: 敏捷调整值

        Returns:
            D20RollResult: 先攻结果
        """
        result = DiceRoller.roll_d20()
        result.total = result.roll + dex_modifier
        return result

    @staticmethod
    def roll_hit_dice(current_level: int, hit_die: int = 8) -> int:
        """生命骰投掷（升级时）

        Args:
            current_level: 当前等级
            hit_die: 生命骰面数

        Returns:
            int: 获得的生命值
        """
        roll = random.randint(1, hit_die)
        return roll

    @staticmethod
    def parse_dice_notation(notation: str) -> tuple[int, int, int]:
        """解析骰子记号

        Args:
            notation: 骰子记号，如 "2d6+3", "d20", "1d8"

        Returns:
            tuple: (数量, 面数, 加值)
        """
        import re
        pattern = r'(\d*)d(\d+)([+-]\d+)?'
        match = re.match(pattern, notation.strip())

        if not match:
            raise ValueError(f"无效的骰子记号: {notation}")

        count_str, sides_str, modifier_str = match.groups()

        count = int(count_str) if count_str else 1
        sides = int(sides_str)
        modifier = int(modifier_str) if modifier_str else 0

        return count, sides, modifier

    @staticmethod
    def roll_from_notation(notation: str) -> DiceRollResult:
        """从记号字符串掷骰

        Args:
            notation: 骰子记号，如 "2d6+3", "d20"

        Returns:
            DiceRollResult: 掷骰结果
        """
        count, sides, modifier = DiceRoller.parse_dice_notation(notation)
        return DiceRoller.roll(sides, count, modifier)


class AbilityCalculator:
    """属性计算器"""

    @staticmethod
    def get_modifier(ability_score: int) -> int:
        """计算属性调整值

        D&D 5e 规则：(属性值 - 10) // 2

        Args:
            ability_score: 属性值 (通常 1-20)

        Returns:
            int: 属性调整值
        """
        return (ability_score - 10) // 2

    @staticmethod
    def get_proficiency_bonus(level: int) -> int:
        """获取熟练加值

        D&D 5e 规则:
        - 等级1-4: +2
        - 等级5-8: +3
        - 等级9-12: +4
        - 等级13-16: +5
        - 等级17-20: +6

        Args:
            level: 角色等级 (1-20)

        Returns:
            int: 熟练加值
        """
        if level < 5:
            return 2
        elif level < 9:
            return 3
        elif level < 13:
            return 4
        elif level < 17:
            return 5
        else:
            return 6

    @staticmethod
    def get_passive_check(ability_modifier: int, proficiency_bonus: int = 0, has_proficiency: bool = False) -> int:
        """计算被动检定

        Args:
            ability_modifier: 属性调整值
            proficiency_bonus: 熟练加值
            has_proficiency: 是否有熟练项

        Returns:
            int: 被动检定值
        """
        base = 10 + ability_modifier
        if has_proficiency:
            base += proficiency_bonus
        return base
