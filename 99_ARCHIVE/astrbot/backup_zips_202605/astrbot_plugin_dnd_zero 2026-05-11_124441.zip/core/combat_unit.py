"""
D&D/Zero 战斗单位系统
CombatUnit、PlayerUnit、MonsterUnit
"""
from dataclasses import dataclass, field
from typing import List, Optional, Dict, Tuple
from .combat_position import AttackRange, MELEE_RANGE, RANGED_RANGE, PIERCE_RANGE


@dataclass
class CombatUnit:
    """战斗单位基类"""
    unit_id: str
    name: str
    unit_type: str = "player"

    position: int = 1
    original_position: int = 1
    is_original_position: bool = True

    max_hp: int = 10
    current_hp: int = 10
    temp_hp: int = 0
    armor_class: int = 10
    speed: int = 30

    proficiency_bonus: int = 2

    abilities: Dict[str, int] = field(default_factory=lambda: {
        "strength": 10, "dexterity": 10, "constitution": 10,
        "intelligence": 10, "wisdom": 10, "charisma": 10
    })

    attack_bonus: int = 0
    damage_bonus: int = 0

    class_name: str = ""
    level: int = 1

    action_used: bool = False
    bonus_action_used: bool = False
    reaction_available: bool = True
    movement_used: bool = False

    spell_slots: Dict[int, int] = field(default_factory=dict)
    prepared_spells: List[str] = field(default_factory=list)

    conditions: List[str] = field(default_factory=list)
    concentration_spell: Optional[str] = None

    death_saves: Dict[str, int] = field(default_factory=lambda: {"success": 0, "fail": 0})
    is_unconscious: bool = False
    is_dead: bool = False

    is_taunted: bool = False
    taunt_source: Optional[str] = None

    defending: bool = False
    dodging: bool = False
    temp_ac_bonus: int = 0

    def get_modifier(self, ability: str) -> int:
        """获取属性调整值"""
        score = self.abilities.get(ability, 10)
        return (score - 10) // 2

    def get_position_status(self) -> str:
        """获取位置状态"""
        if self.is_dead:
            return "dead"
        elif self.is_unconscious:
            return "unconscious"
        else:
            return "alive"

    def swap_to_position(self, new_position: int) -> bool:
        """换到新位置"""
        if new_position not in [1, 2, 3, 4]:
            return False

        self.position = new_position
        self.is_original_position = (new_position == self.original_position)
        return True

    def take_damage(self, damage: int):
        """受到伤害"""
        if self.temp_hp > 0:
            if self.temp_hp >= damage:
                self.temp_hp -= damage
                damage = 0
            else:
                damage -= self.temp_hp
                self.temp_hp = 0

        self.current_hp -= damage

        if self.current_hp <= 0:
            self.current_hp = 0
            self.is_unconscious = True
            self.conditions.append("昏迷")

    def heal(self, amount: int):
        """治疗"""
        self.current_hp = min(self.max_hp, self.current_hp + amount)

        if self.is_unconscious and self.current_hp > 0:
            self.is_unconscious = False
            if "昏迷" in self.conditions:
                self.conditions.remove("昏迷")

    def apply_condition(self, condition: str):
        """施加状态"""
        if condition not in self.conditions:
            self.conditions.append(condition)

    def remove_condition(self, condition: str):
        """移除状态"""
        if condition in self.conditions:
            self.conditions.remove(condition)

    def get_effective_ac(self) -> int:
        """获取有效护甲等级"""
        ac = self.armor_class

        if self.defending:
            ac += 2

        ac += self.temp_ac_bonus

        return ac

    def reset_turn(self):
        """重置回合状态"""
        self.action_used = False
        self.bonus_action_used = False
        self.movement_used = False
        self.reaction_available = True
        self.defending = False
        self.dodging = False
        self.temp_ac_bonus = 0


@dataclass
class PlayerUnit(CombatUnit):
    """玩家战斗单位"""
    unit_type: str = "player"
    player_id: str = ""
    player_name: str = ""

    racial_traits: List[str] = field(default_factory=list)
    class_features: List[str] = field(default_factory=list)

    saving_throws: Dict[str, bool] = field(default_factory=dict)
    skill_proficiencies: List[str] = field(default_factory=list)

    equipment_bonus: Dict[str, int] = field(default_factory=dict)

    weapon_range: AttackRange = MELEE_RANGE
    default_weapon: str = "unarmed"
    default_damage: str = "1d4"

    def __post_init__(self):
        if isinstance(self.weapon_range, dict):
            self.weapon_range = AttackRange(
                range=self.weapon_range.get("range", 2),
                start=self.weapon_range.get("start", 1)
            )

    def get_attack_range(self, skill_id: str = None) -> AttackRange:
        """获取攻击范围"""
        return self.weapon_range

    def can_use_skill(self, skill_id: str, required_position: any = None) -> Tuple[bool, str]:
        """检查是否可以使用技能"""
        if required_position is not None:
            if isinstance(required_position, list):
                if self.position not in required_position:
                    return False, f"需要站在 {required_position} 号位"
            else:
                if self.position != required_position:
                    return False, f"需要站在 {required_position} 号位"

        return True, ""

    def roll_death_save(self) -> Tuple[bool, str, Dict]:
        """投掷死亡豁免"""
        import random
        roll = random.randint(1, 20)

        if roll == 20:
            self.is_unconscious = False
            self.current_hp = 1
            if "昏迷" in self.conditions:
                self.conditions.remove("昏迷")
            return True, "大成功！立即苏醒！", {"roll": roll, "success": 3}

        if roll == 1:
            self.death_saves["fail"] += 2
            return False, "大失败！算作2次失败", {"roll": roll, "fail": self.death_saves["fail"]}

        dc = 10
        save_roll = roll + self.get_modifier("constitution")

        if save_roll >= dc:
            self.death_saves["success"] += 1
            msg = f"成功！({roll} vs DC{dc})"
        else:
            self.death_saves["fail"] += 1
            msg = f"失败！({roll} vs DC{dc})"

        if self.death_saves["success"] >= 3:
            self.is_unconscious = False
            self.current_hp = 1
            if "昏迷" in self.conditions:
                self.conditions.remove("昏迷")
            if "倒地" not in self.conditions:
                self.conditions.append("倒地")
            msg = "稳定存活！"
            self.death_saves = {"success": 0, "fail": 0}

        elif self.death_saves["fail"] >= 3:
            self.is_dead = True
            self.is_unconscious = False
            msg = "死亡！"

        return self.death_saves["success"] >= 3, msg, {
            "roll": roll,
            "success": self.death_saves["success"],
            "fail": self.death_saves["fail"]
        }


@dataclass
class MonsterUnit(CombatUnit):
    """怪物战斗单位"""
    unit_type: str = "monster"

    monster_role: str = "warrior"
    cr: int = 1

    behavior_script: str = "aggressive"
    target_priority: List[str] = field(default_factory=list)

    special_abilities: List[str] = field(default_factory=list)
    legendary_actions: int = 0
    legendary_action_used: bool = False

    xp_reward: int = 0
    loot_table: List[Dict] = field(default_factory=list)

    melee_attack: bool = True
    ranged_attack: bool = False
    spellcasting: bool = False
    spell_list: List[str] = field(default_factory=list)

    weapon_range: AttackRange = MELEE_RANGE
    default_damage: str = "1d6"

    def __post_init__(self):
        if isinstance(self.weapon_range, dict):
            self.weapon_range = AttackRange(
                range=self.weapon_range.get("range", 2),
                start=self.weapon_range.get("start", 1)
            )

        if self.melee_attack:
            self.weapon_range = MELEE_RANGE
        elif self.ranged_attack:
            self.weapon_range = RANGED_RANGE

    def get_attack_range(self, skill_id: str = None) -> AttackRange:
        """获取攻击范围"""
        return self.weapon_range

    def select_target(self, allies: List['CombatUnit']) -> Optional['CombatUnit']:
        """选择目标（AI）"""
        if not allies:
            return None

        if self.target_priority:
            for priority in self.target_priority:
                if priority == "front_row":
                    targets = [t for t in allies if t.position <= 2]
                    if targets:
                        return targets[0]
                elif priority == "back_row":
                    targets = [t for t in allies if t.position >= 3]
                    if targets:
                        return targets[0]
                elif priority == "low_hp":
                    targets = sorted(allies, key=lambda x: x.current_hp / x.max_hp)
                    if targets:
                        return targets[0]

        return allies[0]

    def decide_action(self, allies: List['CombatUnit']) -> Tuple[str, any]:
        """决定行动（AI）"""
        if self.behavior_script == "aggressive":
            return "attack", self.select_target(allies)
        elif self.behavior_script == "defensive":
            if self.current_hp < self.max_hp * 0.3:
                return "retreat", None
            return "attack", self.select_target(allies)
        elif self.behavior_script == "supportive":
            lowest_ally = min(allies, key=lambda x: x.current_hp / x.max_hp)
            if lowest_ally.current_hp < lowest_ally.max_hp * 0.5:
                return "heal", lowest_ally
            return "attack", self.select_target(allies)

        return "attack", self.select_target(allies)


MONSTER_TEMPLATES = {
    "哥布林": {
        "name": "哥布林",
        "cr": 0.25,
        "max_hp": 7,
        "armor_class": 15,
        "attack_bonus": 4,
        "damage": "1d6+2",
        "monster_role": "warrior",
        "behavior_script": "aggressive",
        "target_priority": ["front_row"],
        "xp_reward": 50,
        "weapon_range": {"range": 2, "start": 1}
    },
    "狼人": {
        "name": "狼人",
        "cr": 1,
        "max_hp": 11,
        "armor_class": 13,
        "attack_bonus": 5,
        "damage": "2d4+3",
        "monster_role": "assassin",
        "behavior_script": "aggressive",
        "target_priority": ["low_hp", "back_row"],
        "xp_reward": 200,
        "weapon_range": {"range": 2, "start": 1}
    },
    "骷髅法师": {
        "name": "骷髅法师",
        "cr": 1,
        "max_hp": 18,
        "armor_class": 12,
        "attack_bonus": 3,
        "damage": "1d10",
        "monster_role": "mage",
        "behavior_script": "defensive",
        "spellcasting": True,
        "spell_list": ["魔法飞弹", "护盾术"],
        "target_priority": ["back_row"],
        "xp_reward": 200,
        "weapon_range": {"range": 4, "start": 1}
    },
    "食尸鬼": {
        "name": "食尸鬼",
        "cr": 1,
        "max_hp": 22,
        "armor_class": 13,
        "attack_bonus": 5,
        "damage": "2d4+3",
        "monster_role": "warrior",
        "behavior_script": "aggressive",
        "special_abilities": ["paralytic_claw"],
        "target_priority": ["front_row"],
        "xp_reward": 200,
        "weapon_range": {"range": 2, "start": 1}
    },
    "巨魔": {
        "name": "巨魔",
        "cr": 5,
        "max_hp": 84,
        "armor_class": 15,
        "attack_bonus": 7,
        "damage": "2d8+5",
        "monster_role": "elite",
        "behavior_script": "aggressive",
        "special_abilities": ["regeneration"],
        "target_priority": ["front_row"],
        "xp_reward": 1800,
        "weapon_range": {"range": 2, "start": 1}
    },
    "牛头人": {
        "name": "牛头人",
        "cr": 3,
        "max_hp": 47,
        "armor_class": 17,
        "attack_bonus": 6,
        "damage": "2d8+4",
        "monster_role": "boss",
        "behavior_script": "aggressive",
        "special_abilities": ["charge", "reckless_attack"],
        "legendary_actions": 2,
        "target_priority": ["front_row"],
        "xp_reward": 700,
        "weapon_range": {"range": 2, "start": 1}
    }
}


def create_monster(monster_type: str, position: int = 1) -> Optional[MonsterUnit]:
    """创建怪物"""
    template = MONSTER_TEMPLATES.get(monster_type)
    if not template:
        return None

    import uuid

    monster = MonsterUnit(
        unit_id=f"mon_{monster_type}_{uuid.uuid4().hex[:8]}",
        name=template["name"],
        position=position,
        original_position=position,
        max_hp=template["max_hp"],
        current_hp=template["max_hp"],
        armor_class=template["armor_class"],
        attack_bonus=template["attack_bonus"],
        damage_bonus=0,
        monster_role=template.get("monster_role", "warrior"),
        cr=template.get("cr", 1),
        behavior_script=template.get("behavior_script", "aggressive"),
        target_priority=template.get("target_priority", ["front_row"]),
        special_abilities=template.get("special_abilities", []),
        legendary_actions=template.get("legendary_actions", 0),
        xp_reward=template.get("xp_reward", 0),
        spellcasting=template.get("spellcasting", False),
        spell_list=template.get("spell_list", []),
        weapon_range=AttackRange(
            range=template.get("weapon_range", {}).get("range", 2),
            start=template.get("weapon_range", {}).get("start", 1)
        ),
        default_damage=template.get("damage", "1d6")
    )

    return monster
