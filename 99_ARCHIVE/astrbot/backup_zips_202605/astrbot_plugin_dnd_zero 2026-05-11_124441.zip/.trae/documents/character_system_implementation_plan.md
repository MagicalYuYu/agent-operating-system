# 角色系统完善计划

> **计划制定日期**: 2026-05-09
> **开发者**: MagicalYu
> **目标版本**: v0.2.0

---

## 一、需求总结

根据用户决策，实现以下角色系统：

| 需求项 | 决策 |
|--------|------|
| 建卡方式 | 交互式 + 单指令两种都要 |
| 属性分配 | 27点购点制 |
| 职业范围 | 全部12个职业（硬编码） |
| 交互流程 | 多轮对话模式 |
| 中途退出 | 自动保存进度（内存存储） |
| 单指令格式 | `/dnd 创建 战士 人类` |

---

## 二、当前状态分析

### 已有实现
1. **数据结构** (`core/character.py`):
   - `Character`, `AbilityScores`, `Skills` 等数据类已定义
   - `CharacterFactory` 包含 `create_by_point_buy()` 和 `create_by_standard_array()` 方法
   - 技能映射 `SKILL_ABILITY_MAP` 完整（18项技能）

2. **数据加载** (`data/loader.py`):
   - `DataLoader` 支持从 5etools 加载数据

3. **现有命令** (`main.py`):
   - `/dnd create` 已存在，但只创建固定的"人类战士"

### 问题
1. `CharacterFactory` 是为命令行交互设计的，不适合QQ群聊场景
2. 没有职业、种族、背景的完整数据
3. 没有多轮对话状态管理机制

---

## 三、实现方案

### 3.1 新增模块

#### 3.1.1 职业数据库 (`core/classes.py`)

硬编码12个职业的完整数据：

```python
@dataclass
class DNDClass:
    name_cn: str              # 中文名
    name_en: str               # 英文名
    hit_die: int               # 生命骰
    primary_ability: List[str] # 主要属性
    saving_throws: List[str]   # 豁免熟练属性
    armor_proficiencies: List[str]   # 护甲熟练
    weapon_proficiencies: List[str]  # 武器熟练
    skill_choices: int         # 可选技能数量
    available_skills: List[str]      # 可选技能列表
    spellcasting_ability: Optional[str]  # 法术施法属性
```

12个职业：
1. 战士 (Fighter) - 生命骰d10
2. 法师 (Wizard) - 生命骰d6
3. 盗贼 (Rogue) - 生命骰d8
4. 牧师 (Cleric) - 生命骰d8
5. 游侠 (Ranger) - 生命骰d10
6. 圣武士 (Paladin) - 生命骰d10
7. 吟游诗人 (Bard) - 生命骰d8
8. 野蛮人 (Barbarian) - 生命骰d12
9. 僧侣 (Monk) - 生命骰d8
10. 德鲁伊 (Druid) - 生命骰d8
11. 术士 (Sorcerer) - 生命骰d6
12. 奇械师 (Artificer) - 生命骰d8

#### 3.1.2 种族数据库 (`core/races.py`)

硬编码9个种族：

```python
@dataclass
class DNRace:
    name_cn: str                    # 中文名
    name_en: str                     # 英文名
    speed: int                       # 移动速度
    ability_bonus: Dict[str, int]     # 属性加成
    darkvision: int                  # 黑暗视觉距离
    traits: List[str]                 # 种族特性
    languages: List[str]              # 已知语言
```

9个种族：
1. 人类 (Human)
2. 精灵 (Elf) - 含高等精灵、木精灵
3. 矮人 (Dwarf) - 含山矮人、丘陵矮人
4. 半身人 (Halfling)
5. 兽人 (Orc)
6. 龙裔 (Dragonborn)
7. 侏儒 (Gnome) - 含森林侏儒、岩侏儒
8. 提夫林 (Tiefling)
9. 半兽人 (Half-Orc)

#### 3.1.3 背景数据库 (`core/backgrounds.py`)

硬编码13个背景：

```python
@dataclass
class Background:
    name_cn: str                    # 中文名
    name_en: str                     # 英文名
    skill_proficiencies: List[str]   # 技能熟练
    languages: int                    # 可选语言数量
    equipment: List[str]             # 起始装备
    feature: str                     # 背景特性
    trait_options: List[str]         # 性格特质选项
```

13个背景：学者、商人、罪犯、艺人、民间英雄、隐士、贵族、农民、船员、士兵、流浪者、祭司、古怪

#### 3.1.4 建卡状态管理 (`core/character_creator.py`)

管理多轮对话状态：

```python
@dataclass
class CharacterCreationState:
    """建卡进度状态"""
    user_id: str
    step: str                        # 当前步骤
    selected_race: Optional[str]     # 已选种族
    selected_class: Optional[str]    # 已选职业
    selected_background: Optional[str] # 已选背景
    abilities: AbilityScores          # 属性值
    skill_proficiencies: List[str]   # 技能熟练
    created_at: datetime             # 创建时间

class CharacterCreator:
    """交互式建卡管理器"""
    def __init__(self):
        self._states: Dict[str, CharacterCreationState] = {}
        self._step_handlers: Dict[str, callable]

    def get_state(self, user_id: str) -> Optional[CharacterCreationState]
    def start_creation(self, user_id: str) -> CharacterCreationState
    def update_step(self, user_id: str, step: str, data: dict)
    def clear_state(self, user_id: str)
    def get_current_prompt(self, state: CharacterCreationState) -> str
```

建卡流程步骤：
1. `race` - 选择种族
2. `subrace` - 选择亚种（如适用）
3. `class` - 选择职业
4. `ability` - 分配属性（27点购点）
5. `skills` - 选择技能熟练
6. `background` - 选择背景
7. `confirm` - 确认并创建

---

### 3.2 修改文件

#### 3.2.1 `core/character.py`

修改内容：
1. `Character` 类添加 `background`, `skill_proficiencies`, `conditions` 等字段
2. `Character.__post_init__()` 支持根据职业自动计算 HP
3. 添加 `get_available_actions()` 方法

#### 3.2.2 `main.py`

修改内容：
1. 添加 `CharacterCreator` 实例
2. 修改 `/dnd create` 命令
3. 添加 `/dnd 创建 种族/职业/属性/背景/确认` 等子命令
4. 添加 `/dnd 建卡` 命令作为交互式入口
5. 修改角色保存逻辑，包含新字段

---

### 3.3 新增指令

#### 交互式建卡指令

| 指令 | 说明 | 别名 |
|------|------|------|
| `/dnd 建卡` | 开始交互式建卡 | `角色创建` |
| `/dnd 创建 种族 [名称]` | 单指令选择种族 | - |
| `/dnd 创建 职业 [名称]` | 单指令选择职业 | - |
| `/dnd 创建 属性 [6个数字]` | 单指令分配属性 | - |
| `/dnd 创建 背景 [名称]` | 单指令选择背景 | - |
| `/dnd 创建 确认` | 确认并完成建卡 | - |
| `/dnd 建卡状态` | 查看当前建卡进度 | `建卡进度` |
| `/dnd 建卡取消` | 取消当前建卡 | `取消建卡` |

#### 角色管理指令

| 指令 | 说明 |
|------|------|
| `/dnd 种族列表` | 显示所有可选种族 |
| `/dnd 职业列表` | 显示所有可选职业 |
| `/dnd 背景列表` | 显示所有可选背景 |
| `/dnd 职业详情 [名称]` | 查看职业详细信息 |
| `/dnd 种族详情 [名称]` | 查看种族详细信息 |

---

## 四、27点购点制详细规则

### 4.1 规则说明

```
初始属性：每项 8 点
可用点数：27 点

属性值 → 花费点数：
- 8 → 0 (起始)
- 9 → 1
- 10 → 2
- 11 → 3
- 12 → 4
- 13 → 5
- 14 → 7
- 15 → 9
```

### 4.2 界面展示

```
🎯 属性点买系统 - {角色名}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
剩余点数: 27

📊 当前属性:
┌─────────┬────────┬─────────┬────────┐
│ 属性    │ 数值   │ 调整值  │ 花费点数│
├─────────┼────────┼─────────┼────────┤
│ 💪力量  │   8    │   -1    │   0    │
│ 🏃敏捷  │   8    │   -1    │   0    │
│ 💚体质  │   8    │   -1    │   0    │
│ 📚智力  │   8    │   -1    │   0    │
│ 👁感知  │   8    │   -1    │   0    │
│ ✨魅力  │   8    │   -1    │   0    │
└─────────┴────────┴─────────┴────────┘

💡 操作说明:
• 回复数字 1-6 选择要调整的属性
• 回复 +/- 调整幅度 (如 +2, -1)
• 回复 "完成" 确认属性分配
```

---

## 五、交互式建卡流程

### 5.1 完整流程图

```
用户发送 "/dnd 建卡"
        ↓
    [步骤1: 种族选择]
        ↓
    显示可选种族列表
        ↓
    用户输入种族名
        ↓
    [步骤1.5: 亚种选择] (如适用)
        ↓
    [步骤2: 职业选择]
        ↓
    显示可选职业列表（标注可选技能数量）
        ↓
    用户输入职业名
        ↓
    [步骤3: 属性分配]
        ↓
    进入27点购点系统
        ↓
    用户逐步分配属性
        ↓
    [步骤4: 技能熟练]
        ↓
    显示职业可选技能列表
        ↓
    用户选择N项技能
        ↓
    [步骤5: 背景选择]
        ↓
    显示可选背景列表
        ↓
    用户输入背景名
        ↓
    [步骤6: 确认]
        ↓
    显示完整角色预览
        ↓
    用户确认 / 取消 / 修改
        ↓
    [完成] → 创建角色，保存数据
```

### 5.2 消息模板

#### 种族选择
```
🌍 步骤1: 选择种族

请选择你的种族：
━━━━━━━━━━━━━━━━━━━━━━━━━━━
1️⃣ 人类     - 全属性+1
2️⃣ 精灵     - 敏捷+2, 魅力+1 | 黑暗视觉
3️⃣ 矮人     - 体质+2, 魅力+1 | 黑暗视觉, 毒素抗性
4️⃣ 半身人   - 魅力+2, 敏捷+1 | 半身人幸运
5️⃣ 兽人     - 力量+2, 敏捷+1 | 黑暗视觉
6️⃣ 龙裔     - 力量+2, 魅力+1 | 火焰/寒冷等抗性
7️⃣ 侏儒     - 智力+2, 敏捷+1 | 黑暗视觉
8️⃣ 提夫林   - 魅力+2, 智力+1 | 黑暗视觉, 火焰抗性
9️⃣ 半兽人   - 力量+2, 体质+1 | 黑暗视觉

💡 输入数字或种族名称进行选择
```

#### 职业选择
```
⚔️ 步骤2: 选择职业

请选择你的职业（已选择: {种族}）：
━━━━━━━━━━━━━━━━━━━━━━━━━━━
1️⃣ 战士    d10 HP | 攻击特长 | 可选2项技能
2️⃣ 法师    d6 HP  | 法术施法 | 可选2项技能
3️⃣ 盗贼    d8 HP | 偷袭, 陷阱 | 可选4项技能
4️⃣ 牧师    d8 HP | 法术施法 | 可选2项技能
5️⃣ 游侠    d10 HP| 法术施法 | 可选3项技能
...

💡 输入数字或职业名称进行选择
```

#### 属性分配
```
📊 步骤3: 属性分配

你正在使用 27点购点制
━━━━━━━━━━━━━━━━━━━━━━━━━━━

💪 力量:  8 → 调整值 -1  [花费: 0点]
🏃 敏捷:  8 → 调整值 -1  [花费: 0点]
💚 体质:  8 → 调整值 -1  [花费: 0点]
📚 智力:  8 → 调整值 -1  [花费: 0点]
👁 感知:  8 → 调整值 -1  [花费: 0点]
✨ 魅力:  8 → 调整值 -1  [花费: 0点]

━━━━━━━━━━━━━━━━━━━━━━━━━━━
📍 剩余点数: 27

请输入要调整的属性：
• "力量+1" 或 "1+1" → 力量+1点
• "敏捷-1" 或 "1-1" → 敏捷-1点
• "完成" → 确认属性分配
```

#### 技能选择
```
🎯 步骤4: 选择技能熟练

已选择职业: {职业}
可选技能数量: {N} 项

请从以下技能中选择 {N} 项：
━━━━━━━━━━━━━━━━━━━━━━━━━━━
💪 力量系: 运动
🏃 敏捷系: 杂技、巧手、隐匿
📚 智力系: 奥秘、历史、调查、自然、宗教
👁 感知系: 驯兽、洞察、医药、察觉、求生
✨ 魅力系: 欺瞒、威吓、表演、说服

💡 输入技能名称进行选择（如：运动,隐匿）
已选择: 0/{N}
```

#### 确认创建
```
📋 角色预览

━━━━━━━━━━━━━━━━━━━━━━━━━━━
🎭 {角色名}
{种族} {职业} | 等级 1
━━━━━━━━━━━━━━━━━━━━━━━━━━━

📊 属性（购点27点制）:
💪 力量:  {值} ({调整值:+})
🏃 敏捷:  {值} ({调整值:+})
💚 体质:  {值} ({调整值:+})
📚 智力:  {值} ({调整值:+})
👁 感知:  {值} ({调整值:+})
✨ 魅力:  {值} ({调整值:+})

🎯 熟练技能: {技能列表}
📜 背景: {背景名} - {背景特性}

━━━━━━━━━━━━━━━━━━━━━━━━━━━
HP: {最大值} | AC: {护甲等级} | 攻击: +{攻击加值}
熟练加值: +2

━━━━━━━━━━━━━━━━━━━━━━━━━━━

✅ 回复 "确认" 创建角色
✏️ 回复 "修改属性" 重新分配属性
✏️ 回复 "修改技能" 重新选择技能
❌ 回复 "取消" 放弃创建
```

---

## 六、单指令建卡

### 6.1 格式说明

```
/dnd 创建 [职业] [种族] [背景(可选)]
```

### 6.2 示例

```
/dnd 创建 战士 人类
/dnd 创建 法师 精灵
/dnd 创建 盗贼 半身人 商人
```

### 6.3 自动流程

当用户输入单指令时：
1. 解析参数
2. 验证职业、种族存在
3. 使用默认属性分配（标准数组 15,14,13,12,10,8）
4. 自动选择职业默认技能
5. 显示角色预览
6. 提示用户确认

---

## 七、数据结构变更

### 7.1 Character 字段扩展

```python
@dataclass
class Character:
    # ... 现有字段 ...

    # 新增字段
    background: str = ""                    # 背景
    skill_proficiencies: List[str] = field(default_factory=list)  # 技能熟练
    saving_throws: List[str] = field(default_factory=list)  # 豁免熟练
    languages: List[str] = field(default_factory=list)  # 已知语言
    conditions: List[str] = field(default_factory=list)  # 状态效果
    feature: str = ""                        # 背景特性
```

### 7.2 建卡状态

```python
@dataclass
class CharacterCreationState:
    user_id: str
    step: str                                # "race"|"subrace"|"class"|"ability"|"skills"|"background"|"confirm"
    selected_race: Optional[str] = None
    selected_subrace: Optional[str] = None
    selected_class: Optional[str] = None
    selected_background: Optional[str] = None
    abilities: Optional[AbilityScores] = None
    skill_proficiencies: List[str] = field(default_factory=list)
    points_spent: int = 0
    created_at: datetime = field(default_factory=datetime.now)
```

---

## 八、实现任务清单

| 序号 | 任务 | 优先级 | 状态 |
|------|------|--------|------|
| 1 | 创建 `core/classes.py` 职业数据库 | 🔴 高 | 📋 |
| 2 | 创建 `core/races.py` 种族数据库 | 🔴 高 | 📋 |
| 3 | 创建 `core/backgrounds.py` 背景数据库 | 🔴 高 | 📋 |
| 4 | 创建 `core/character_creator.py` 建卡管理器 | 🔴 高 | 📋 |
| 5 | 修改 `core/character.py` 扩展字段 | 🔴 高 | 📋 |
| 6 | 修改 `main.py` 添加新指令 | 🔴 高 | 📋 |
| 7 | 实现交互式建卡流程 | 🔴 高 | 📋 |
| 8 | 实现单指令建卡 | 🔴 高 | 📋 |
| 9 | 实现27点购点制UI | 🔴 高 | 📋 |
| 10 | 添加职业/种族/背景列表指令 | 🟡 中 | 📋 |
| 11 | 测试验证 | 🔴 高 | 📋 |
| 12 | 更新文档 | 🟡 中 | 📋 |

---

## 九、文件变更清单

### 新增文件
- `core/classes.py` - 职业数据库
- `core/races.py` - 种族数据库
- `core/backgrounds.py` - 背景数据库
- `core/character_creator.py` - 建卡状态管理

### 修改文件
- `core/character.py` - 扩展 Character 类
- `main.py` - 添加新指令和逻辑

### 备份文件
- 每次修改前备份原文件到 `backup/`

---

## 十、验收标准

- [ ] `/dnd 建卡` 启动交互式建卡流程
- [ ] 可以选择全部12个职业
- [ ] 可以选择全部9个种族
- [ ] 可以选择全部13个背景
- [ ] 27点购点制正确计算
- [ ] 技能熟练按职业规定数量选择
- [ ] HP/AC 根据职业/种族/属性自动计算
- [ ] `/dnd 创建 战士 人类` 单指令建卡可用
- [ ] 建卡中途可取消
- [ ] 所有新指令支持中文
- [ ] 数值来源清晰说明
- [ ] 文档已更新
