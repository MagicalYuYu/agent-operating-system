"""
NPC 系统模块 - 管理深水城南区 NPC 数据和对话
"""
import json
import random
from dataclasses import dataclass, field
from typing import List, Dict, Optional
from pathlib import Path


@dataclass
class NPCDialogue:
    """NPC 对话数据"""
    greeting: List[str] = field(default_factory=list)
    relaxed: List[str] = field(default_factory=list)
    mysterious: List[str] = field(default_factory=list)
    comedic: List[str] = field(default_factory=list)
    default: List[str] = field(default_factory=list)


@dataclass
class NPC:
    """NPC 数据"""
    npc_id: str
    name: str
    title: str
    location: str
    personality: str
    greeting: str
    dialogues: NPCDialogue = field(default_factory=NPCDialogue)


class NPCDatabase:
    """NPC 数据库"""

    def __init__(self, data_path: Optional[str] = None):
        self.data_path = data_path or self._get_default_data_path()
        self.npcs: Dict[str, NPC] = {}
        self.npc_search_aliases: Dict[str, str] = {}
        self._load_data()

    def _get_default_data_path(self) -> str:
        """获取默认数据路径"""
        current_dir = Path(__file__).parent.parent
        return str(current_dir / "data" / "npc_data.json")

    def _load_data(self) -> None:
        """加载 NPC 数据"""
        try:
            with open(self.data_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            self._parse_data(data)
        except FileNotFoundError:
            raise FileNotFoundError(f"NPC 数据文件未找到: {self.data_path}")
        except json.JSONDecodeError as e:
            raise ValueError(f"NPC 数据 JSON 解析错误: {e}")

    def _parse_data(self, data: dict) -> None:
        """解析 NPC 数据"""
        for npc_id, npc_data in data.get("npcs", {}).items():
            dialogues_data = npc_data.get("dialogues", {})

            dialogues = NPCDialogue(
                greeting=dialogues_data.get("greeting", []),
                relaxed=dialogues_data.get("relaxed", []),
                mysterious=dialogues_data.get("mysterious", []),
                comedic=dialogues_data.get("comedic", []),
                default=dialogues_data.get("default", [])
            )

            self.npcs[npc_id] = NPC(
                npc_id=npc_id,
                name=npc_data.get("name", ""),
                title=npc_data.get("title", ""),
                location=npc_data.get("location", ""),
                personality=npc_data.get("personality", ""),
                greeting=npc_data.get("greeting", ""),
                dialogues=dialogues
            )

        self.npc_search_aliases = data.get("npc_search_aliases", {})

    def get_npc(self, npc_id: str) -> Optional[NPC]:
        """根据 ID 获取 NPC"""
        return self.npcs.get(npc_id)

    def get_npc_by_name(self, name: str) -> Optional[NPC]:
        """根据名称或别名获取 NPC"""
        npc_id = self.npc_search_aliases.get(name)
        if npc_id:
            return self.npcs.get(npc_id)

        for npc in self.npcs.values():
            if name in npc.name or name in npc.title:
                return npc
            if name in npc.personality:
                return npc

        return None

    def get_npcs_by_location(self, location: str) -> List[NPC]:
        """获取指定地点的所有 NPC"""
        return [npc for npc in self.npcs.values() if npc.location == location]

    def get_all_npcs(self) -> List[NPC]:
        """获取所有 NPC"""
        return list(self.npcs.values())

    def get_npc_list(self) -> List[Dict[str, str]]:
        """获取 NPC 列表"""
        result = []
        for npc in self.npcs.values():
            result.append({
                "npc_id": npc.npc_id,
                "name": npc.name,
                "title": npc.title,
                "location": npc.location
            })
        return result

    def _select_dialogue_style(self) -> str:
        """随机选择对话风格

        概率分布:
        - 轻松治愈 (relaxed): 50%
        - 惊悚灵异 (mysterious): 25%
        - 搞笑无厘头 (comedic): 25%
        """
        rand = random.random()
        if rand < 0.50:
            return "relaxed"
        elif rand < 0.75:
            return "mysterious"
        else:
            return "comedic"

    def get_greeting(self, npc_id: str) -> Optional[str]:
        """获取 NPC 问候语"""
        npc = self.get_npc(npc_id)
        if not npc:
            return None

        if npc.greetings:
            return random.choice(npc.greetings)
        return npc.greeting

    def get_dialogue(self, npc_id: str, dialogue_type: Optional[str] = None) -> Optional[str]:
        """获取 NPC 对话

        Args:
            npc_id: NPC ID
            dialogue_type: 对话类型（relaxed/mysterious/comedic/greeting/default）
                          如果为 None 则随机选择风格

        Returns:
            随机选择的对话文本
        """
        npc = self.get_npc(npc_id)
        if not npc:
            return None

        if dialogue_type is None:
            dialogue_type = self._select_dialogue_style()

        dialogues = getattr(npc.dialogues, dialogue_type, [])
        if not dialogues:
            dialogues = npc.dialogues.default

        if not dialogues:
            return npc.greeting

        return random.choice(dialogues)

    def get_dialogue_multi_style(self, npc_id: str, max_styles: int = 2) -> List[Dict[str, str]]:
        """获取多个风格的对话

        Args:
            npc_id: NPC ID
            max_styles: 最大返回的风格数量

        Returns:
            包含风格和对话的列表
        """
        npc = self.get_npc(npc_id)
        if not npc:
            return []

        styles = ["relaxed", "mysterious", "comedic"]
        selected_styles = random.sample(styles, min(max_styles, len(styles)))

        result = []
        style_names = {
            "relaxed": "☀️ 轻松治愈",
            "mysterious": "🌙 惊悚灵异",
            "comedic": "🎭 搞笑无厘头"
        }

        for style in selected_styles:
            dialogues = getattr(npc.dialogues, style, [])
            if dialogues:
                result.append({
                    "style": style,
                    "style_name": style_names.get(style, style),
                    "dialogue": random.choice(dialogues)
                })

        return result

    def get_npc_full_info(self, npc_id: str) -> Optional[Dict[str, str]]:
        """获取 NPC 完整信息"""
        npc = self.get_npc(npc_id)
        if not npc:
            return None

        return {
            "npc_id": npc.npc_id,
            "name": npc.name,
            "title": npc.title,
            "location": npc.location,
            "personality": npc.personality,
            "greeting": npc.greeting
        }

    def npc_exists(self, npc_id: str) -> bool:
        """检查 NPC 是否存在"""
        return npc_id in self.npcs
