"""
D&D 5e 职业数据库
包含全部12个基础职业的完整数据
"""
from dataclasses import dataclass, field
from typing import List, Optional, Dict
from enum import Enum


@dataclass
class DNDClass:
    """D&D 职业"""
    name_cn: str
    name_en: str
    hit_die: int
    primary_ability: List[str]
    saving_throws: List[str]
    armor_proficiencies: List[str] = field(default_factory=list)
    weapon_proficiencies: List[str] = field(default_factory=list)
    tool_proficiencies: List[str] = field(default_factory=list)
    skill_choices: int = 2
    available_skills: List[str] = field(default_factory=list)
    spellcasting_ability: Optional[str] = None
    description: str = ""
    features: List[str] = field(default_factory=list)


class ClassDatabase:
    """职业数据库"""

    CLASSES: Dict[str, DNDClass] = {
        "战士": DNDClass(
            name_cn="战士",
            name_en="Fighter",
            hit_die=10,
            primary_ability=["力量", "敏捷"],
            saving_throws=["力量", "体质"],
            armor_proficiencies=["轻甲", "中甲", "重甲", "盾牌"],
            weapon_proficiencies=["简易武器", "军用武器"],
            skill_choices=2,
            available_skills=["运动", "杂技", "驯兽", "历史", "洞察", "威吓", "察觉", "求生"],
            description="精通各种武器和装甲的战场专家，以力量和技巧统治战场。",
            features=["战斗风格", "二次攻击(5级)"]
        ),
        "法师": DNDClass(
            name_cn="法师",
            name_en="Wizard",
            hit_die=6,
            primary_ability=["智力"],
            saving_throws=["智力", "感知"],
            weapon_proficiencies=["匕首", "飞镖", "法杖", "轻弩"],
            skill_choices=2,
            available_skills=["奥秘", "历史", "洞察", "医药", "察觉", "调查"],
            spellcasting_ability="智力",
            description="通过研习神秘知识掌握强大法术的学者，擅长各种奥术魔法。",
            features=["奥术复兴", "法术书"]
        ),
        "盗贼": DNDClass(
            name_cn="盗贼",
            name_en="Rogue",
            hit_die=8,
            primary_ability=["敏捷", "魅力"],
            saving_throws=["敏捷", "智力"],
            weapon_proficiencies=["简易武器", "手弩", "长剑", "弯刀", "刺剑"],
            skill_choices=4,
            available_skills=["杂技", "巧手", "欺瞒", "隐匿", "历史", "洞察", "威吓", "察觉", "表演"],
            description="擅长潜行、偷袭和开锁的灵活专家，以敏捷和智慧取胜。",
            features=["偷袭", "专家技艺", "偷袭(5级)"]
        ),
        "牧师": DNDClass(
            name_cn="牧师",
            name_en="Cleric",
            hit_die=8,
            primary_ability=["感知", "魅力"],
            saving_throws=["感知", "魅力"],
            armor_proficiencies=["轻甲", "中甲", "重甲", "盾牌"],
            weapon_proficiencies=["简易武器"],
            skill_choices=2,
            available_skills=["历史", "洞察", "医药", "察觉", "说服", "宗教"],
            spellcasting_ability="感知",
            description="神圣力量的代言人，兼具治疗能力和战斗能力。",
            features=["神导力", "引导神力"]
        ),
        "游侠": DNDClass(
            name_cn="游侠",
            name_en="Ranger",
            hit_die=10,
            primary_ability=["敏捷", "感知"],
            saving_throws=["敏捷", "感知"],
            armor_proficiencies=["轻甲", "中甲", "盾牌"],
            weapon_proficiencies=["简易武器", "军用武器"],
            skill_choices=3,
            available_skills=["驯兽", "运动", "洞察", "调查", "自然", "察觉", "隐匿", "求生"],
            spellcasting_ability="感知",
            description="荒野的守护者，精通追踪、弓箭和自然魔法。",
            features=["宿敌", "自然探索者"]
        ),
        "圣武士": DNDClass(
            name_cn="圣武士",
            name_en="Paladin",
            hit_die=10,
            primary_ability=["力量", "魅力"],
            saving_throws=["感知", "魅力"],
            armor_proficiencies=["轻甲", "中甲", "重甲", "盾牌"],
            weapon_proficiencies=["简易武器", "军用武器"],
            skill_choices=2,
            available_skills=["运动", "洞察", "医药", "说服", "宗教", "威吓"],
            spellcasting_ability="魅力",
            description="神圣誓言的守护者，结合战士与法师的能力。",
            features=["神力感应", "宣誓"]
        ),
        "吟游诗人": DNDClass(
            name_cn="吟游诗人",
            name_en="Bard",
            hit_die=8,
            primary_ability=["魅力", "敏捷"],
            saving_throws=["敏捷", "魅力"],
            armor_proficiencies=["轻甲"],
            weapon_proficiencies=["简易武器", "长剑", "刺剑", "短剑", "手弩"],
            tool_proficiencies=["3种自选乐器"],
            skill_choices=3,
            available_skills=["杂技", "欺瞒", "隐匿", "奥秘", "驯兽", "历史", "洞察", "威吓", "医药", "察觉", "表演", "说服", "巧手"],
            spellcasting_ability="魅力",
            description="多才多艺的表演者，以音乐和言辞影响世界。",
            features=["诗人激励", "施法"]
        ),
        "野蛮人": DNDClass(
            name_cn="野蛮人",
            name_en="Barbarian",
            hit_die=12,
            primary_ability=["力量", "敏捷"],
            saving_throws=["力量", "体质"],
            armor_proficiencies=["轻甲", "中甲", "盾牌"],
            weapon_proficiencies=["简易武器", "军用武器"],
            skill_choices=2,
            available_skills=["驯兽", "运动", "威吓", "自然", "察觉", "求生"],
            description="狂暴的战士，在愤怒中释放惊人力量。",
            features=["狂暴", "无甲防御"]
        ),
        "僧侣": DNDClass(
            name_cn="僧侣",
            name_en="Monk",
            hit_die=8,
            primary_ability=["力量", "敏捷"],
            saving_throws=["力量", "敏捷"],
            weapon_proficiencies=["简易武器", "长剑", "弯刀", "短剑"],
            skill_choices=2,
            available_skills=["运动", "杂技", "历史", "洞察", "宗教", "隐匿"],
            description="精通气功的武者，以徒手格斗和敏捷身法著称。",
            features=["无甲防御", "武艺", "气功"]
        ),
        "德鲁伊": DNDClass(
            name_cn="德鲁伊",
            name_en="Druid",
            hit_die=8,
            primary_ability=["感知", "智力"],
            saving_throws=["智力", "感知"],
            armor_proficiencies=["轻甲", "中甲", "盾牌"],
            weapon_proficiencies=["匕首", "飞镖", "法杖", "硬头锤", "标枪", "月牙斧", "短弓", "长弓", "硬头锤", "战杖"],
            tool_proficiencies=["草药师工具"],
            skill_choices=2,
            available_skills=["奥秘", "驯兽", "医药", "自然", "察觉", "洞察", "宗教"],
            spellcasting_ability="感知",
            description="与自然合一的变化者，可变身动物并操控自然力量。",
            features=["德鲁伊语", "变形"]
        ),
        "术士": DNDClass(
            name_cn="术士",
            name_en="Sorcerer",
            hit_die=6,
            primary_ability=["魅力"],
            saving_throws=["体质", "魅力"],
            weapon_proficiencies=["匕首", "飞镖", "轻弩", "法杖", "细剑", "短弓"],
            skill_choices=2,
            available_skills=["奥秘", "欺瞒", "洞察", "威吓", "医药", "察觉", "宗教"],
            spellcasting_ability="魅力",
            description="天生魔法血脉的持有者，以意志力直接释放魔法。",
            features=["魔法血脉", "法术极效"]
        ),
        "奇械师": DNDClass(
            name_cn="奇械师",
            name_en="Artificer",
            hit_die=8,
            primary_ability=["智力", "体质"],
            saving_throws=["智力", "感知"],
            armor_proficiencies=["轻甲", "中甲", "盾牌"],
            weapon_proficiencies=["简易武器", "军用武器"],
            tool_proficiencies=["草药师工具", "工匠工具", "盗贼工具"],
            skill_choices=2,
            available_skills=["奥秘", "历史", "洞察", "医药", "自然", "察觉", "巧手"],
            spellcasting_ability="智力",
            description="魔法与技术融合的发明家，创造魔法装置和神器。",
            features=["魔法装置", "工具专精"]
        )
    }

    @classmethod
    def get_all_classes(cls) -> List[str]:
        """获取所有职业名称"""
        return list(cls.CLASSES.keys())

    @classmethod
    def get_class(cls, name: str) -> Optional[DNDClass]:
        """获取职业数据"""
        name = name.strip()
        if name in cls.CLASSES:
            return cls.CLASSES[name]
        for cn, cls_data in cls.CLASSES.items():
            if cls_data.name_en.lower() == name.lower():
                return cls_data
        return None

    @classmethod
    def get_class_info(cls, name: str) -> Optional[str]:
        """获取职业信息文本"""
        cls_data = cls.get_class(name)
        if not cls_data:
            return None

        info = f"⚔️ {cls_data.name_cn} ({cls_data.name_en})\n"
        info += f"━━━━━━━━━━━━━━━━━━━━\n"
        info += f"📖 {cls_data.description}\n\n"
        info += f"🎲 生命骰: d{cls_data.hit_die}\n"
        info += f"💪 主要属性: {', '.join(cls_data.primary_ability)}\n"
        info += f"🛡️ 豁免熟练: {', '.join(cls_data.saving_throws)}\n"

        if cls_data.armor_proficiencies:
            info += f"🛡️ 护甲熟练: {', '.join(cls_data.armor_proficiencies)}\n"
        if cls_data.weapon_proficiencies:
            info += f"⚔️ 武器熟练: {', '.join(cls_data.weapon_proficiencies)}\n"

        info += f"\n🎯 可选技能数: {cls_data.skill_choices}项\n"
        info += f"📋 可选技能: {', '.join(cls_data.available_skills)}\n"

        if cls_data.spellcasting_ability:
            info += f"✨ 法术施法: {cls_data.spellcasting_ability}\n"

        return info

    @classmethod
    def get_skill_choices(cls, class_name: str) -> int:
        """获取职业可选技能数量"""
        cls_data = cls.get_class(class_name)
        return cls_data.skill_choices if cls_data else 2

    @classmethod
    def get_available_skills(cls, class_name: str) -> List[str]:
        """获取职业可选技能列表"""
        cls_data = cls.get_class(class_name)
        return cls_data.available_skills if cls_data else []

    @classmethod
    def calculate_hp(cls, class_name: str, con_mod: int, level: int = 1) -> int:
        """计算初始HP"""
        cls_data = cls.get_class(class_name)
        if not cls_data:
            return 10 + con_mod

        base_hp = cls_data.hit_die + con_mod
        return base_hp
