"""
D&D/Zero 完整战斗系统
独立的战斗上下文，独立于普通指令系统
"""
import random
import uuid
from dataclasses import dataclass, field
from typing import List, Optional, Dict, Tuple, Any
from enum import Enum
import copy

from .combat_position import AttackRange, MELEE_RANGE, RANGED_RANGE, PIERCE_RANGE
from .combat_unit import CombatUnit, PlayerUnit, MonsterUnit
from .combat_skill import Skill, SkillDatabase
from .battle_arena import WATERDEEP_ARENA_MONSTERS, Difficulty


class CombatPhase(Enum):
    """战斗阶段"""
    WAITING = "waiting"           # 等待开始
    INITIATIVE = "initiative"      # 先攻排序中
    PLAYER_TURN = "player_turn"   # 玩家回合
    ENEMY_TURN = "enemy_turn"    # 敌人回合
    ROUND_END = "round_end"       # 回合结束
    COMBAT_END = "combat_end"     # 战斗结束


class CombatCommand(Enum):
    """战斗指令类型"""
    ATTACK = "attack"             # 攻击
    SKILL = "skill"               # 技能
    CAST = "cast"                 # 施法
    ITEM = "item"                 # 物品
    DEFEND = "defend"             # 防御
    DODGE = "dodge"               # 躲避
    SWAP = "swap"                 # 换位
    FLEE = "flee"                 # 逃跑
    WAIT = "wait"                 # 等待
    END_TURN = "end_turn"         # 结束回合


@dataclass
class CombatFighter:
    """战斗参与者"""
    fighter_id: str
    name: str                      # 角色名
    sender_id: str                 # QQ用户ID
    sender_name: str               # QQ昵称
    
    position: int = 1
    original_position: int = 1
    initiative: int = 0
    
    max_hp: int = 10
    current_hp: int = 10
    armor_class: int = 10
    
    attack_bonus: int = 0
    damage_dice: str = "1d6"
    damage_bonus: int = 0
    attack_range: AttackRange = field(default_factory=lambda: MELEE_RANGE)
    
    abilities: Dict[str, int] = field(default_factory=lambda: {
        "strength": 10, "dexterity": 10, "constitution": 10,
        "intelligence": 10, "wisdom": 10, "charisma": 10
    })
    
    spell_slots: Dict[int, int] = field(default_factory=dict)
    prepared_spells: List[str] = field(default_factory=list)
    
    conditions: List[str] = field(default_factory=list)
    concentration_spell: Optional[str] = None
    
    action_used: bool = False
    bonus_action_used: bool = False
    reaction_available: bool = True
    movement_used: bool = False
    
    defending: bool = False
    dodging: bool = False
    
    death_saves: Dict[str, int] = field(default_factory=lambda: {"success": 0, "fail": 0})
    is_unconscious: bool = False
    is_dead: bool = False
    is_enemy: bool = False
    
    def get_modifier(self, ability: str) -> int:
        score = self.abilities.get(ability, 10)
        return (score - 10) // 2
    
    def get_effective_ac(self) -> int:
        ac = self.armor_class
        if self.defending:
            ac += 2
        if self.dodging:
            ac += 2
        return ac
    
    def reset_turn(self):
        self.action_used = False
        self.bonus_action_used = False
        self.reaction_available = True
        self.movement_used = False
        self.defending = False
        self.dodging = False


class CombatContext:
    """战斗上下文管理器"""
    
    def __init__(self, group_id: str):
        self.combat_id: str = str(uuid.uuid4())[:8].upper()
        self.group_id: str = group_id
        
        self.phase: CombatPhase = CombatPhase.WAITING
        
        self.allies: Dict[str, CombatFighter] = {}
        self.enemies: Dict[str, CombatFighter] = {}
        
        self.initiative_order: List[CombatFighter] = []
        self.current_turn_index: int = 0
        self.round_number: int = 1
        
        self.selected_difficulty: Optional[Difficulty] = None
        self.entry_states: Dict[str, Dict] = {}
        
        self.battle_log: List[Dict] = []
        
    def add_ally(self, fighter: CombatFighter) -> bool:
        """添加友方单位"""
        if len(self.allies) >= 4:
            return False
        fighter.is_enemy = False
        fighter.position = len(self.allies) + 1
        fighter.original_position = fighter.position
        self.allies[fighter.fighter_id] = fighter
        return True
    
    def add_enemy(self, fighter: CombatFighter) -> bool:
        """添加敌方单位"""
        if len(self.enemies) >= 4:
            return False
        fighter.is_enemy = True
        fighter.position = len(self.enemies) + 1
        fighter.original_position = fighter.position
        self.enemies[fighter.fighter_id] = fighter
        return True
    
    def get_fighter(self, fighter_id: str) -> Optional[CombatFighter]:
        """获取战斗单位"""
        return self.allies.get(fighter_id) or self.enemies.get(fighter_id)
    
    def get_fighter_by_sender(self, sender_id: str) -> Optional[CombatFighter]:
        """通过发送者ID获取战斗单位"""
        for fighter in self.allies.values():
            if fighter.sender_id == sender_id:
                return fighter
        return None
    
    def get_current_fighter(self) -> Optional[CombatFighter]:
        """获取当前回合单位"""
        if 0 <= self.current_turn_index < len(self.initiative_order):
            return self.initiative_order[self.current_turn_index]
        return None
    
    def get_alive_allies(self) -> List[CombatFighter]:
        """获取存活友方"""
        return [f for f in self.allies.values() if not f.is_dead and not f.is_unconscious]
    
    def get_alive_enemies(self) -> List[CombatFighter]:
        """获取存活敌方"""
        return [f for f in self.enemies.values() if not f.is_dead and not f.is_unconscious]
    
    def roll_initiative(self):
        """投先攻"""
        self.initiative_order = list(self.allies.values()) + list(self.enemies.values())
        
        for fighter in self.initiative_order:
            dex_mod = fighter.get_modifier("dexterity")
            roll = random.randint(1, 20)
            fighter.initiative = roll + dex_mod
        
        self.initiative_order.sort(key=lambda x: x.initiative, reverse=True)
        self.current_turn_index = 0
        self.phase = CombatPhase.PLAYER_TURN
        self.round_number = 1
    
    def next_turn(self):
        """进入下一回合"""
        current = self.get_current_fighter()
        if current:
            current.reset_turn()
            
            if current.is_unconscious:
                self._process_death_save(current)
        
        self.current_turn_index += 1
        
        if self.current_turn_index >= len(self.initiative_order):
            self.current_turn_index = 0
            self.round_number += 1
        
        self._check_combat_end()
    
    def _process_death_save(self, fighter: CombatFighter):
        """处理死亡豁免"""
        roll = random.randint(1, 20)
        
        if roll == 20:
            fighter.is_unconscious = False
            fighter.current_hp = 1
            self._log_event("death_save", {
                "fighter": fighter.name,
                "roll": roll,
                "result": "大成功！立即苏醒"
            })
            return
        
        if roll == 1:
            fighter.death_saves["fail"] += 2
        else:
            dc = 10
            save_roll = roll + fighter.get_modifier("constitution")
            if save_roll >= dc:
                fighter.death_saves["success"] += 1
            else:
                fighter.death_saves["fail"] += 1
        
        if fighter.death_saves["success"] >= 3:
            fighter.is_unconscious = False
            fighter.current_hp = 1
            fighter.conditions.append("倒地")
            self._log_event("death_save", {
                "fighter": fighter.name,
                "result": "稳定存活！"
            })
        elif fighter.death_saves["fail"] >= 3:
            fighter.is_dead = True
            self._log_event("death_save", {
                "fighter": fighter.name,
                "result": "死亡！"
            })
    
    def take_damage(self, fighter: CombatFighter, damage: int) -> Dict:
        """受到伤害"""
        result = {"original_damage": damage, "actual_damage": damage, "killed": False}
        
        fighter.current_hp -= damage
        result["actual_damage"] = damage
        
        if fighter.current_hp <= 0:
            fighter.current_hp = 0
            fighter.is_unconscious = True
            if "昏迷" not in fighter.conditions:
                fighter.conditions.append("昏迷")
            result["killed"] = True
        
        self._log_event("damage", {
            "target": fighter.name,
            "damage": damage,
            "remaining_hp": fighter.current_hp
        })
        
        return result
    
    def heal(self, fighter: CombatFighter, amount: int) -> int:
        """治疗"""
        old_hp = fighter.current_hp
        fighter.current_hp = min(fighter.max_hp, fighter.current_hp + amount)
        healed = fighter.current_hp - old_hp
        
        if fighter.is_unconscious and fighter.current_hp > 0:
            fighter.is_unconscious = False
            if "昏迷" in fighter.conditions:
                fighter.conditions.remove("昏迷")
        
        self._log_event("heal", {
            "target": fighter.name,
            "amount": healed
        })
        
        return healed
    
    def can_act(self, fighter: CombatFighter, action_type: str) -> Tuple[bool, str]:
        """检查是否可以执行动作"""
        if fighter.is_dead:
            return False, "该单位已死亡"
        
        if fighter.is_unconscious:
            return False, "该单位已昏迷"
        
        if action_type == "action":
            if fighter.action_used:
                return False, "本回合已使用动作"
        elif action_type == "bonus_action":
            if fighter.bonus_action_used:
                return False, "本回合已使用附赠动作"
        elif action_type == "movement":
            if fighter.movement_used:
                return False, "本回合已使用移动"
        
        return True, ""
    
    def execute_attack(self, attacker: CombatFighter, target_pos: int) -> Dict:
        """执行攻击"""
        can_act, msg = self.can_act(attacker, "action")
        if not can_act:
            return {"success": False, "message": msg}
        
        enemies = self.get_alive_enemies()
        if not enemies:
            return {"success": False, "message": "没有可攻击的目标"}
        
        if target_pos < 1 or target_pos > len(enemies):
            return {"success": False, "message": f"无效的目标位置: {target_pos}"}
        
        target = enemies[target_pos - 1]
        
        attack_roll = random.randint(1, 20)
        attack_total = attack_roll + attacker.attack_bonus
        target_ac = target.get_effective_ac()
        
        is_crit = (attack_roll == 20)
        is_fumble = (attack_roll == 1)
        
        hit = is_crit or (not is_fumble and attack_total >= target_ac)
        
        result = {
            "success": True,
            "attacker": attacker.name,
            "attacker_name": attacker.sender_name,
            "target": target.name,
            "attack_roll": attack_roll,
            "attack_bonus": attacker.attack_bonus,
            "attack_total": attack_total,
            "target_ac": target_ac,
            "hit": hit,
            "critical": is_crit,
            "fumble": is_fumble,
            "damage": 0
        }
        
        if hit:
            damage = self._roll_damage(attacker.damage_dice, attacker.damage_bonus, is_crit)
            damage_result = self.take_damage(target, damage)
            result["damage"] = damage
            result["killed"] = damage_result.get("killed", False)
        
        attacker.action_used = True
        
        self._log_event("attack", result)
        
        return result
    
    def _roll_damage(self, dice: str, bonus: int = 0, critical: bool = False) -> int:
        """投伤害骰"""
        import re
        
        total = 0
        parts = dice.replace("+", " ").replace("-", " -").split()
        
        for part in parts:
            if 'd' in part:
                match = re.match(r'(\d+)d(\d+)', part)
                if match:
                    count = int(match.group(1))
                    sides = int(match.group(2))
                    for _ in range(count):
                        total += random.randint(1, sides)
                    if critical:
                        for _ in range(count):
                            total += random.randint(1, sides)
            else:
                try:
                    total += int(part)
                except ValueError:
                    pass
        
        return total + bonus
    
    def execute_defend(self, fighter: CombatFighter) -> Dict:
        """执行防御"""
        can_act, msg = self.can_act(fighter, "action")
        if not can_act:
            return {"success": False, "message": msg}
        
        fighter.action_used = True
        fighter.defending = True
        
        self._log_event("defend", {"fighter": fighter.name})
        
        return {"success": True, "message": f"{fighter.name}进入防御姿态"}
    
    def execute_dodge(self, fighter: CombatFighter) -> Dict:
        """执行躲避"""
        can_act, msg = self.can_act(fighter, "action")
        if not can_act:
            return {"success": False, "message": msg}
        
        fighter.action_used = True
        fighter.dodging = True
        
        self._log_event("dodge", {"fighter": fighter.name})
        
        return {"success": True, "message": f"{fighter.name}专注闪避"}
    
    def swap_position(self, fighter: CombatFighter, new_pos: int) -> Dict:
        """交换位置"""
        if fighter in self.allies.values():
            others = list(self.allies.values())
        else:
            others = list(self.enemies.values())
        
        target = None
        for f in others:
            if f.position == new_pos and f.fighter_id != fighter.fighter_id:
                target = f
                break
        
        if target:
            old_pos = fighter.position
            fighter.position, target.position = target.position, old_pos
            self._log_event("swap", {
                "fighter": fighter.name,
                "from": old_pos,
                "to": new_pos
            })
            return {"success": True, "message": f"{fighter.name}与{target.name}交换位置"}
        else:
            return {"success": False, "message": f"{new_pos}号位没有可交换的单位"}
    
    def _check_combat_end(self) -> Optional[str]:
        """检查战斗是否结束"""
        allies_alive = len(self.get_alive_allies())
        enemies_alive = len(self.get_alive_enemies())
        
        if allies_alive == 0:
            self.phase = CombatPhase.COMBAT_END
            self._log_event("combat_end", {"result": "defeat"})
            return "defeat"
        
        if enemies_alive == 0:
            self.phase = CombatPhase.COMBAT_END
            self._log_event("combat_end", {"result": "victory"})
            return "victory"
        
        return None
    
    def _log_event(self, event_type: str, data: Dict):
        """记录事件"""
        self.battle_log.append({
            "type": event_type,
            "data": data,
            "round": self.round_number
        })
    
    def get_battlefield_display(self) -> str:
        """获取战场显示"""
        text = "⚔️ **战斗状态** ⚔️\n"
        text += "━━━━━━━━━━━━━━━━━━━━\n"
        text += f"📅 **回合**: 第{self.round_number}轮\n\n"
        
        text += self._get_position_display()
        
        allies_alive = len(self.get_alive_allies())
        enemies_alive = len(self.get_alive_enemies())
        text += f"\n**【单位统计】**: 我方存活 {allies_alive} | 敌方存活 {enemies_alive}\n"
        
        return text
    
    def get_attack_targets_display(self, attacker: CombatFighter) -> str:
        """获取可攻击目标列表"""
        enemies = self.get_alive_enemies()
        
        if not enemies:
            return "⚠️ 没有可攻击的目标"
        
        text = "🎯 **可攻击目标**\n"
        text += "━━━━━━━━━━━━━━━━━━━━\n"
        
        for i, enemy in enumerate(enemies):
            target_pos = i + 1
            hp_bar = self._generate_hp_bar(enemy.current_hp, enemy.max_hp, length=4)
            text += f"  **{target_pos}号位** ⚔️ {enemy.name}\n"
            text += f"        HP: {hp_bar} {enemy.current_hp}/{enemy.max_hp} | AC: {enemy.get_effective_ac()}\n"
        
        return text
    
    def _get_fighter_status(self, fighter: CombatFighter) -> str:
        """获取单位状态字符串"""
        if fighter.is_dead:
            return f"[💀 死亡 HP:0/{fighter.max_hp}]"
        elif fighter.is_unconscious:
            ds = fighter.death_saves
            return f"[😵 昏迷 HP:0/{fighter.max_hp} 豁免:✓{ds['success']}/✗{ds['fail']}]"
        else:
            hp_bar = self._generate_hp_bar(fighter.current_hp, fighter.max_hp)
            return f"[HP:{hp_bar} AC:{fighter.get_effective_ac()}]"
    
    @staticmethod
    def _generate_hp_bar(current: int, maximum: int, length: int = 5) -> str:
        """生成HP条"""
        if maximum <= 0:
            return "-----"
        
        ratio = current / maximum
        filled = int(ratio * length)
        empty = length - filled
        
        return f"{'█' * filled}{'░' * empty}"
    
    def get_action_menu(self, fighter: CombatFighter) -> str:
        """获取动作菜单"""
        text = f"📋 **{fighter.name}** - 选择动作\n"
        text += "━━━━━━━━━━━━━━━━━━━━\n"
        
        if fighter.action_used:
            text += "📌 **动作** (已使用)\n"
        else:
            text += "📌 **动作**\n"
            text += "  攻击 <目标> - 普通攻击\n"
            text += "  防御 - 防御姿态(AC+2)\n"
            text += "  躲避 - 专注闪避\n"
        
        if fighter.bonus_action_used:
            text += "\n⚡ **附赠动作** (已使用)\n"
        else:
            text += "\n⚡ **附赠动作**\n"
            text += "  治疗真言 <目标> - 治疗盟友\n"
        
        if fighter.reaction_available:
            text += "\n🔄 **反应** (可用)\n"
        else:
            text += "\n🔄 **反应** (已使用)\n"
        
        if not fighter.action_used and not fighter.bonus_action_used:
            text += "\n⏭️ **跳过** - 结束回合\n"
        
        return text
    
    def get_combat_start_display(self) -> str:
        """获取战斗开始显示"""
        allies = list(self.allies.values())
        enemies = list(self.enemies.values())
        
        text = "⚔️ **战斗开始！** ⚔️\n"
        text += "━━━━━━━━━━━━━━━━━━━━\n"
        text += f"📅 **回合**: 第 {self.round_number} 轮\n\n"
        
        text += self._get_position_display()
        
        text += "\n**【先攻顺序】**\n"
        for i, f in enumerate(self.initiative_order):
            marker = "→" if i == self.current_turn_index else " "
            dead_marker = "💀 " if f.is_dead else ("😵 " if f.is_unconscious else "  ")
            text += f"  {marker}{dead_marker}{i+1}. **{f.name}** (先攻:{f.initiative})\n"
        
        return text
    
    def _get_position_display(self) -> str:
        """获取4号位站位可视化"""
        allies = list(self.allies.values())
        enemies = list(self.enemies.values())
        
        text = "**【战场站位】**\n"
        text += "━━━━━━━━━━━━━━━━━━━━\n"
        
        ally_positions = {f.position: f for f in allies}
        enemy_positions = {f.position: f for f in enemies}
        
        for pos in [4, 3, 2, 1]:
            ally = ally_positions.get(pos)
            enemy = enemy_positions.get(pos)
            
            if ally:
                hp_display = f"{ally.current_hp}/{ally.max_hp}"
                hp_bar = self._generate_hp_bar(ally.current_hp, ally.max_hp, length=4)
                if ally.is_dead:
                    line = f"  {pos}号位 💀 **{ally.name}** | HP: {hp_bar} {hp_display}"
                elif ally.is_unconscious:
                    line = f"  {pos}号位 😵 **{ally.name}** | HP: {hp_bar} {hp_display}"
                elif ally.action_used:
                    line = f"→{pos}号位 🛡️ **{ally.name}** | HP: {hp_bar} {hp_display}"
                else:
                    line = f"→{pos}号位 ⚔️ **{ally.name}** | HP: {hp_bar} {hp_display}"
            else:
                line = f"  {pos}号位 ⚪ 空"
            
            if enemy:
                hp_display = f"{enemy.current_hp}/{enemy.max_hp}"
                hp_bar = self._generate_hp_bar(enemy.current_hp, enemy.max_hp, length=4)
                if enemy.is_dead:
                    line += f"          {pos}号位 💀 **{enemy.name}** | HP: {hp_bar} {hp_display}"
                elif enemy.is_unconscious:
                    line += f"          {pos}号位 😵 **{enemy.name}** | HP: {hp_bar} {hp_display}"
                else:
                    line += f"          {pos}号位 ⚔️ **{enemy.name}** | HP: {hp_bar} {hp_display}"
            else:
                line += f"          {pos}号位 ⚪ 空"
            
            text += line + "\n"
        
        text += "\n📌 **站位说明**: → 标记表示当前可行动角色\n"
        text += "⚔️ 攻击范围: 近战(1-2号位) / 远程(1-4号位)\n"
        
        return text


class CombatManager:
    """全局战斗管理器"""
    
    def __init__(self):
        self.active_combats: Dict[str, CombatContext] = {}
    
    def create_combat(self, group_id: str) -> CombatContext:
        """创建战斗"""
        if group_id in self.active_combats:
            del self.active_combats[group_id]
        
        ctx = CombatContext(group_id)
        self.active_combats[group_id] = ctx
        return ctx
    
    def get_combat(self, group_id: str) -> Optional[CombatContext]:
        """获取战斗"""
        return self.active_combats.get(group_id)
    
    def has_active_combat(self, group_id: str) -> bool:
        """检查是否有进行中的战斗"""
        ctx = self.active_combats.get(group_id)
        return ctx is not None and ctx.phase != CombatPhase.COMBAT_END
    
    def end_combat(self, group_id: str):
        """结束战斗"""
        if group_id in self.active_combats:
            del self.active_combats[group_id]


COMBAT_MANAGER = CombatManager()
