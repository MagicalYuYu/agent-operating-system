# AstrBot 插件开发完整教程

> 本教程整理自 AstrBot 官方文档，适用于 AI 学习 AstrBot 插件开发方法。

---

## 一、AstrBot 简介

AstrBot 是一个 Agentic AI 助手，支持连接 QQ、企业微信、飞书、Telegram、Discord 等多个聊天平台，具有高度可扩展的插件系统，支持 OpenAI、Anthropic、Gemini 等多种大模型接入，内置知识库和 Agent 智能体能力。

---

## 二、开发环境准备

### 2.1 前置要求

1. 有一定的 Python 编程经验
2. 有一定的 Git、GitHub 使用经验

### 2.2 获取插件模板

1. 打开 AstrBot 插件模板: [helloworld](https://github.com/Soulter/helloworld)
2. 点击右上角 `Use this template` → `Create new repository`
3. 填写插件名（格式要求）：
   - 推荐以 `astrbot_plugin_` 开头
   - 不能包含空格
   - 保持全部字母小写
   - 尽量简短
4. 点击 `Create repository`

### 2.3 克隆项目到本地

```bash
git clone https://github.com/AstrBotDevs/AstrBot
mkdir -p AstrBot/data/plugins
cd AstrBot/data/plugins
git clone <插件仓库地址>
```

### 2.4 插件目录结构

```
astrbot_plugin_xxx/
├── main.py              # 插件主文件（必须）
├── metadata.yaml        # 插件元数据（必须）
├── requirements.txt     # 依赖管理（可选）
├── logo.png            # 插件Logo（可选）
├── _conf_schema.json   # 配置定义（可选）
├── pages/              # 前端页面（可选）
│   └── <page_name>/
│       └── index.html
├── skills/             # Skills目录（可选）
│   └── SKILL.md
└── .astrbot-plugin/    # 国际化（可选）
    └── i18n/
        ├── zh-CN.json
        └── en-US.json
```

### 2.5 metadata.yaml 配置

```yaml
name: astrbot_plugin_xxx        # 插件名称
desc: 插件描述                   # 插件描述
version: v1.0.0                 # 版本号
author: your_name               # 作者
repo: https://github.com/xxx    # 仓库地址
display_name: 插件展示名         # 展示名（可选）
short_desc: 一句话介绍           # 短描述（可选）
support_platforms:              # 支持平台（可选）
  - telegram
  - discord
astrbot_version: ">=4.16,<5"    # 版本范围（可选）
```

### 2.6 调试插件

- 启动 AstrBot 本体
- 代码修改后，在 WebUI 插件管理处点击 `重载插件`
- 支持热重载功能

---

## 三、插件基础架构

### 3.1 最小实例

```python
from astrbot.api.event import filter, AstrMessageEvent, MessageEventResult
from astrbot.api.star import Context, Star, register
from astrbot.api import logger

class MyPlugin(Star):
    def __init__(self, context: Context):
        super().__init__(context)

    @filter.command("helloworld")
    async def helloworld(self, event: AstrMessageEvent):
        '''这是一个 hello world 指令'''
        user_name = event.get_sender_name()
        message_str = event.message_str
        logger.info("触发hello world指令!")
        yield event.plain_result(f"Hello, {user_name}!")

    async def terminate(self):
        '''插件卸载/停用时调用'''
        pass
```

### 3.2 核心类说明

| 类名 | 说明 |
|------|------|
| `Star` | 插件基类，所有插件必须继承此类 |
| `Context` | 插件与 AstrBot Core 交互的上下文对象 |
| `AstrMessageEvent` | 消息事件对象，包含发送者、消息内容等信息 |
| `AstrBotMessage` | 消息对象，存储消息平台下发的具体内容 |

### 3.3 AstrBotMessage 结构

```python
class AstrBotMessage:
    type: MessageType           # 消息类型
    self_id: str               # 机器人ID
    session_id: str            # 会话ID
    message_id: str            # 消息ID
    group_id: str = ""         # 群组ID（私聊为空）
    sender: MessageMember      # 发送者
    message: List[BaseMessageComponent]  # 消息链
    message_str: str           # 纯文本消息
    raw_message: object        # 原始消息对象
    timestamp: int             # 消息时间戳
```

---

## 四、消息链与消息组件

### 4.1 消息链概念

消息链是一个有序列表，每个元素称为消息段。常见消息段类型：

| 类型 | 说明 |
|------|------|
| `Plain` | 文本消息段 |
| `At` | 提及消息段 |
| `Image` | 图片消息段 |
| `Record` | 语音消息段 |
| `Video` | 视频消息段 |
| `File` | 文件消息段 |
| `Face` | 表情消息段（OneBot v11） |
| `Node` | 合并转发节点 |
| `Poke` | 戳一戳消息段 |

### 4.2 消息组件导入

```python
import astrbot.api.message_components as Comp
```

### 4.3 消息链示例

```python
chain = [
    Comp.At(qq=event.get_sender_id()),
    Comp.Plain("来看这个图："),
    Comp.Image.fromURL("https://example.com/image.jpg"),
    Comp.Image.fromFileSystem("path/to/image.jpg"),
    Comp.Plain("这是一个图片。")
]
```

### 4.4 平台适配矩阵

| 平台 | At | Plain | Image | Record | Video | Reply | 主动消息 |
|------|----|----|----|----|----|----|----|
| QQ 个人号(aiocqhttp) | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| Telegram | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| QQ 官方接口 | ❌ | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ |
| 飞书 | ✅ | ✅ | ✅ | ❌ | ❌ | ✅ | ✅ |
| 企业微信 | ❌ | ✅ | ✅ | ✅ | ❌ | ❌ | ❌ |
| 钉钉 | ❌ | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ |

---

## 五、指令系统

### 5.1 基本指令

```python
@filter.command("helloworld")
async def helloworld(self, event: AstrMessageEvent):
    '''这是 hello world 指令'''
    yield event.plain_result("Hello!")
```

### 5.2 带参指令

```python
@filter.command("add")
async def add(self, event: AstrMessageEvent, a: int, b: int):
    # /add 1 2 -> 结果是: 3
    yield event.plain_result(f"结果是: {a + b}")
```

### 5.3 指令组

```python
@filter.command_group("math")
def math(self):
    pass

@math.command("add")
async def add(self, event: AstrMessageEvent, a: int, b: int):
    # /math add 1 2
    yield event.plain_result(f"结果是: {a + b}")

@math.command("sub")
async def sub(self, event: AstrMessageEvent, a: int, b: int):
    # /math sub 1 2
    yield event.plain_result(f"结果是: {a - b}")
```

### 5.4 嵌套指令组

```python
@filter.command_group("math")
def math():
    pass

@math.group("calc")  # 注意：这里是 group，而不是 command_group
def calc():
    pass

@calc.command("add")
async def add(self, event: AstrMessageEvent, a: int, b: int):
    yield event.plain_result(f"结果是: {a + b}")
```

### 5.5 指令别名

```python
@filter.command("help", alias={'帮助', 'helpme'})
def help(self, event: AstrMessageEvent):
    yield event.plain_result("帮助信息")
```

---

## 六、事件过滤器

### 6.1 导入过滤器

```python
from astrbot.api.event import filter, AstrMessageEvent
```

### 6.2 事件类型过滤

```python
# 接收所有消息
@filter.event_message_type(filter.EventMessageType.ALL)
async def on_all_message(self, event: AstrMessageEvent):
    yield event.plain_result("收到了一条消息。")

# 只接收私聊消息
@filter.event_message_type(filter.EventMessageType.PRIVATE_MESSAGE)
async def on_private_message(self, event: AstrMessageEvent):
    yield event.plain_result("收到了一条私聊消息。")

# 只接收群聊消息
@filter.event_message_type(filter.EventMessageType.GROUP_MESSAGE)
async def on_group_message(self, event: AstrMessageEvent):
    yield event.plain_result("收到了一条群聊消息。")
```

### 6.3 平台过滤

```python
@filter.platform_adapter_type(filter.PlatformAdapterType.AIOCQHTTP | filter.PlatformAdapterType.QQOFFICIAL)
async def on_aiocqhttp(self, event: AstrMessageEvent):
    '''只接收 AIOCQHTTP 和 QQOFFICIAL 的消息'''
    yield event.plain_result("收到了一条信息")
```

### 6.4 权限过滤

```python
@filter.permission_type(filter.PermissionType.ADMIN)
@filter.command("test")
async def test(self, event: AstrMessageEvent):
    pass  # 仅管理员可用
```

### 6.5 多个过滤器组合

```python
@filter.command("helloworld")
@filter.event_message_type(filter.EventMessageType.PRIVATE_MESSAGE)
async def helloworld(self, event: AstrMessageEvent):
    yield event.plain_result("你好！")
```

### 6.6 优先级设置

```python
@filter.command("helloworld", priority=1)
async def helloworld(self, event: AstrMessageEvent):
    yield event.plain_result("Hello!")
```

---

## 七、事件钩子

### 7.1 Bot 初始化完成

```python
@filter.on_astrbot_loaded()
async def on_astrbot_loaded(self):
    print("AstrBot 初始化完成")
```

### 7.2 LLM 请求钩子

```python
from astrbot.api.provider import ProviderRequest

@filter.on_llm_request()
async def my_custom_hook(self, event: AstrMessageEvent, req: ProviderRequest):
    print(req)
    # 追加动态上下文（推荐方式）
    from astrbot.core.agent.message import TextPart
    req.extra_user_content_parts.append(
        TextPart(text="<dynamic_context>当前时间：2026-05-03</dynamic_context>")
    )
```

### 7.3 LLM 响应钩子

```python
from astrbot.api.provider import LLMResponse

@filter.on_llm_response()
async def on_llm_resp(self, event: AstrMessageEvent, resp: LLMResponse):
    print(resp)
```

### 7.4 Agent 生命周期钩子

```python
# Agent 开始运行
@filter.on_agent_begin()
async def on_agent_begin(self, event: AstrMessageEvent, run_context):
    print("Agent 开始运行")

# Agent 运行完成
@filter.on_agent_done()
async def on_agent_done(self, event: AstrMessageEvent, run_context, resp: LLMResponse):
    print(resp)
```

### 7.5 工具调用钩子

```python
from astrbot.core.agent.tool import FunctionTool

@filter.on_using_llm_tool()
async def on_using_llm_tool(self, event: AstrMessageEvent, tool: FunctionTool, tool_args: dict):
    print(tool.name, tool_args)

@filter.on_llm_tool_respond()
async def on_llm_tool_respond(self, event: AstrMessageEvent, tool: FunctionTool, tool_args: dict, tool_result):
    print(tool.name, tool_args, tool_result)
```

### 7.6 消息发送钩子

```python
# 发送消息前
@filter.on_decorating_result()
async def on_decorating_result(self, event: AstrMessageEvent):
    result = event.get_result()
    chain = result.chain
    chain.append(Comp.Plain("!"))

# 发送消息后
@filter.after_message_sent()
async def after_message_sent(self, event: AstrMessageEvent):
    pass
```

---

## 八、消息发送

### 8.1 被动消息

```python
@filter.command("helloworld")
async def helloworld(self, event: AstrMessageEvent):
    yield event.plain_result("Hello!")
    yield event.image_result("path/to/image.jpg")
    yield event.image_result("https://example.com/image.jpg")
```

### 8.2 主动消息

```python
from astrbot.api.event import MessageChain

@filter.command("helloworld")
async def helloworld(self, event: AstrMessageEvent):
    umo = event.unified_msg_origin
    message_chain = MessageChain().message("Hello!").file_image("path/to/image.jpg")
    await self.context.send_message(umo, message_chain)
```

### 8.3 富媒体消息

```python
@filter.command("helloworld")
async def helloworld(self, event: AstrMessageEvent):
    chain = [
        Comp.At(qq=event.get_sender_id()),
        Comp.Plain("来看这个图："),
        Comp.Image.fromURL("https://example.com/image.jpg"),
        Comp.Image.fromFileSystem("path/to/image.jpg"),
    ]
    yield event.chain_result(chain)
```

### 8.4 发送视频

```python
from astrbot.api.message_components import Video

@filter.command("test")
async def test(self, event: AstrMessageEvent):
    video = Video.fromFileSystem(path="test.mp4")
    # 或
    video = Video.fromURL(url="https://example.com/video.mp4")
    yield event.chain_result([video])
```

### 8.5 发送合并转发消息

```python
from astrbot.api.message_components import Node, Plain, Image

@filter.command("test")
async def test(self, event: AstrMessageEvent):
    node = Node(
        uin=905617992,
        name="Soulter",
        content=[
            Plain("hi"),
            Image.fromFileSystem("test.jpg")
        ]
    )
    yield event.chain_result([node])
```

---

## 九、AI/LLM 集成

### 9.1 获取当前会话的聊天模型 ID

```python
umo = event.unified_msg_origin
provider_id = await self.context.get_current_chat_provider_id(umo=umo)
```

### 9.2 调用大模型

```python
llm_resp = await self.context.llm_generate(
    chat_provider_id=provider_id,
    prompt="Hello, world!",
)
# print(llm_resp.completion_text)
```

### 9.3 定义 Tool

```python
from pydantic import Field
from pydantic.dataclasses import dataclass
from astrbot.core.agent.run_context import ContextWrapper
from astrbot.core.agent.tool import FunctionTool, ToolExecResult
from astrbot.core.astr_agent_context import AstrAgentContext

@dataclass
class BilibiliTool(FunctionTool[AstrAgentContext]):
    name: str = "bilibili_videos"
    description: str = "A tool to fetch Bilibili videos."
    parameters: dict = Field(
        default_factory=lambda: {
            "type": "object",
            "properties": {
                "keywords": {
                    "type": "string",
                    "description": "Keywords to search for Bilibili videos.",
                },
            },
            "required": ["keywords"],
        }
    )

    async def call(
        self, context: ContextWrapper[AstrAgentContext], **kwargs
    ) -> ToolExecResult:
        return "1. 视频标题：如何使用AstrBot\n视频链接：xxxxxx"
```

### 9.4 注册 Tool

```python
class MyPlugin(Star):
    def __init__(self, context: Context):
        super().__init__(context)
        self.context.add_llm_tools(BilibiliTool())
```

### 9.5 装饰器方式定义 Tool

```python
@filter.llm_tool(name="get_weather")
async def get_weather(self, event: AstrMessageEvent, location: str) -> MessageEventResult:
    '''获取天气信息。

    Args:
        location(string): 地点
    '''
    resp = self.get_weather_from_api(location)
    yield event.plain_result("天气信息: " + resp)
```

### 9.6 调用 Agent

```python
llm_resp = await self.context.tool_loop_agent(
    event=event,
    chat_provider_id=prov_id,
    prompt="搜索一下 bilibili 上关于 AstrBot 的相关视频。",
    tools=ToolSet([BilibiliTool()]),
    max_steps=30,
    tool_call_timeout=60,
)
```

---

## 十、配置管理

### 10.1 配置定义 (_conf_schema.json)

```json
{
    "token": {
        "description": "Bot Token",
        "type": "string",
        "hint": "请输入您的 Bot Token",
        "obvious_hint": true
    },
    "enable": {
        "description": "启用插件",
        "type": "bool",
        "default": true
    },
    "count": {
        "description": "数量",
        "type": "int",
        "default": 10
    },
    "rate": {
        "description": "比率",
        "type": "float",
        "default": 0.5
    },
    "mode": {
        "description": "模式",
        "type": "string",
        "options": ["fast", "safe"],
        "labels": ["快速", "安全"]
    },
    "sub_config": {
        "description": "嵌套配置",
        "type": "object",
        "items": {
            "name": {
                "description": "名称",
                "type": "string"
            }
        }
    }
}
```

### 10.2 配置类型

| 类型 | 说明 |
|------|------|
| `string` | 字符串 |
| `text` | 大文本（显示为可拖拽的 textarea） |
| `int` | 整数 |
| `float` | 浮点数 |
| `bool` | 布尔值 |
| `object` | 对象（嵌套配置） |
| `list` | 列表 |
| `dict` | 字典 |
| `template_list` | 模板列表 |
| `file` | 文件上传 |

### 10.3 特殊选择器

```json
{
    "provider": {
        "description": "选择模型提供商",
        "type": "string",
        "_special": "select_provider"
    },
    "persona": {
        "description": "选择人格",
        "type": "string",
        "_special": "select_persona"
    },
    "knowledgebase": {
        "description": "选择知识库",
        "type": "list",
        "default": [],
        "_special": "select_knowledgebase"
    }
}
```

### 10.4 在插件中使用配置

```python
from astrbot.api import AstrBotConfig

class MyPlugin(Star):
    def __init__(self, context: Context, config: AstrBotConfig):
        super().__init__(context)
        self.config = config
        print(self.config["token"])
        # self.config.save_config()  # 保存配置
```

---

## 十一、存储功能

### 11.1 简单 KV 存储

```python
class Main(Star):
    @filter.command("hello")
    async def hello(self, event: AstrMessageEvent):
        # 存储数据
        await self.put_kv_data("greeted", True)
        # 获取数据
        greeted = await self.get_kv_data("greeted", False)
        # 删除数据
        await self.delete_kv_data("greeted")
```

### 11.2 存储大文件规范

```python
from pathlib import Path
from astrbot.core.utils.astrbot_path import get_astrbot_data_path

plugin_data_path = Path(get_astrbot_data_path()) / "plugin_data" / self.name
```

---

## 十二、会话控制

### 12.1 基本用法

```python
from astrbot.core.utils.session_waiter import (
    session_waiter,
    SessionController,
)

@filter.command("成语接龙")
async def handle_idiom(self, event: AstrMessageEvent):
    yield event.plain_result("请发送一个成语~")

    @session_waiter(timeout=60, record_history_chains=False)
    async def idiom_waiter(controller: SessionController, event: AstrMessageEvent):
        idiom = event.message_str

        if idiom == "退出":
            await event.send(event.plain_result("已退出"))
            controller.stop()
            return

        if len(idiom) != 4:
            await event.send(event.plain_result("成语必须是四个字"))
            return

        await event.send(event.plain_result("先见之明"))
        controller.keep(timeout=60, reset_timeout=True)

    try:
        await idiom_waiter(event)
    except TimeoutError:
        yield event.plain_result("你超时了！")
    finally:
        event.stop_event()
```

### 12.2 SessionController 方法

| 方法 | 说明 |
|------|------|
| `keep(timeout, reset_timeout)` | 保持会话 |
| `stop()` | 结束会话 |
| `get_history_chains()` | 获取历史消息链 |

### 12.3 自定义会话 ID

```python
from astrbot.core.utils.session_waiter import SessionFilter

class CustomFilter(SessionFilter):
    def filter(self, event: AstrMessageEvent) -> str:
        return event.get_group_id() if event.get_group_id() else event.unified_msg_origin

await idiom_waiter(event, session_filter=CustomFilter())
```

---

## 十三、前端页面 (Pages)

### 13.1 目录结构

```
pages/
└── bridge-demo/
    ├── index.html
    ├── app.js
    ├── style.css
    └── assets/
        └── logo.svg
```

### 13.2 前端示例

```html
<!doctype html>
<html lang="zh-CN">
<head>
    <meta charset="utf-8" />
    <title>Plugin Page Demo</title>
    <link rel="stylesheet" href="./style.css" />
</head>
<body>
    <button id="ping">Ping</button>
    <pre id="output"></pre>
    <script type="module" src="./app.js"></script>
</body>
</html>
```

```javascript
const bridge = window.AstrBotPluginPage;
const output = document.getElementById("output");

const context = await bridge.ready();
output.textContent = JSON.stringify(context, null, 2);

document.getElementById("ping").addEventListener("click", async () => {
    const result = await bridge.apiGet("ping");
    output.textContent = JSON.stringify(result, null, 2);
});
```

### 13.3 注册后端 API

```python
from quart import jsonify

class MyPlugin(Star):
    def __init__(self, context: Context):
        super().__init__(context)
        context.register_web_api(
            f"/{PLUGIN_NAME}/ping",
            self.page_ping,
            ["GET"],
            "Page ping",
        )

    async def page_ping(self):
        return jsonify({"message": "pong"})
```

### 13.4 Bridge API

| 方法 | 说明 |
|------|------|
| `ready()` | 等待 bridge 就绪并返回上下文 |
| `getContext()` | 读取当前上下文 |
| `apiGet(endpoint, params)` | 发送 GET 请求 |
| `apiPost(endpoint, body)` | 发送 POST 请求 |
| `upload(endpoint, file)` | 上传文件 |
| `download(endpoint, params, filename)` | 下载文件 |
| `subscribeSSE(endpoint, handlers, params)` | 订阅 SSE |
| `unsubscribeSSE(subscriptionId)` | 取消 SSE 订阅 |

---

## 十四、国际化

### 14.1 目录结构

```
.astrbot-plugin/
└── i18n/
    ├── zh-CN.json
    └── en-US.json
```

### 14.2 翻译文件格式

```json
{
    "metadata": {
        "display_name": "天气助手",
        "short_desc": "一句话天气查询。",
        "desc": "查询天气并提供出行建议。"
    },
    "config": {
        "enable": {
            "description": "启用",
            "hint": "是否启用这个插件。"
        },
        "mode": {
            "description": "模式",
            "labels": ["快速", "安全"]
        }
    }
}
```

---

## 十五、文转图功能

### 15.1 基本文转图

```python
@filter.command("image")
async def on_image(self, event: AstrMessageEvent, text: str):
    url = await self.text_to_image(text)
    yield event.image_result(url)
```

### 15.2 自定义 HTML 模板

```python
TMPL = '''
<div style="font-size: 32px;">
<h1 style="color: black">Todo List</h1>
<ul>
{% for item in items %}
    <li>{{ item }}</li>
{% endfor %}
</ul>
</div>
'''

@filter.command("todo")
async def custom_t2i(self, event: AstrMessageEvent):
    url = await self.html_render(TMPL, {"items": ["吃饭", "睡觉", "玩原神"]})
    yield event.image_result(url)
```

---

## 十六、对话管理器

### 16.1 获取对话历史

```python
from astrbot.core.conversation_mgr import Conversation

uid = event.unified_msg_origin
conv_mgr = self.context.conversation_manager
curr_cid = await conv_mgr.get_curr_conversation_id(uid)
conversation = await conv_mgr.get_conversation(uid, curr_cid)
```

### 16.2 主要方法

| 方法 | 说明 |
|------|------|
| `new_conversation()` | 新建对话 |
| `switch_conversation()` | 切换对话 |
| `delete_conversation()` | 删除对话 |
| `get_curr_conversation_id()` | 获取当前对话 ID |
| `get_conversation()` | 获取对话对象 |
| `get_conversations()` | 获取所有对话列表 |
| `update_conversation()` | 更新对话 |
| `add_message_pair()` | 添加消息记录 |

---

## 十七、人格设定管理器

### 17.1 获取人格

```python
persona_mgr = self.context.persona_manager
persona = persona_mgr.get_persona(persona_id)
all_personas = persona_mgr.get_all_personas()
```

### 17.2 主要方法

| 方法 | 说明 |
|------|------|
| `get_persona(persona_id)` | 获取人格 |
| `get_all_personas()` | 获取所有人格 |
| `create_persona(...)` | 创建人格 |
| `update_persona(...)` | 更新人格 |
| `delete_persona(persona_id)` | 删除人格 |
| `get_default_persona_v3()` | 获取默认人格 |

---

## 十八、杂项功能

### 18.1 获取消息平台实例

```python
from astrbot.api.platform import AiocqhttpAdapter

platform = self.context.get_platform(filter.PlatformAdapterType.AIOCQHTTP)
assert isinstance(platform, AiocqhttpAdapter)
```

### 18.2 调用 QQ 协议端 API

```python
@filter.command("helloworld")
async def helloworld(self, event: AstrMessageEvent):
    if event.get_platform_name() == "aiocqhttp":
        from astrbot.core.platform.sources.aiocqhttp.aiocqhttp_message_event import AiocqhttpMessageEvent
        assert isinstance(event, AiocqhttpMessageEvent)
        client = event.bot
        payloads = {"message_id": event.message_obj.message_id}
        ret = await client.api.call_action('delete_msg', **payloads)
```

### 18.3 获取所有插件

```python
plugins = self.context.get_all_stars()
```

### 18.4 获取所有平台

```python
from astrbot.api.platform import Platform
platforms = self.context.platform_manager.get_insts()
```

---

## 十九、控制事件传播

```python
@filter.command("check_ok")
async def check_ok(self, event: AstrMessageEvent):
    ok = self.check()
    if not ok:
        yield event.plain_result("检查失败")
        event.stop_event()  # 停止事件传播
```

---

## 二十、开发原则

1. **功能需经过测试**
2. **需包含良好的注释**
3. **持久化数据存储于 `data` 目录下**，而非插件自身目录
4. **良好的错误处理机制**，不要让插件因一个错误而崩溃
5. **使用 ruff 格式化代码**
6. **不要使用 `requests` 库**，使用 `aiohttp`, `httpx` 等异步库
7. **优先提交 PR** 而不是单独写新插件（除非原插件已停止维护）

---

## 二十一、发布插件

1. 将插件代码推送到 GitHub 仓库
2. 前往 [AstrBot 插件市场](https://plugins.astrbot.app/)
3. 点击右下角 `+` 按钮
4. 填写基本信息、作者信息、仓库信息
5. 点击 `提交到 GITHUB` 按钮
6. 确认信息后提交 Issue

---

## 二十二、开发者支持

- 开发者专用 QQ 群: `975206796`
- GitHub 仓库: [AstrBotDevs/AstrBot](https://github.com/AstrBotDevs/AstrBot)
- 插件模板: [helloworld](https://github.com/Soulter/helloworld)
- 文转图在线工具: [AstrBot Text2Image Playground](https://t2i-playground.astrbot.app/)

---

## 附录：常用导入

```python
# 核心类
from astrbot.api.star import Context, Star
from astrbot.api.event import filter, AstrMessageEvent, MessageEventResult
from astrbot.api import logger, AstrBotConfig

# 消息组件
import astrbot.api.message_components as Comp
from astrbot.api.event import MessageChain

# AI 相关
from astrbot.api.provider import ProviderRequest, LLMResponse
from astrbot.core.agent.tool import FunctionTool, ToolExecResult
from astrbot.core.agent.run_context import ContextWrapper
from astrbot.core.astr_agent_context import AstrAgentContext

# 会话控制
from astrbot.core.utils.session_waiter import (
    session_waiter,
    SessionController,
    SessionFilter,
)

# 存储
from pathlib import Path
from astrbot.core.utils.astrbot_path import get_astrbot_data_path
```

---

*文档整理自 AstrBot 官方文档 (https://docs.astrbot.app/dev/)*
