"""
每日签到系统模块 - 管理签到逻辑和奖励发放
"""
import random
from dataclasses import dataclass, field
from typing import Dict, Any, Optional, List
from datetime import datetime, timedelta


@dataclass
class DailyReward:
    """每日奖励配置"""
    min_days: int
    gold: int
    items: List[str] = field(default_factory=list)
    description: str = ""


class DailySystem:
    """每日签到系统"""

    REWARD_TIERS = [
        DailyReward(min_days=1, gold=50, description="首次签到"),
        DailyReward(min_days=3, gold=80, items=["小血瓶"], description="连续签到3天"),
        DailyReward(min_days=7, gold=150, items=["绿色装备_随机"], description="连续签到7天"),
        DailyReward(min_days=14, gold=200, items=["蓝色装备_随机"], description="连续签到14天"),
        DailyReward(min_days=30, gold=500, items=["紫色装备_随机"], description="连续签到30天"),
    ]

    ITEMS = {
        "小血瓶": {"name": "小血瓶", "item_type": "consumable", "rarity": "common", "description": "恢复 1d4+1 点生命值"},
        "中血瓶": {"name": "中血瓶", "item_type": "consumable", "rarity": "uncommon", "description": "恢复 2d4+2 点生命值"},
        "大血瓶": {"name": "大血瓶", "item_type": "consumable", "rarity": "rare", "description": "恢复 4d4+4 点生命值"},
    }

    EQUIPMENT_TEMPLATES = {
        "绿色装备_随机": [
            {"name": "附魔短剑", "item_type": "weapon", "rarity": "uncommon", "description": "+1 攻击的短剑"},
            {"name": "防御戒指", "item_type": "accessory", "rarity": "uncommon", "description": "+1 AC"},
            {"name": "治疗药水", "item_type": "consumable", "rarity": "uncommon", "description": "恢复 2d4+2 HP"},
        ],
        "蓝色装备_随机": [
            {"name": "魔法长剑", "item_type": "weapon", "rarity": "rare", "description": "+2 攻击的长剑"},
            {"name": "防护披风", "item_type": "armor", "rarity": "rare", "description": "+2 AC"},
            {"name": "高等治疗药水", "item_type": "consumable", "rarity": "rare", "description": "恢复 4d4+4 HP"},
        ],
        "紫色装备_随机": [
            {"name": "传说之剑", "item_type": "weapon", "rarity": "legendary", "description": "+3 攻击的神器"},
            {"name": "龙鳞护甲", "item_type": "armor", "rarity": "legendary", "description": "+3 AC"},
            {"name": "生命灵药", "item_type": "consumable", "rarity": "legendary", "description": "完全恢复 HP"},
        ],
    }

    def __init__(self):
        self._init_time()

    def _init_time(self) -> None:
        """初始化时间相关配置"""
        self.server_timezone = "Asia/Shanghai"
        self.reset_hour = 0

    def get_today_date(self) -> str:
        """获取今天的日期字符串"""
        return datetime.now().strftime("%Y-%m-%d")

    def get_yesterday_date(self) -> str:
        """获取昨天的日期字符串"""
        yesterday = datetime.now() - timedelta(days=1)
        return yesterday.strftime("%Y-%m-%d")

    def check_sign_status(self, daily_sign: Dict[str, Any]) -> Dict[str, Any]:
        """检查签到状态

        Args:
            daily_sign: 玩家的签到记录

        Returns:
            签到状态信息
        """
        today = self.get_today_date()
        last_sign = daily_sign.get("last_sign_date", "")

        is_signed_today = last_sign == today
        total_days = daily_sign.get("total_days", 0)

        return {
            "is_signed_today": is_signed_today,
            "last_sign_date": last_sign,
            "total_days": total_days,
            "today": today
        }

    def sign(self, daily_sign: Dict[str, Any]) -> Dict[str, Any]:
        """执行签到

        Args:
            daily_sign: 玩家当前的签到记录

        Returns:
            签到结果，包含奖励信息
        """
        status = self.check_sign_status(daily_sign)

        if status["is_signed_today"]:
            return {
                "success": False,
                "message": "你已经签到过了，明天再来吧～",
                "rewards": {},
                "daily_sign": daily_sign
            }

        today = self.get_today_date()
        yesterday = self.get_yesterday_date()
        last_sign = status["last_sign_date"]

        if last_sign == yesterday:
            consecutive_days = daily_sign.get("consecutive_days", 0) + 1
        else:
            consecutive_days = 1

        new_total_days = daily_sign.get("total_days", 0) + 1

        daily_sign["last_sign_date"] = today
        daily_sign["consecutive_days"] = consecutive_days
        daily_sign["total_days"] = new_total_days

        rewards = self._calculate_rewards(consecutive_days)

        return {
            "success": True,
            "message": self._generate_sign_message(consecutive_days, new_total_days),
            "rewards": rewards,
            "daily_sign": daily_sign
        }

    def _calculate_rewards(self, consecutive_days: int) -> Dict[str, Any]:
        """计算签到奖励

        Args:
            consecutive_days: 连续签到天数

        Returns:
            奖励信息
        """
        rewards = {"gold": 0, "items": []}

        base_reward = self.REWARD_TIERS[0]
        rewards["gold"] += base_reward.gold

        for tier in self.REWARD_TIERS[1:]:
            if consecutive_days >= tier.min_days:
                rewards["gold"] = tier.gold
                rewards["items"] = []
                for item_template in tier.items:
                    if "_随机" in item_template:
                        item = self._generate_random_equipment(item_template)
                    else:
                        item = self.ITEMS.get(item_template, {}).copy()
                    if item:
                        rewards["items"].append(item)

        return rewards

    def _generate_random_equipment(self, template: str) -> Optional[Dict[str, Any]]:
        """生成随机装备

        Args:
            template: 装备模板名称

        Returns:
            随机生成的装备
        """
        equipment_pool = self.EQUIPMENT_TEMPLATES.get(template, [])
        if not equipment_pool:
            return None
        return random.choice(equipment_pool).copy()

    def _generate_sign_message(self, consecutive_days: int, total_days: int) -> str:
        """生成签到成功消息

        Args:
            consecutive_days: 连续签到天数
            total_days: 累计签到天数

        Returns:
            格式化的签到消息
        """
        messages = [
            f"🎉 签到成功！",
            f"📅 连续签到：{consecutive_days} 天",
            f"📊 累计签到：{total_days} 天",
        ]

        return "\n".join(messages)

    def get_reward_preview(self, consecutive_days: int) -> str:
        """获取奖励预览

        Args:
            consecutive_days: 当前连续签到天数（签到后将变为 consecutive_days+1）

        Returns:
            奖励预览文本
        """
        next_days = consecutive_days + 1
        rewards = self._calculate_rewards(next_days)

        gold = rewards["gold"]
        items = rewards["items"]

        items_text = ""
        if items:
            item_names = [item["name"] for item in items]
            items_text = f" + {'、'.join(item_names)}"

        next_tier = self._get_next_tier(next_days)
        tier_text = f"\n🎯 下一档奖励：连续签到 {next_tier} 天" if next_tier else ""

        return f"""
📋 今日签到将获得：

💰 金币：{gold}
🎁 物品：{'无' if not items else items_text}

{tier_text}
"""

    def _get_next_tier(self, current_days: int) -> Optional[int]:
        """获取下一档奖励的天数

        Args:
            current_days: 当前连续签到天数

        Returns:
            下一档奖励的天数，如果没有下一档则返回 None
        """
        for tier in self.REWARD_TIERS:
            if tier.min_days > current_days:
                return tier.min_days
        return None

    def get_sign_calendar(self, daily_sign: Dict[str, Any], month: Optional[int] = None) -> str:
        """生成本月签到日历

        Args:
            daily_sign: 签到记录
            month: 月份（默认为本月）

        Returns:
            签到日历文本
        """
        now = datetime.now()
        if month is None:
            month = now.month

        year = now.year

        signed_dates = daily_sign.get("signed_dates", [])

        cal = f"""
📅 {year} 年 {month} 月签到日历

  一 二 三 四 五 六 日
"""
        first_day = datetime(year, month, 1)
        start_weekday = first_day.weekday()

        day_count = 31
        if month in [4, 6, 9, 11]:
            day_count = 30
        elif month == 2:
            if (year % 4 == 0 and year % 100 != 0) or year % 400 == 0:
                day_count = 29
            else:
                day_count = 28

        line = " " * 4
        for i in range(start_weekday):
            line += "   "

        for day in range(1, day_count + 1):
            date_str = f"{year}-{month:02d}-{day:02d}"
            if date_str in signed_dates:
                line += " ✅"
            elif date_str == self.get_today_date():
                line += " 📍"
            else:
                line += f"{day:3d}"

            if (start_weekday + day) % 7 == 0:
                cal += line.rstrip() + "\n"
                line = ""

        if line.strip():
            cal += line.rstrip() + "\n"

        return cal.strip()

    def is_new_day(self, last_sign_date: str) -> bool:
        """检查是否是新的签到日

        Args:
            last_sign_date: 上次签到日期

        Returns:
            是否是新的一天
        """
        return last_sign_date != self.get_today_date()
