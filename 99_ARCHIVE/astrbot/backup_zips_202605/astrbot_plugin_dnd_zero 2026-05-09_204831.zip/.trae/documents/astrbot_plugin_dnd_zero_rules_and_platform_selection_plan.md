# DND/TRPG 插件规则体系选型与实施计划

> **文档版本**: v1.0  
> **创建日期**: 2026-05-09  
> **作者**: AI Assistant  
> **状态**: 计划阶段 - 待用户确认

---

## 📋 一、项目概述

### 1.1 项目背景

**项目名称**: astrbot_plugin_dnd_zero  
**项目目标**: 开发一款基于简化D&D规则的轻量化TRPG群组跑团插件

### 1.2 核心定位

- **规则基础**: D&D 5e (2014版本)
- **设计理念**: "D&D精神 + 网游化改造"
  - 保留D&D核心机制（D20检定、职业系统、战斗框架）
  - 融入网游长线养成要素（装备、社交、日常）
  - 适配群聊轻量化交互场景
- **目标用户**: TRPG新手玩家
- **复杂度定位**: 中等复杂度（保留核心、简化次要规则）

### 1.3 战略决策

| 决策项 | 选择 | 理由 |
|--------|------|------|
| 规则版本 | **D&D 5e (2014)** | 社区成熟、资料丰富、向后兼容 |
| 参考数据源 | **5e-bits/5e-database** | 开源免费、完整SRD、MIT许可 |
| 数据获取方式 | **本地离线数据库** | 快速响应、无需网络、支持魔改 |
| 插件语言 | **中文** | 面向中文TRPG新手玩家 |
| 扩展方向 | **社交组队 + 混合养成** | 群聊核心场景 + 差异化特色 |

---

## 🎯 二、规则体系设计

### 2.1 D&D 5e 核心机制保留清单

#### ✅ 必须保留的机制

| 机制类别 | 具体内容 | 保留程度 | 说明 |
|---------|---------|---------|------|
| **D20检定系统** | 攻击检定、属性检定、豁免检定 | ✅ 完整保留 | 核心中的核心 |
| **属性系统** | 力量/敏捷/体质/智力/感知/魅力 | ✅ 完整保留 | 6大属性标准配置 |
| **技能系统** | 18项技能 + 熟练加值 | ✅ 保留核心技能 | 简化可选规则 |
| **职业系统** | 12职业 + 子职业 | ✅ 完整保留 | 后续可扩展 |
| **等级系统** | 1-20级 + CR系统 | ✅ 完整保留 | 支持长线升级 |
| **种族系统** | 种族 + 亚种 | ✅ 完整保留 | 保留文化背景 |
| **背景系统** | 背景 + 特质/理想/羁绊/缺点 | ✅ 简化保留 | 可选机制 |
| **战斗系统** | 回合制、动作、附赠动作、移动 | ✅ 完整保留 | 核心玩法 |
| **法术系统** | 法术列表、法术位、施法规则 | ✅ 保留核心 | 简化高阶法术 |
| **专长系统** | 专长选择 | ✅ 保留可选 | 提升角色个性化 |

#### 🔧 可简化/魔改的机制

| 机制类别 | 原版处理 | 魔改方案 | 说明 |
|---------|---------|---------|------|
| **生命值** | 固定+体质调整 | 保留计算方式，但可能调整上限 | 适配长线生存 |
| **护甲等级 (AC)** | 复杂计算 | 简化为数值直接计算 | 减少新手困惑 |
| **职业特性** | 大量详细描述 | 核心特性保留，描述简化 | 聚焦关键能力 |
| **法术列表** | 完整数百个法术 | 基础法术 + 可解锁 | 避免信息过载 |
| **物品/装备** | 简单道具系统 | 扩展为MMO式装备体系 | 融入养成要素 |
| **阵营/道德** | 9宫格阵营 | 可简化或移除 | 非核心机制 |

### 2.2 扩展系统设计

#### 🌟 核心扩展方向

| 扩展系统 | 设计思路 | 优先级 | 说明 |
|---------|---------|-------|------|
| **社交组队系统** | 群聊场景核心 | ⭐⭐⭐⭐⭐ 最高 | 队伍管理、组队匹配 |
| **装备养成** | MMO式装备强化 | ⭐⭐⭐⭐ 高 | 强化、精炼、镶嵌 |
| **日常任务** | 轻量化长线留存 | ⭐⭐⭐⭐ 高 | 签到、日常挑战 |
| **副本/秘境** | 单人/组队冒险 | ⭐⭐⭐ 中 | 简化副本流程 |
| **经济系统** | 金币交易、商店 | ⭐⭐⭐ 中 | 交易、拍卖 |
| **成就系统** | 里程碑奖励 | ⭐⭐ 低 | 可后续扩展 |
| **宠物/伙伴** | 辅助角色 | ⭐⭐ 低 | 未来可扩展 |

#### 🎮 特色设计理念

```
┌─────────────────────────────────────┐
│        D&D 5e 核心框架               │
│  ┌─────────────────────────────┐    │
│  │ D20检定 · 职业 · 战斗 · 法术 │    │
│  └─────────────────────────────┘    │
└──────────────┬──────────────────────┘
               │
               ▼
┌─────────────────────────────────────┐
│        魔改与扩展层                  │
│  ┌─────────────────────────────┐    │
│  │ 简化规则 + MMO养成 + 社交    │    │
│  │ + 日常运营 + 装备系统        │    │
│  └─────────────────────────────┘    │
└──────────────┬──────────────────────┘
               │
               ▼
┌─────────────────────────────────────┐
│        AstrBot 插件实现              │
│  ┌─────────────────────────────┐    │
│  │ QQ群聊 · 文本交互 · LLM DM   │    │
│  └─────────────────────────────┘    │
└─────────────────────────────────────┘
```

---

## 🗄️ 三、数据体系设计

### 3.1 数据源选择

#### 📊 5e-bits/5e-database 分析

| 维度 | 评估 | 得分 |
|------|------|------|
| **数据完整性** | 包含职业、种族、法术、怪物、装备等 | ⭐⭐⭐⭐⭐ |
| **开放性** | MIT许可证，完全开源免费 | ⭐⭐⭐⭐⭐ |
| **维护状态** | 活跃维护（最新2025年） | ⭐⭐⭐⭐⭐ |
| **社区支持** | Discord社区 + GitHub协作 | ⭐⭐⭐⭐ |
| **中文支持** | 英文为主，但结构清晰易翻译 | ⭐⭐⭐ |
| **API可用性** | 提供REST API (dnd5eapi.co) | ⭐⭐⭐⭐ |

**最终评价**: ⭐⭐⭐⭐⭐ **强烈推荐**

### 3.2 数据获取策略

#### 📥 本地离线数据库方案

```
数据获取流程:
1. 初始构建 → 从5e-bits仓库克隆数据
2. 本地存储 → JSON/MongoDB格式存储
3. 中文本地化 → LLM翻译 + 人工校对
4. 魔改适配 → 扩展自定义内容
5. 增量更新 → 定期同步上游更新
```

#### 📁 数据目录结构设计

```
data/
├── srd/                          # D&D 5e SRD原始数据
│   ├── classes/                  # 职业数据
│   │   ├── barbarian.json
│   │   ├── fighter.json
│   │   └── ... (12个职业)
│   ├── races/                    # 种族数据
│   │   ├── dwarf.json
│   │   ├── elf.json
│   │   └── ... (9个种族)
│   ├── spells/                   # 法术数据
│   │   ├── level_0/              # 0环法术
│   │   ├── level_1/             # 1环法术
│   │   └── ... (1-9环)
│   ├── monsters/                 # 怪物数据
│   ├── equipment/                # 装备数据
│   └── backgrounds/              # 背景数据
├── i18n/                         # 国际化/本地化
│   ├── zh-CN/                    # 中文翻译
│   │   ├── classes.json
│   │   ├── races.json
│   │   ├── spells.json
│   │   └── ... (详细翻译)
│   └── en-US/                    # 英文原文
├── custom/                       # 自定义/魔改数据
│   ├── custom_classes/           # 自定义职业扩展
│   ├── custom_spells/            # 自定义法术
│   ├── dungeons/                 # 副本/秘境设计
│   └── events/                   # 事件/任务设计
└── game/                        # 游戏运行时数据
    ├── players/                 # 玩家角色数据
    ├── parties/                 # 队伍数据
    ├── inventories/             # 装备/物品数据
    └── economy/                 # 经济系统数据
```

### 3.3 数据模型设计

#### 👤 玩家角色数据模型

```json
{
  "player_id": "123456789",
  "character": {
    "name": "角色名称",
    "level": 5,
    "experience": 6500,
    "class": "fighter",
    "subclass": "champion",
    "race": "human",
    "background": "soldier",
    "ability_scores": {
      "strength": 16,
      "dexterity": 14,
      "constitution": 15,
      "intelligence": 10,
      "wisdom": 12,
      "charisma": 13
    },
    "hit_points": {
      "current": 42,
      "maximum": 45,
      "temporary": 0
    },
    "armor_class": 18,
    "proficiency_bonus": 3,
    "skills": ["athletics", "intimidation", "perception"],
    "equipment": [
      {
        "id": "longsword_001",
        "name": "精炼长剑",
        "type": "weapon",
        "rarity": "rare",
        "enchant_level": 3,
        "stats": {
          "attack_bonus": 5,
          "damage_bonus": 2
        }
      }
    ],
    "spells": ["fire_bolt", "magic_missile"],
    "features": ["action_surge", "second_wind"]
  },
  "party_id": "party_001",
  "achievements": [],
  "daily_quests": [],
  "created_at": "2026-05-09T12:00:00Z",
  "updated_at": "2026-05-09T15:30:00Z"
}
```

#### 👥 队伍数据模型

```json
{
  "party_id": "party_001",
  "name": "冒险者小队",
  "leader_id": "123456789",
  "members": [
    {
      "player_id": "123456789",
      "character_name": "战士角色",
      "role": "tank",
      "joined_at": "2026-05-09T12:00:00Z"
    }
  ],
  "dungeon_id": "dungeon_forest_01",
  "status": "exploring",
  "created_at": "2026-05-09T12:00:00Z"
}
```

---

## 🔧 四、技术实现方案

### 4.1 技术栈选择

| 组件 | 选择 | 理由 |
|------|------|------|
| **主语言** | Python 3.10+ | AstrBot框架要求 |
| **数据格式** | JSON | 轻量、易读、易编辑 |
| **数据库** | SQLite / 文件存储 | 插件轻量化，避免额外依赖 |
| **HTTP客户端** | httpx | AstrBot推荐异步库 |
| **数据验证** | Pydantic | 类型安全、验证方便 |
| **日期处理** | datetime | 标准库 |

### 4.2 核心模块架构

```
astrbot_plugin_dnd_zero/
├── main.py                      # 插件主入口
├── core/                        # 核心逻辑
│   ├── __init__.py
│   ├── character.py             # 角色系统
│   ├── combat.py                 # 战斗系统
│   ├── spell.py                 # 法术系统
│   ├── skill.py                 # 技能检定系统
│   └── dungeon.py               # 副本/秘境系统
├── data/                        # 数据层
│   ├── loader.py                # 数据加载器
│   ├── srd/                     # SRD原始数据
│   ├── i18n/                    # 国际化数据
│   └── custom/                  # 自定义数据
├── features/                    # 功能模块
│   ├── party.py                 # 组队系统
│   ├── equipment.py             # 装备系统
│   ├── daily.py                 # 日常任务
│   └── economy.py               # 经济系统
├── api/                        # API层
│   ├── dnd_api.py              # D&D数据API
│   └── game_api.py             # 游戏逻辑API
├── utils/                      # 工具函数
│   ├── dice.py                 # 掷骰工具
│   ├── formatter.py             # 格式化工具
│   └── validator.py            # 验证工具
└── hooks/                      # 钩子模块
    ├── llm_dm.py               # LLM DM集成
    └── events.py               # 事件处理
```

### 4.3 D&D API 封装

#### 🎲 核心掷骰系统

```python
class DiceRoller:
    """D20系统掷骰器"""

    def roll_d20(self) -> int:
        """标准D20掷骰"""
        return random.randint(1, 20)

    def roll_attack(self, attack_bonus: int) -> dict:
        """攻击检定"""
        roll = self.roll_d20()
        total = roll + attack_bonus
        return {
            "roll": roll,
            "bonus": attack_bonus,
            "total": total,
            "critical": roll == 20
        }

    def roll_ability_check(
        self,
        ability_modifier: int,
        proficiency_bonus: int = 0,
        advantage: bool = False,
        disadvantage: bool = False
    ) -> dict:
        """属性检定"""
        roll1 = self.roll_d20()
        roll2 = self.roll_d20() if advantage or disadvantage else None

        if advantage and not disadvantage:
            roll = max(roll1, roll2)
        elif disadvantage and not advantage:
            roll = min(roll1, roll2)
        else:
            roll = roll1

        total = roll + ability_modifier + proficiency_bonus
        return {
            "roll": roll,
            "ability_modifier": ability_modifier,
            "proficiency_bonus": proficiency_bonus,
            "total": total,
            "natural_20": roll == 20,
            "natural_1": roll == 1
        }
```

#### ⚔️ 战斗系统

```python
class CombatSystem:
    """D&D 5e 战斗系统"""

    def __init__(self, data_loader: DataLoader):
        self.data = data_loader

    def process_attack(
        self,
        attacker: Character,
        defender: Character,
        weapon: Equipment
    ) -> CombatResult:
        """处理攻击流程"""
        attack_roll = DiceRoller.roll_attack(weapon.attack_bonus)

        if not attack_roll["critical"]:
            if attack_roll["total"] < defender.armor_class:
                return CombatResult.MISS

        damage_roll = DiceRoller.roll_damage(weapon.damage_dice)
        damage = damage_roll.total + weapon.damage_bonus

        defender.take_damage(damage)

        return CombatResult.HIT(damage, attack_roll)

    def calculate_ac(self, character: Character) -> int:
        """计算护甲等级"""
        base_ac = 10
        dex_mod = character.get_modifier("dexterity")
        armor_bonus = character.get_armor_bonus()

        return base_ac + dex_mod + armor_bonus
```

### 4.4 LLM DM 集成

```python
class LLMDungeonMaster:
    """基于LLM的DM系统"""

    def __init__(self, context: Context, config: AstrBotConfig):
        self.context = context
        self.config = config
        self.dm_model = config.get("dm_model", "gpt-4o")

    async def generate_scene(self, party: Party, location: str) -> str:
        """生成场景描述"""
        prompt = f"""
你是{D&D}的地下城主。

当前场景: {location}
队伍等级: {party.average_level}
队伍成员: {', '.join([m.character_name for m in party.members])}

请生成一段适合当前等级的场景描述，包含:
1. 环境描写
2. 可能的遭遇
3. 氛围营造

请使用中文回复，保持简洁（200字以内）。
"""
        return await self._call_llm(prompt)

    async def resolve_action(
        self,
        party: Party,
        action: str,
        context: str
    ) -> ActionResult:
        """解析玩家行动"""
        prompt = f"""
你是D&D的地下城主。

队伍行动: {action}
当前场景: {context}

请判断这个行动的:
1. 是否需要检定？需要的话什么类型？
2. 检定的难度等级（DC）是多少？
3. 可能的结果（成功/失败/特殊）

请以JSON格式回复。
"""
        response = await self._call_llm(prompt)
        return self._parse_action_result(response)

    async def _call_llm(self, prompt: str) -> str:
        """调用LLM"""
        provider_id = await self.context.get_current_chat_provider_id(...)
        resp = await self.context.llm_generate(
            chat_provider_id=provider_id,
            prompt=prompt
        )
        return resp.completion_text
```

---

## 📅 五、实施计划

### 5.1 第一阶段：数据基础设施 (预计 1-2 周)

#### 任务清单

| 任务 | 优先级 | 预估时间 | 说明 |
|------|--------|---------|------|
| 5.1.1 克隆 5e-bits 数据仓库 | ⭐⭐⭐⭐⭐ | 2小时 | 获取完整SRD数据 |
| 5.1.2 数据格式转换 | ⭐⭐⭐⭐⭐ | 4小时 | JSON化处理 |
| 5.1.3 数据加载器开发 | ⭐⭐⭐⭐⭐ | 6小时 | 统一数据访问接口 |
| 5.1.4 中文本地化 | ⭐⭐⭐⭐⭐ | 1-2天 | LLM翻译 + 校对 |
| 5.1.5 数据验证工具 | ⭐⭐⭐⭐ | 4小时 | 确保数据完整性 |

#### 交付物

- [ ] `data/srd/` 完整D&D 5e SRD数据
- [ ] `data/i18n/zh-CN/` 中文翻译
- [ ] `data/loader.py` 数据加载模块

### 5.2 第二阶段：核心系统实现 (预计 2-3 周)

#### 任务清单

| 任务 | 优先级 | 预估时间 | 说明 |
|------|--------|---------|------|
| 5.2.1 角色系统 | ⭐⭐⭐⭐⭐ | 2天 | 创建、属性、升级 |
| 5.2.2 掷骰系统 | ⭐⭐⭐⭐⭐ | 1天 | D20及各种骰子 |
| 5.2.3 技能检定系统 | ⭐⭐⭐⭐⭐ | 2天 | 攻击、豁免、技能 |
| 5.2.4 战斗系统 | ⭐⭐⭐⭐⭐ | 3天 | 回合制战斗流程 |
| 5.2.5 法术系统 | ⭐⭐⭐⭐ | 2天 | 法术查询与施放 |

#### 交付物

- [ ] `core/character.py` 角色管理
- [ ] `utils/dice.py` 掷骰工具
- [ ] `core/skill.py` 检定系统
- [ ] `core/combat.py` 战斗系统
- [ ] `core/spell.py` 法术系统

### 5.3 第三阶段：扩展功能开发 (预计 2-3 周)

#### 任务清单

| 任务 | 优先级 | 预估时间 | 说明 |
|------|--------|---------|------|
| 5.3.1 组队系统 | ⭐⭐⭐⭐⭐ | 2天 | 队伍创建、邀请、管理 |
| 5.3.2 装备系统基础 | ⭐⭐⭐⭐ | 2天 | 装备穿戴、属性加成 |
| 5.3.3 副本系统 | ⭐⭐⭐⭐ | 3天 | 秘境探索流程 |
| 5.3.4 LLM DM 集成 | ⭐⭐⭐⭐ | 2天 | 动态剧情生成 |
| 5.3.5 经济系统基础 | ⭐⭐⭐ | 1天 | 金币、商店 |

#### 交付物

- [ ] `features/party.py` 组队系统
- [ ] `features/equipment.py` 装备系统
- [ ] `features/dungeon.py` 副本系统
- [ ] `hooks/llm_dm.py` LLM DM模块
- [ ] `features/economy.py` 经济系统

### 5.4 第四阶段：插件集成与测试 (预计 1-2 周)

#### 任务清单

| 任务 | 优先级 | 预估时间 | 说明 |
|------|--------|---------|------|
| 5.4.1 AstrBot 插件集成 | ⭐⭐⭐⭐⭐ | 1天 | 指令注册、事件处理 |
| 5.4.2 指令系统完善 | ⭐⭐⭐⭐⭐ | 2天 | /dnd create, /dnd quest 等 |
| 5.4.3 群组权限管理 | ⭐⭐⭐⭐ | 1天 | 白名单、权限控制 |
| 5.4.4 单元测试 | ⭐⭐⭐⭐ | 2天 | 核心逻辑测试 |
| 5.4.5 集成测试 | ⭐⭐⭐ | 1天 | 端到端测试 |

#### 交付物

- [ ] 完整插件代码
- [ ] 测试用例
- [ ] 使用文档

---

## 🎯 六、验证与测试

### 6.1 单元测试清单

| 测试项 | 测试内容 | 通过标准 |
|--------|---------|---------|
| 掷骰系统 | D20、各类骰子、加成计算 | 结果在合理范围 |
| 属性检定 | 各种优势/劣势组合 | 概率分布合理 |
| 战斗流程 | 攻击→伤害→HP更新 | 数值逻辑正确 |
| 角色创建 | 属性分配、职业选择 | 符合5e规则 |
| 法术系统 | 法术查询、施法判定 | 数据完整准确 |

### 6.2 集成测试清单

| 测试场景 | 测试步骤 | 预期结果 |
|---------|---------|---------|
| 创建角色 | /dnd create → 选择种族/职业 → 完成 | 角色数据正确保存 |
| 发起战斗 | /dnd combat → 攻击检定 → 伤害计算 | 战斗流程正常 |
| 组队冒险 | /dnd party create → 邀请成员 → 开始副本 | 队伍系统工作正常 |
| LLM DM | /dnd quest → LLM生成场景 → 玩家行动 | 剧情流畅自然 |

### 6.3 用户验收标准

- [ ] 新手能在5分钟内创建角色
- [ ] 战斗流程符合D&D 5e规则
- [ ] 组队系统支持2-6人队伍
- [ ] 基础中文本地化完成
- [ ] 无明显Bug或崩溃

---

## ⚠️ 七、风险与应对

### 7.1 主要风险

| 风险项 | 可能性 | 影响程度 | 应对策略 |
|--------|--------|---------|----------|
| 数据版权问题 | 低 | 高 | 使用OGL许可的SRD数据 |
| 中文翻译质量 | 中 | 中 | LLM初翻 + 社区校对 |
| LLM DM 质量 | 中 | 高 | 提供备用预设剧情 |
| 性能问题 | 低 | 中 | 优化数据加载，缓存热点 |
| 用户留存 | 中 | 高 | 持续运营内容更新 |

### 7.2 备选方案

- **如果5e-bits数据不可用** → 使用Open5e API
- **如果LLM DM质量不佳** → 提供预设剧情模板
- **如果中文翻译量大** → 社区协作翻译

---

## 📚 八、参考资源

### 8.1 官方资源

- [D&D 5e SRD (System Reference Document)](https://www.dndbeyond.com/posts/1717-2024-core-rulebooks-to-expand-the-srd)
- [D&D Beyond 官方规则](https://www.dndbeyond.com/)
- [Open Gaming License (OGL)](https://www Wizards.com/default.asp?x=d20/oglfaq/20040123f)

### 8.2 技术资源

- [5e-bits/5e-database](https://github.com/5e-bits/5e-database) - 开源D&D数据
- [D&D 5e API](https://dnd5eapi.co/) - REST API服务
- [AstrBot 插件开发文档](https://docs.astrbot.app/dev/)

### 8.3 中文社区

- [D&D 5e 中文规则书](https://www.douban.com/group/topic/177039246/)
- [5e SRD 中文翻译项目](https://github.com/) (待寻找)

---

## ✅ 九、决策确认清单

在开始实施前，请确认以下决策：

- [x] 规则基础：D&D 5e (2014)
- [x] 数据来源：5e-bits/5e-database
- [x] 数据获取：本地离线数据库
- [x] 语言：中文
- [x] 复杂度：中等
- [x] 保留机制：D20检定、职业、等级、种族、战斗、法术
- [x] 扩展方向：社交组队 + MMO养成
- [ ] **请确认以上决策是否符合预期？**

---

## 📝 十、后续步骤

1. **确认本计划** → 用户确认后开始实施
2. **数据获取** → 克隆5e-bits仓库
3. **基础设施** → 开发数据加载器
4. **核心系统** → 实现D20检定、战斗等
5. **扩展功能** → 组队、副本、LLM DM
6. **插件集成** → AstrBot指令注册
7. **测试验收** → 完整功能测试

---

**文档状态**: 📋 待确认  
**下一步行动**: 等待用户确认后开始第一阶段实施  
**预期完成时间**: 6-10 周（根据投入时间）  
**优先级**: ⭐⭐⭐⭐⭐ 最高
