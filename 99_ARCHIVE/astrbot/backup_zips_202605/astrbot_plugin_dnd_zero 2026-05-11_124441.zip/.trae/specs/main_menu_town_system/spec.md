# 主菜单/城镇界面系统规范

## Why

AstrBot DND/Zero 插件需要从基础的角色建卡系统扩展到完整的游戏主菜单界面。作为 D&D 5e TRPG 插件，需要为玩家提供沉浸式的游戏体验，包括城镇探索、NPC 交互、背包管理、商店交易、冒险小队组队等核心功能。首个城镇设定在深水城（Waterdeep）南区，符合 D&D 5e 被遗忘的国度（Forgotten Realms）世界观。

## What Changes

### 新增系统模块

- **城镇系统** (`core/town.py`)：管理深水城南区 6 个区域的区域数据、描述文本
- **菜单系统** (`core/menu.py`)：生成主菜单界面、区域菜单、功能子菜单
- **NPC 系统** (`core/npc.py`)：NPC 数据管理、对话文本库、随机对话选择
- **每日签到系统** (`core/daily.py`)：累计签到奖励机制
- **背包系统** (`core/backpack.py`)：物品管理、使用/丢弃
- **商店系统** (`core/shop.py`)：多分类商品展示、购买逻辑
- **冒险小队系统** (`core/party.py`)：组队管理

### 新增数据文件

- `data/town_data.json`：深水城南区区域数据
- `data/npc_data.json`：NPC 数据和对话文本库
- `data/shop_data.json`：商店商品分类数据

### 修改现有系统

- `core/character.py`：扩展 Character 类，添加金币、背包、签到记录等字段
- `main.py`：添加城镇指令路由
- `core/__init__.py`：导出新模块

### 界面交互模式

- 少量文字直接发送消息
- 中量/大量文字使用合并转发卡片（Nodes）
- 功能按钮通过指令菜单选择

## Impact

- **受影响的规范**：角色创建系统、战斗系统、剧本系统
- **受影响的代码**：
  - `core/town.py`（新增）
  - `core/menu.py`（新增）
  - `core/npc.py`（新增）
  - `core/daily.py`（新增）
  - `core/backpack.py`（新增）
  - `core/shop.py`（新增）
  - `core/party.py`（新增）
  - `core/character.py`（修改）
  - `main.py`（修改）
  - `data/town_data.json`（新增）
  - `data/npc_data.json`（新增）
  - `data/shop_data.json`（新增）

---

## ADDED Requirements

### Requirement: 城镇主界面

系统 SHALL 提供城镇主界面，通过 `/dnd 城镇`、`/dnd 主页`、`/dnd home`、`/dnd 菜单` 指令触发，显示深水城南区主界面。

#### Scenario: 显示主界面
- **WHEN** 玩家发送 `/dnd 城镇`
- **THEN** 系统显示包含 6 个功能入口的界面（角色、背包、商店、冒险小队、副本、每日签到）
- **AND** 界面显示玩家当前金币数量
- **AND** 界面显示玩家累计签到天数
- **AND** 界面显示玩家当前队伍状态

### Requirement: 区域浏览

系统 SHALL 提供区域浏览功能，通过 `/dnd 区域` 指令触发，显示深水城南区 6 个区域的详细信息。

#### Scenario: 显示区域列表
- **WHEN** 玩家发送 `/dnd 区域`
- **THEN** 系统显示南区广场、冒险者公会、南区集市、醉月亭、黎明神殿、训练场共 6 个区域
- **AND** 每个区域显示名称和简短描述

### Requirement: NPC 对话

系统 SHALL 提供 NPC 对话功能，通过 `/dnd NPC <NPC名称>` 指令触发，显示 NPC 对话文本。

#### Scenario: NPC 对话
- **WHEN** 玩家发送 `/dnd NPC 莫里斯`
- **THEN** 系统显示莫里斯的问候语
- **AND** 系统从对话文本库中随机选择一条回复

### Requirement: 每日签到

系统 SHALL 提供每日签到功能，通过 `/dnd 签到` 指令触发，执行签到并发放奖励。

#### Scenario: 首次签到
- **WHEN** 玩家发送 `/dnd 签到` 且玩家当日未签到
- **THEN** 系统增加玩家金币 50
- **AND** 系统更新累计签到天数为 1
- **AND** 系统显示签到成功消息

#### Scenario: 累计签到奖励
- **WHEN** 玩家累计签到达到 3 天
- **THEN** 系统发放 80 金币和 1 个小血瓶
- **WHEN** 玩家累计签到达到 7 天
- **THEN** 系统发放 150 金币和 1 件随机绿色装备

### Requirement: 背包管理

系统 SHALL 提供背包管理功能，通过 `/dnd 背包` 指令触发，显示玩家背包内容。

#### Scenario: 查看背包
- **WHEN** 玩家发送 `/dnd 背包`
- **THEN** 系统显示背包中的物品列表
- **AND** 系统显示背包容量（已用/总容量）

### Requirement: 商店系统

系统 SHALL 提供商店系统，通过 `/dnd 商店` 指令触发，显示商店商品列表。

#### Scenario: 浏览商店
- **WHEN** 玩家发送 `/dnd 商店`
- **THEN** 系统显示商店分类（武器、防具、药水、卷轴、杂货）
- **AND** 系统显示每种分类的代表性商品

#### Scenario: 购买商品
- **WHEN** 玩家发送 `/dnd 商店 购买 <物品>`
- **AND** 玩家拥有足够金币
- **THEN** 系统扣除玩家金币
- **AND** 系统将物品添加到玩家背包

### Requirement: 冒险小队

系统 SHALL 提供冒险小队功能，通过 `/dnd 冒险小队` 系列指令触发，管理组队状态。

#### Scenario: 创建小队
- **WHEN** 玩家发送 `/dnd 冒险小队 创建`
- **AND** 玩家当前未在小队中
- **THEN** 系统创建新小队并将玩家设为队长
- **AND** 系统返回小队信息

#### Scenario: 邀请成员
- **WHEN** 队长发送 `/dnd 冒险小队 邀请 <玩家>`
- **THEN** 系统向目标玩家发送邀请
- **AND** 目标玩家可以发送 `/dnd 冒险小队 接受` 加入小队

### Requirement: 文本风格多样性

系统 SHALL 提供多种文本风格的随机文本生成。

#### Scenario: 文本风格选择
- **WHEN** 系统需要生成区域描述或 NPC 对话
- **THEN** 系统以 50% 概率选择轻松治愈风格
- **AND** 系统以 25% 概率选择惊悚灵异风格
- **AND** 系统以 25% 概率选择搞笑无厘头风格

---

## MODIFIED Requirements

### Requirement: Character 数据扩展

**原始需求**：Character 类仅包含角色基本属性

**修改后需求**：Character 类 SHALL 包含以下新增字段：
- `gold: int` - 玩家金币，默认 100
- `inventory: List[str]` - 背包物品 ID 列表
- `daily_sign: Dict[str, Any]` - 签到记录（最后签到日期、累计天数）
- `current_location: str` - 当前位置，默认 "plaza"
- `party_id: Optional[str]` - 所属冒险小队 ID

---

## REMOVED Requirements

无

---

## Technical Notes

### 数据持久化

- 所有玩家数据保存到 `plugin_data/astrbot_plugin_dnd_zero/data/characters.json`
- 签到记录使用日期字符串作为键
- 小队数据单独存储

### 合并转发卡片格式

```python
node_list = [
    Comp.Node(
        uin=event.get_self_id(),
        name="标题",
        content=[Comp.Plain("内容")]
    )
]
yield event.chain_result([Comp.Nodes(node_list)])
```

### 世界观设定

- **城市**：深水城（Waterdeep）- 被遗忘的国度核心城市
- **区域**：南区（Southern District）- 下层区
- **风格**：50% 轻松治愈 + 25% 惊悚灵异 + 25% 搞笑无厘头

### 分阶段实施

- **第一阶段**：城镇系统、菜单系统、NPC 系统（当前）
- **第二阶段**：签到系统、背包系统
- **第三阶段**：商店系统
- **第四阶段**：冒险小队系统
