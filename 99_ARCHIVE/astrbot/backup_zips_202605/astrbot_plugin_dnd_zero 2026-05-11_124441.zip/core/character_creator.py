"""
D&D 5e 交互式建卡系统
管理多轮对话建卡流程和27点购点制
"""
from dataclasses import dataclass, field
from typing import List, Optional, Dict, Tuple
from datetime import datetime
from enum import Enum

from .character import AbilityScores, Character, Skills
from .classes import ClassDatabase
from .races import RaceDatabase, Subrace
from .backgrounds import BackgroundDatabase

RACE_TRAIT_DESCRIPTIONS = {
    "适应力": "你的可塑性强，可以额外获得一项自选技能的熟练。在游戏开始时选择一项技能获得熟练。",
    "额外属性": "某些种族在特定属性上有额外加成，可在亚种选择时体现。",
    "精灵族视力": "你能以60尺内的细微距离辨别色彩和形状细节。在该距离内即使在Magical Darkness中也能以灰阶看清生物和物体。",
    "进阶精灵族视力": "你的精灵族视力在原有基础上增强，可以看穿更远的距离。",
    "矮人坚韧": "你的体质值增加1点。",
    "矮人武器熟练": "你获得矮人战锤、矮人短斧、矮人飞锤的熟练。",
    "金属防护本能": "你天生对金属铠甲有所了解。当金属护甲触碰你时，你对它的抵抗能力更强。",
    "石人血脉": "你的身体与岩石有着神秘的联系。当你处于或进入碎石地形时，你可以使用一个附赠动作来获得对抗一次攻击的+2护甲等级加值，持续到你回合结束。",
    "战士血统": "你的血脉中流淌着战士的荣耀。获得重甲和军用武器的熟练。",
    "半兽人之怒": "你可以在自己回合用附赠动作对自己造成1d6的钝击伤害；每长休一次。",
    "野兽姿态": "你可以在短休或长休后选择一种野兽形态。在野兽形态下你获得特定能力：\n  • 熊：力量+2，感知+1；技能：athletics；免疫：疾病、力竭；\n  • 狼：敏捷+2，感知+1；技能：perception, stealth；免疫：疾病、力竭；\n  • 鹰：敏捷+2，魅力+1；技能：perception, stealth；免疫：疾病、力竭；盲视10尺、飞行速度30尺。",
    "食人魔之力": "你获得食人魔的力量。当你进行力量检定或力量豁免时，你的熟练加值会翻倍。",
    "食人魔体格": "你的体型变大。在你处于狂暴状态时，你的武器造成额外伤害。",
    "灵能能力": "你拥有有限的灵能能力，允许你在短休后重新使用。",
    "隐匿施法": "你可以使用灵能能力施放特定法术。",
}

CLASS_FEATURE_DESCRIPTIONS = {
    "动作如风": "你的移动变得极为灵活。你可以用附赠动作执行'离开'动作。",
    "狂暴": "在每场战斗中，你可以进入狂暴状态，获得以下加成：力量或敏捷+2（取较高者）、物理伤害增加、获得Temporary HP。你的狂暴持续1分钟或你陷入失能。",
    "狂暴之力": "你的狂暴攻击造成额外伤害。",
    "先祖守卫": "当一个你能看到的生物在你身边5尺内受到攻击时，你可以用反应来让该生物获得+1AC。如果那次攻击命中，该伤害减少1d6。",
    "牧者之声": "你学会如何使用声音和手势与野兽沟通。你可以用一个动作向一个生物发出简单信号。",
    "引导神力": "你可以引导神圣能量来增强攻击。每次长休后可使用一次，造成额外伤害或治疗。",
    "次级法术": "你学会一些基础法术，可以每天各施放一次。",
    "奥秘传承": "你深入研究魔法奥秘，获得额外的奥秘知识。",
    "奥秘卷轴": "你可以创建魔法卷轴来记录你知道的法术。",
    "战斗风格": "你选择一种战斗风格：防御、攻击、重甲、武器或双武器战斗。",
    "防护魔法": "你学会基础防护法术，可以每天各施放一次。",
    "变形魔法": "你掌握变形法术，可以改变自身形态。",
    "消失": "你可以在自己回合用附赠动作执行'躲藏'动作。",
    "狡诈动作": "你可以在自己回合用附赠动作执行'离开'动作。",
    "灵巧动作": "你可以在自己回合用附赠动作执行'离开'或'躲藏'动作。",
    "诈术": "你的魔法与幻术相互关联，增强欺骗能力。",
    "心灵感应": "你获得了心灵感应能力，可以在短距离内与生物交流。",
    "诗人的灵感": "你用诗歌和音乐鼓舞同伴。当一个生物在你的短休或长休后进行一次攻击检定、豁免检定或技能检定时，你可以为该检定添加一个d20（灵感骰）。",
    "次级祈言": "你学会使用音乐和言语来影响他人，获得更多社交能力。",
    "威名远扬": "你的名声和事迹为你赢得尊重和特殊待遇。",
    "隐秘行动": "你可以在自己回合用附赠动作执行'躲藏'动作。",
    "超魔法": "你可以使用超魔法能力增强法术效果。",
    "治疗术": "你学会治疗魔法。",
    "预兆": "你可以通过掷骰子来预测未来，获得神谕指引。",
    "引导神力（治疗）": "你的引导神力可以治疗生物。",
    "引导神力（攻击）": "你的引导神力可以造成伤害。",
    "引导神力（驱散）": "你的引导神力可以驱散不死生物和妖精。",
    "引导神力（领域）": "你深入研究引导神力的领域力量。",
}

SKILL_DESCRIPTIONS = {
    "运动": "衡量你的体能和耐力，包括攀爬、游泳、跳跃等身体活动。\n影响：攀爬、跳跃、游泳、长跑等",
    "杂技": "衡量你执行杂技动作的能力，如翻滚、保持平衡等。\n影响：翻滚、平衡、翻跟头等",
    "巧手": "衡量你的敏捷性和手指灵活度，用于精细操作。\n影响：开锁、偷窃、欺骗性手部动作等",
    "隐匿": "衡量你躲避观察和听力的能力。\n影响：潜行、躲藏、避免被发现等",
    "奥秘": "衡量你对魔法和神秘知识的研究能力。\n影响：识别魔法效应、辨认奥术符文、研究神秘事物等",
    "历史": "衡量你对历史事件、人物、文明的知识。\n影响：回忆历史事件、识别历史人物、了解古代文明等",
    "调查": "衡量你通过搜索和推理发现问题真相的能力。\n影响：搜索线索、推理分析、解谜等",
    "自然": "衡量你对自然世界和地理的知识。\n影响：识别动植物、了解天气和地形、野外生存等",
    "宗教": "衡量你对神祇、宗教仪式、神话的知识。\n影响：识别神祇、回忆宗教知识、驱散不死生物等",
    "驯兽": "衡量你与动物沟通和照顾它们的能力。\n影响：安抚动物、骑乘动物、动物交流等",
    "洞察": "衡量你判断他人真实意图的能力。\n影响：察言观色、识破谎言、感知欺骗等",
    "医药": "衡量你医疗知识和急救能力。\n影响：诊断疾病、治疗伤口、稳定濒死生物等",
    "察觉": "衡量你感知周围环境的能力。\n影响：发现隐藏生物、感知陷阱、注意细节等",
    "求生": "衡量你在野外生存的能力。\n影响：追踪、觅食、导航、预测天气等",
    "欺瞒": "衡量你用谎言和欺骗他人心智的能力。\n影响：说谎、掩饰、假冒、欺骗等",
    "威吓": "衡量你用威胁、敌意或暴力影响他人的能力。\n影响：恐吓、威胁、胁迫等",
    "表演": "衡量你通过音乐、舞蹈、戏剧等娱乐他人的能力。\n影响：歌唱、演奏、演戏、公众演讲等",
    "说服": "衡量你用理性和逻辑说服他人的能力。\n影响：谈判、游说、建议、辩论等",
}

BACKGROUND_FEATURE_DESCRIPTIONS = {
    "获取典籍": "你可以在旅店或图书馆找到便宜的住处。在城市中，你可以免费获取关于当地的重要信息。",
    "获取卷宗": "你可以使用图书馆查阅所需信息。在查阅前需进行智力（调查）检定，可能需要支付研究费用。",
    "常春盟渊源": "你与常春盟的联系可以帮助你获取某些物品和服务，享受15%的折扣。",
    "同伴追随者": "你在旅途中结识了一些追随者，他们会跟随你冒险并提供帮助。",
    "额外收益": "你的背景为你带来了额外的财富。每次完成冒险后，你会获得额外的金币。",
    "行会会员": "你是特定公会的成员，可以享受公会提供的各种便利和服务。",
    "语言天赋": "你额外学会一门自选语言。",
    "流浪儿背景": "你从小在街头长大，学会了如何躲避麻烦和保护自己。",
    "走私客的联络": "你认识一些不太正当的人物，可以在需要时获得非法物品或信息。",
    "士兵的历练": "你曾在军队中服役，了解战争和军事事务。",
    "水手知识": "你熟悉海洋和水上生活，了解船只和航海知识。",
    "贵族关系": "你与当地贵族有联系，可以获得一定的社会地位和帮助。",
    "远见者": "你预见到未来的某些事件，这为你的决策提供帮助。",
}


def apply_ability_bonus(abilities: AbilityScores, bonus_dict: dict) -> AbilityScores:
    """应用属性加值，同时支持中文和英文键"""
    key_mapping = {
        "力量": "strength", "str": "strength",
        "敏捷": "dexterity", "dex": "dexterity",
        "体质": "constitution", "con": "constitution",
        "智力": "intelligence", "int": "intelligence",
        "感知": "wisdom", "wis": "wisdom",
        "魅力": "charisma", "cha": "charisma"
    }
    
    bonus_values = {
        "strength": 0, "dexterity": 0, "constitution": 0,
        "intelligence": 0, "wisdom": 0, "charisma": 0
    }
    
    for key, value in bonus_dict.items():
        normalized_key = key_mapping.get(key.lower() if isinstance(key, str) else key, key)
        if normalized_key in bonus_values:
            bonus_values[normalized_key] += value
    
    return AbilityScores(
        strength=abilities.strength + bonus_values["strength"],
        dexterity=abilities.dexterity + bonus_values["dexterity"],
        constitution=abilities.constitution + bonus_values["constitution"],
        intelligence=abilities.intelligence + bonus_values["intelligence"],
        wisdom=abilities.wisdom + bonus_values["wisdom"],
        charisma=abilities.charisma + bonus_values["charisma"]
    )


class CreationStep(Enum):
    """建卡步骤枚举"""
    START = "start"
    NAME = "name"
    GENDER = "gender"
    RACE = "race"
    SUBRACE = "subrace"
    CLASS = "class"
    ABILITY = "ability"
    SKILLS = "skills"
    BACKGROUND = "background"
    CONFIRM = "confirm"
    COMPLETE = "complete"


@dataclass
class CharacterCreationState:
    """建卡进度状态"""
    user_id: str
    user_name: str
    step: CreationStep = CreationStep.START

    character_name: Optional[str] = None
    selected_gender: Optional[str] = None
    selected_race: Optional[str] = None
    selected_subrace: Optional[str] = None
    selected_class: Optional[str] = None
    selected_background: Optional[str] = None

    abilities: Optional[AbilityScores] = None
    skill_proficiencies: List[str] = field(default_factory=list)

    available_points: int = 27
    points_spent: int = 0

    created_at: datetime = field(default_factory=datetime.now)

    def to_ability_dict(self) -> Dict[str, int]:
        """转换为属性字典"""
        if self.abilities:
            return {
                "力量": self.abilities.strength,
                "敏捷": self.abilities.dexterity,
                "体质": self.abilities.constitution,
                "智力": self.abilities.intelligence,
                "感知": self.abilities.wisdom,
                "魅力": self.abilities.charisma
            }
        return {
            "力量": 8, "敏捷": 8, "体质": 8,
            "智力": 8, "感知": 8, "魅力": 8
        }

    def remaining_points(self) -> int:
        """剩余点数"""
        return self.available_points - self.points_spent


class PointBuyCalculator:
    """27点购点计算器"""

    POINT_COSTS = {
        8: 0, 9: 1, 10: 2, 11: 3, 12: 4,
        13: 5, 14: 7, 15: 9
    }

    ATTRIBUTE_NAMES_CN = ["力量", "敏捷", "体质", "智力", "感知", "魅力"]
    ATTRIBUTE_NAMES_EN = ["strength", "dexterity", "constitution", "intelligence", "wisdom", "charisma"]

    @classmethod
    def get_cost(cls, value: int) -> int:
        """获取属性值对应的点数花费"""
        return cls.POINT_COSTS.get(value, 0)

    @classmethod
    def can_increase(cls, current_value: int) -> bool:
        """是否可以增加属性"""
        return current_value < 15

    @classmethod
    def can_decrease(cls, current_value: int) -> bool:
        """是否可以降低属性"""
        return current_value > 8

    @classmethod
    def get_max_increase_cost(cls, current_value: int) -> int:
        """获取增加到最大值需要的点数"""
        return cls.get_cost(15) - cls.get_cost(current_value)

    @classmethod
    def normalize_attribute_input(cls, input_str: str) -> Optional[str]:
        """标准化属性输入"""
        input_str = input_str.strip().lower()

        mapping = {
            "1": "力量", "str": "力量", "力量": "力量",
            "2": "敏捷", "dex": "敏捷", "敏捷": "敏捷",
            "3": "体质", "con": "体质", "体质": "体质",
            "4": "智力", "int": "智力", "智力": "智力",
            "5": "感知", "wis": "感知", "感知": "感知",
            "6": "魅力", "cha": "魅力", "魅力": "魅力"
        }

        return mapping.get(input_str)

    @classmethod
    def parse_adjustment(cls, input_str: str) -> Tuple[Optional[str], int, bool]:
        """解析调整输入

        Returns:
            (属性名, 调整量, 是否有效)
        """
        input_str = input_str.strip()

        for attr_cn in cls.ATTRIBUTE_NAMES_CN:
            if input_str.startswith(attr_cn):
                remainder = input_str[len(attr_cn):].strip()
                if remainder.startswith("+"):
                    try:
                        return attr_cn, int(remainder[1:]), True
                    except ValueError:
                        pass
                elif remainder.startswith("-"):
                    try:
                        return attr_cn, int(remainder), True
                    except ValueError:
                        pass
                elif remainder == "":
                    return attr_cn, 1, True

        if len(input_str) >= 2:
            attr_idx = None
            try:
                attr_num = int(input_str[0])
                if 1 <= attr_num <= 6:
                    attr_idx = cls.ATTRIBUTE_NAMES_CN[attr_num - 1]
            except ValueError:
                pass

            if attr_idx:
                remainder = input_str[1:].strip()
                if remainder.startswith("+"):
                    try:
                        return attr_idx, int(remainder[1:]), True
                    except ValueError:
                        pass
                elif remainder.startswith("-"):
                    try:
                        return attr_idx, int(remainder), True
                    except ValueError:
                        pass
                elif remainder == "":
                    return attr_idx, 1, True

        return None, 0, False


class CharacterCreator:
    """交互式建卡管理器"""

    def __init__(self):
        self._states: Dict[str, CharacterCreationState] = {}

    def get_state(self, user_id: str) -> Optional[CharacterCreationState]:
        """获取用户的建卡状态"""
        return self._states.get(user_id)

    def has_active_creation(self, user_id: str) -> bool:
        """检查是否有进行中的建卡"""
        state = self.get_state(user_id)
        return state is not None and state.step != CreationStep.COMPLETE

    def start_creation(self, user_id: str, user_name: str) -> CharacterCreationState:
        """开始新的建卡流程"""
        state = CharacterCreationState(
            user_id=user_id,
            user_name=user_name,
            step=CreationStep.NAME
        )
        self._states[user_id] = state
        return state

    def clear_state(self, user_id: str):
        """清除建卡状态"""
        if user_id in self._states:
            del self._states[user_id]

    def update_name(self, user_id: str, name: str) -> Tuple[bool, str]:
        """设置角色名称"""
        state = self.get_state(user_id)
        if not state:
            return False, "没有进行中的建卡"

        name = name.strip()
        if len(name) < 1:
            return False, "角色名称不能为空"
        if len(name) > 20:
            return False, "角色名称不能超过20个字符"

        state.character_name = name
        state.step = CreationStep.GENDER
        return True, "gender"

    def update_gender(self, user_id: str, gender: str) -> Tuple[bool, str]:
        """选择性别"""
        state = self.get_state(user_id)
        if not state:
            return False, "没有进行中的建卡"

        gender = gender.strip()

        gender_aliases = {
            "1": "男", "男性": "男", "男": "男", "雄": "男", "male": "男", "m": "男",
            "2": "女", "女性": "女", "女": "女", "雌": "女", "female": "女", "f": "女",
            "3": "无", "无": "无", "无性别": "无", "中性": "无", "none": "无", "n": "无",
            "4": "多元", "多元": "多元", "其他": "多元", "other": "多元", "o": "多元",
        }

        normalized_gender = gender_aliases.get(gender.lower() if gender.lower() in ["male", "female", "none", "other", "m", "f", "n", "o"] else gender)

        if gender.lower() in ["male", "m"]:
            normalized_gender = "男"
        elif gender.lower() in ["female", "f"]:
            normalized_gender = "女"
        elif gender.lower() in ["none", "n"]:
            normalized_gender = "无"
        elif gender.lower() in ["other", "o"]:
            normalized_gender = "多元"
        elif gender in ["1", "男性", "男", "雄"]:
            normalized_gender = "男"
        elif gender in ["2", "女性", "女", "雌"]:
            normalized_gender = "女"
        elif gender in ["3", "无", "无性别", "中性"]:
            normalized_gender = "无"
        elif gender in ["4", "多元", "其他"]:
            normalized_gender = "多元"
        else:
            return False, f"未知的性别选项: {gender}\n请输入 1-4 或 男/女/无/多元"

        state.selected_gender = normalized_gender
        state.step = CreationStep.RACE
        return True, "race"

    def update_race(self, user_id: str, race_name: str) -> Tuple[bool, str]:
        """选择种族"""
        state = self.get_state(user_id)
        if not state:
            return False, "没有进行中的建卡"

        race = RaceDatabase.get_race(race_name)
        if not race:
            return False, f"未找到种族: {race_name}"

        state.selected_race = race_name

        if race.subraces:
            state.step = CreationStep.SUBRACE
            return True, "subrace"
        else:
            state.step = CreationStep.CLASS
            return True, "class"

    def update_subrace(self, user_id: str, subrace_name: str) -> Tuple[bool, str]:
        """选择亚种"""
        state = self.get_state(user_id)
        if not state:
            return False, "没有进行中的建卡"

        subrace = RaceDatabase.get_subrace(state.selected_race, subrace_name)
        if not subrace:
            return False, f"未找到亚种: {subrace_name}"

        state.selected_subrace = subrace_name
        state.step = CreationStep.CLASS
        return True, "class"

    def update_class(self, user_id: str, class_name: str) -> Tuple[bool, str]:
        """选择职业"""
        state = self.get_state(user_id)
        if not state:
            return False, "没有进行中的建卡"

        dnd_class = ClassDatabase.get_class(class_name)
        if not dnd_class:
            return False, f"未找到职业: {class_name}"

        state.selected_class = class_name
        state.abilities = AbilityScores()
        state.step = CreationStep.ABILITY
        return True, "ability"

    def update_abilities(self, user_id: str, ability_str: str) -> Tuple[bool, str, Optional[str]]:
        """更新属性

        Returns:
            (是否成功, 消息, 下一个步骤或None)
        """
        state = self.get_state(user_id)
        if not state:
            return False, "没有进行中的建卡", None

        if ability_str in ["完成", "确认", "done", "confirm"]:
            state.step = CreationStep.SKILLS
            return True, "属性分配完成", "skills"

        if ability_str in ["重置", "reset"]:
            state.abilities = AbilityScores()
            state.points_spent = 0
            return True, "属性已重置为初始值", None

        if ability_str in ["战士", "str", "力量型"]:
            return self._apply_preset(state, "战士")
        if ability_str in ["法师", "int", "智力型"]:
            return self._apply_preset(state, "法师")
        if ability_str in ["盗贼", "dex", "敏捷型"]:
            return self._apply_preset(state, "盗贼")
        if ability_str in ["牧师", "wis", "感知型"]:
            return self._apply_preset(state, "牧师")
        if ability_str in ["游侠"]:
            return self._apply_preset(state, "游侠")
        if ability_str in ["圣武士", "paladin"]:
            return self._apply_preset(state, "圣武士")
        if ability_str in ["吟游诗人", "bard"]:
            return self._apply_preset(state, "吟游诗人")
        if ability_str in ["野蛮人", "barbarian"]:
            return self._apply_preset(state, "野蛮人")
        if ability_str in ["僧侣", "monk"]:
            return self._apply_preset(state, "僧侣")
        if ability_str in ["德鲁伊", "druid"]:
            return self._apply_preset(state, "德鲁伊")
        if ability_str in ["术士", "sorcerer"]:
            return self._apply_preset(state, "术士")
        if ability_str in ["奇械师", "artificer"]:
            return self._apply_preset(state, "奇械师")
        if ability_str in ["cha", "魅力型"]:
            return self._apply_preset(state, "魅力型")

        parts = ability_str.replace(",", " ").replace("，", " ").replace("、", " ").split()
        if len(parts) > 1:
            return self._batch_update_abilities(state, parts)

        attr_name, adjust, valid = PointBuyCalculator.parse_adjustment(ability_str)
        if not valid:
            return False, f"无法解析输入: {ability_str}\n💡 可用命令: 力量+1, 完成, 重置, 战士, 法师 等", None

        return self._single_update_ability(state, attr_name, adjust)

    def _single_update_ability(self, state: CharacterCreationState, attr_name: str, adjust: int) -> Tuple[bool, str, Optional[str]]:
        """单个属性更新"""
        abilities = state.to_ability_dict()
        current_value = abilities.get(attr_name, 8)

        if adjust > 0:
            if not PointBuyCalculator.can_increase(current_value):
                return False, f"{attr_name}已达最大值15", None

            new_value = min(current_value + adjust, 15)
            new_cost = PointBuyCalculator.get_cost(new_value)
            old_cost = PointBuyCalculator.get_cost(current_value)
            cost_diff = new_cost - old_cost

            if cost_diff > state.remaining_points():
                return False, f"点数不足！需要{cost_diff}点，剩余{state.remaining_points()}点", None

            abilities[attr_name] = new_value
            state.points_spent += cost_diff

        elif adjust < 0:
            if not PointBuyCalculator.can_decrease(current_value):
                return False, f"{attr_name}已至最小值8", None

            new_value = max(current_value + adjust, 8)
            new_cost = PointBuyCalculator.get_cost(new_value)
            old_cost = PointBuyCalculator.get_cost(current_value)
            cost_diff = old_cost - new_cost

            abilities[attr_name] = new_value
            state.points_spent -= cost_diff

        state.abilities = AbilityScores(
            strength=abilities["力量"],
            dexterity=abilities["敏捷"],
            constitution=abilities["体质"],
            intelligence=abilities["智力"],
            wisdom=abilities["感知"],
            charisma=abilities["魅力"]
        )

        return True, f"已将{attr_name}调整为{new_value}", None

    def _batch_update_abilities(self, state: CharacterCreationState, parts: list) -> Tuple[bool, str, Optional[str]]:
        """批量更新属性"""
        results = []
        abilities = state.to_ability_dict()
        points_spent = state.points_spent

        for part in parts:
            attr_name, adjust, valid = PointBuyCalculator.parse_adjustment(part)
            if not valid:
                continue
            current_value = abilities.get(attr_name, 8)

            if adjust > 0:
                if not PointBuyCalculator.can_increase(current_value):
                    results.append(f"{attr_name}已达上限")
                    continue
                new_value = min(current_value + adjust, 15)
                new_cost = PointBuyCalculator.get_cost(new_value)
                old_cost = PointBuyCalculator.get_cost(current_value)
                cost_diff = new_cost - old_cost
                if cost_diff > (27 - points_spent):
                    results.append(f"{attr_name}点数不足")
                    continue
                abilities[attr_name] = new_value
                points_spent += cost_diff
                results.append(f"{attr_name}→{new_value}")

            elif adjust < 0:
                if not PointBuyCalculator.can_decrease(current_value):
                    results.append(f"{attr_name}已达下限")
                    continue
                new_value = max(current_value + adjust, 8)
                old_cost = PointBuyCalculator.get_cost(current_value)
                new_cost = PointBuyCalculator.get_cost(new_value)
                abilities[attr_name] = new_value
                points_spent -= (old_cost - new_cost)
                results.append(f"{attr_name}→{new_value}")

        state.abilities = AbilityScores(
            strength=abilities["力量"],
            dexterity=abilities["敏捷"],
            constitution=abilities["体质"],
            intelligence=abilities["智力"],
            wisdom=abilities["感知"],
            charisma=abilities["魅力"]
        )
        state.points_spent = points_spent

        return True, f"批量调整: {', '.join(results)}", None

    def _apply_preset(self, state: CharacterCreationState, preset: str) -> Tuple[bool, str, Optional[str]]:
        """应用预设属性分配"""
        presets = {
            "战士": {"力量": 15, "体质": 14, "敏捷": 13, "智力": 10, "感知": 10, "魅力": 8},  # 9+7+5+2+2+0=27
            "法师": {"智力": 15, "敏捷": 14, "体质": 13, "魅力": 10, "感知": 10, "力量": 8},  # 9+7+5+2+2+0=27
            "盗贼": {"敏捷": 15, "智力": 14, "魅力": 13, "体质": 10, "感知": 10, "力量": 8},  # 9+7+5+2+2+0=27
            "牧师": {"感知": 15, "魅力": 14, "体质": 13, "智力": 10, "敏捷": 10, "力量": 8},  # 9+7+5+2+2+0=27
            "游侠": {"敏捷": 15, "感知": 14, "体质": 13, "智力": 10, "魅力": 10, "力量": 8},  # 9+7+5+2+2+0=27
            "圣武士": {"力量": 15, "魅力": 14, "体质": 13, "感知": 10, "智力": 10, "敏捷": 8},  # 9+7+5+2+2+0=27
            "吟游诗人": {"魅力": 15, "敏捷": 14, "体质": 13, "感知": 10, "智力": 10, "力量": 8},  # 9+7+5+2+2+0=27
            "野蛮人": {"力量": 15, "体质": 14, "敏捷": 13, "感知": 10, "魅力": 10, "智力": 8},  # 9+7+5+2+2+0=27
            "僧侣": {"敏捷": 15, "力量": 14, "体质": 13, "感知": 10, "智力": 10, "魅力": 8},  # 9+7+5+2+2+0=27
            "德鲁伊": {"感知": 15, "智力": 14, "体质": 13, "敏捷": 10, "魅力": 10, "力量": 8},  # 9+7+5+2+2+0=27
            "术士": {"魅力": 15, "体质": 14, "敏捷": 13, "感知": 10, "智力": 10, "力量": 8},  # 9+7+5+2+2+0=27
            "奇械师": {"智力": 15, "体质": 14, "敏捷": 13, "感知": 10, "魅力": 10, "力量": 8},  # 9+7+5+2+2+0=27
            "感知型": {"感知": 15, "智力": 14, "敏捷": 13, "体质": 10, "魅力": 10, "力量": 8},  # 9+7+5+2+2+0=27
            "魅力型": {"魅力": 15, "感知": 14, "敏捷": 13, "体质": 10, "智力": 10, "力量": 8},  # 9+7+5+2+2+0=27
        }

        preset_aliases = {
            "战士": "战士",
            "法师": "法师",
            "盗贼": "盗贼",
            "牧师": "牧师",
            "游侠": "游侠",
            "圣武士": "圣武士",
            "吟游诗人": "吟游诗人",
            "野蛮人": "野蛮人",
            "僧侣": "僧侣",
            "德鲁伊": "德鲁伊",
            "术士": "术士",
            "奇械师": "奇械师",
            "str": "战士",
            "力量型": "战士",
            "int": "法师",
            "智力型": "法师",
            "dex": "盗贼",
            "敏捷型": "盗贼",
            "wis": "感知型",
            "cha": "魅力型",
        }

        preset = preset_aliases.get(preset, preset)
        preset_values = presets.get(preset, {})
        if not preset_values:
            available = list(presets.keys()) + list(preset_aliases.keys())
            return False, f"未知的预设。可用预设: {', '.join(available)}", None

        abilities = state.to_ability_dict()
        total_cost = 0
        for attr, value in preset_values.items():
            total_cost += PointBuyCalculator.get_cost(value)

        if total_cost > 27:
            return False, f"预设分配需要{total_cost}点，超出27点限制", None

        for attr, value in preset_values.items():
            abilities[attr] = value

        state.abilities = AbilityScores(
            strength=abilities["力量"],
            dexterity=abilities["敏捷"],
            constitution=abilities["体质"],
            intelligence=abilities["智力"],
            wisdom=abilities["感知"],
            charisma=abilities["魅力"]
        )
        state.points_spent = total_cost
        remaining = 27 - total_cost

        return True, f"已应用{preset}预设（花费{total_cost}点，剩余{remaining}点可微调）", None

    def update_skills(self, user_id: str, skill_input: str) -> Tuple[bool, str, Optional[str]]:
        """更新技能熟练选择"""
        state = self.get_state(user_id)
        if not state:
            return False, "没有进行中的建卡", None

        dnd_class = ClassDatabase.get_class(state.selected_class)
        if not dnd_class:
            return False, "职业数据不存在", None

        max_skills = dnd_class.skill_choices

        if skill_input in ["完成", "确认", "done", "confirm"]:
            if len(state.skill_proficiencies) < max_skills:
                return False, f"还需选择{max_skills - len(state.skill_proficiencies)}项技能", None
            state.step = CreationStep.BACKGROUND
            return True, "技能选择完成", "background"

        skill_input = skill_input.strip()
        skills_to_add = [s.strip() for s in skill_input.replace(",", "、").replace("，", "、").replace("、", "、").replace("/", "、").split("、")]
        skills_to_add = [s for s in skills_to_add if s]

        available = dnd_class.available_skills
        newly_added = []

        for skill in skills_to_add:
            if skill in available and skill not in state.skill_proficiencies:
                if len(state.skill_proficiencies) >= max_skills:
                    continue
                state.skill_proficiencies.append(skill)
                newly_added.append(skill)

        remaining = max_skills - len(state.skill_proficiencies)

        if len(state.skill_proficiencies) >= max_skills:
            state.step = CreationStep.BACKGROUND
            return True, f"已选择: {', '.join(state.skill_proficiencies)} ({len(state.skill_proficiencies)}/{max_skills})\n✨ 技能选择完成！", "background"

        if newly_added:
            return True, f"已选择: {', '.join(state.skill_proficiencies)} ({remaining}/{max_skills})", None
        elif skills_to_add:
            return True, f"已选择: {', '.join(state.skill_proficiencies) if state.skill_proficiencies else '无'} ({remaining}/{max_skills})", None
        else:
            return True, f"已选择: {', '.join(state.skill_proficiencies) if state.skill_proficiencies else '无'} ({remaining}/{max_skills})", None

    def update_background(self, user_id: str, bg_name: str) -> Tuple[bool, str]:
        """选择背景"""
        state = self.get_state(user_id)
        if not state:
            return False, "没有进行中的建卡"

        bg = BackgroundDatabase.get_background(bg_name)
        if not bg:
            return False, f"未找到背景: {bg_name}"

        state.selected_background = bg_name
        state.step = CreationStep.CONFIRM
        return True, "confirm"

    def confirm_creation(self, user_id: str) -> Tuple[bool, Optional[Character], str]:
        """确认并创建角色"""
        state = self.get_state(user_id)
        if not state:
            return False, None, "没有进行中的建卡"

        if state.step != CreationStep.CONFIRM:
            return False, None, "请先完成所有步骤"

        race_data = RaceDatabase.get_race(state.selected_race)
        class_data = ClassDatabase.get_class(state.selected_class)

        # 验证关键数据存在
        if not race_data:
            return False, None, f"种族数据不存在: {state.selected_race}"
        if not class_data:
            return False, None, f"职业数据不存在: {state.selected_class}"
        if not state.abilities:
            return False, None, "属性数据不存在，请重新分配属性"
        if len(state.skill_proficiencies) < class_data.skill_choices:
            return False, None, f"还需要选择 {class_data.skill_choices - len(state.skill_proficiencies)} 个技能"
        if not state.selected_background:
            return False, None, "请选择一个背景"

        final_abilities = state.abilities
        if race_data:
            final_abilities = apply_ability_bonus(final_abilities, race_data.ability_bonus)

        if state.selected_subrace:
            subrace = RaceDatabase.get_subrace(state.selected_race, state.selected_subrace)
            if subrace:
                final_abilities = apply_ability_bonus(final_abilities, subrace.ability_bonus)

        con_mod = AbilityScores(
            strength=final_abilities.strength,
            dexterity=final_abilities.dexterity,
            constitution=final_abilities.constitution,
            intelligence=final_abilities.intelligence,
            wisdom=final_abilities.wisdom,
            charisma=final_abilities.charisma
        ).get_modifier("constitution")

        max_hp = class_data.hit_die + con_mod

        char_name = state.character_name if state.character_name else state.user_name

        char = Character(
            name=char_name,
            player_id=state.user_id,
            level=1,
            abilities=final_abilities,
            class_name=state.selected_class,
            race=state.selected_race,
            subrace=state.selected_subrace if state.selected_subrace else "",
            gender=state.selected_gender if state.selected_gender else "",
            background=state.selected_background,
            hit_points=max_hp,
            max_hit_points=max_hp,
            armor_class=10 + AbilityScores(
                strength=final_abilities.strength,
                dexterity=final_abilities.dexterity,
                constitution=final_abilities.constitution,
                intelligence=final_abilities.intelligence,
                wisdom=final_abilities.wisdom,
                charisma=final_abilities.charisma
            ).get_modifier("dexterity"),
            skill_proficiencies=state.skill_proficiencies.copy()
        )

        state.step = CreationStep.COMPLETE
        return True, char, "角色创建成功"

    def get_current_prompt(self, user_id: str) -> Optional[str]:
        """获取当前步骤的提示文本"""
        state = self.get_state(user_id)
        if not state:
            return None

        if state.step == CreationStep.NAME:
            return self._get_name_prompt()
        elif state.step == CreationStep.GENDER:
            return self._get_gender_prompt()
        elif state.step == CreationStep.RACE:
            return self._get_race_prompt()
        elif state.step == CreationStep.SUBRACE:
            return self._get_subrace_prompt(state)
        elif state.step == CreationStep.CLASS:
            return self._get_class_prompt(state)
        elif state.step == CreationStep.ABILITY:
            return self._get_ability_prompt(state)
        elif state.step == CreationStep.SKILLS:
            return self._get_skills_prompt(state)
        elif state.step == CreationStep.BACKGROUND:
            return self._get_background_prompt()
        elif state.step == CreationStep.CONFIRM:
            return self._get_confirm_prompt(state)

        return None

    def _get_name_prompt(self) -> str:
        """角色名称输入提示"""
        prompt = "📝 步骤1: 设定角色名称\n\n"
        prompt += "请为你的角色取一个名字：\n"
        prompt += "━━━━━━━━━━━━━━━━━━━━\n"
        prompt += "💡 回复格式: /dnd 建卡 <角色名>\n"
        prompt += "   例如: /dnd 建卡 阿尔萨斯\n"
        prompt += "   （名称长度: 1-20个字符）"
        return prompt

    def _get_gender_prompt(self) -> str:
        """性别选择提示"""
        prompt = "⚧ 步骤2: 选择性别\n\n"
        prompt += "请选择你的角色性别：\n"
        prompt += "━━━━━━━━━━━━━━━━━━━━\n"
        prompt += "1. ♂ 男性\n"
        prompt += "2. ♀ 女性\n"
        prompt += "3. ⚪ 无性别\n"
        prompt += "4. 🟡 多元性别\n"
        prompt += "━━━━━━━━━━━━━━━━━━━━\n"
        prompt += "💡 回复格式: /dnd 建卡 <选项>\n"
        prompt += "   例如: /dnd 建卡 1   或   /dnd 建卡 男"
        return prompt

    def _get_race_prompt(self) -> str:
        """种族选择简洁提示"""
        prompt = "🌍 步骤3: 选择种族\n\n"
        prompt += "请选择你的种族：\n"
        prompt += "━━━━━━━━━━━━━━━━━━━━\n"

        races = RaceDatabase.get_all_races()
        for i, race_name in enumerate(races, 1):
            race = RaceDatabase.get_race(race_name)
            bonus_str = ", ".join([f"{k}+{v}" for k, v in race.ability_bonus.items() if v > 0])
            subrace_info = " ⭐" if race.subraces else ""
            prompt += f"{i}. {race_name:6} - {bonus_str}{subrace_info}\n"

        prompt += "\n━━━━━━━━━━━━━━━━━━━━\n"
        prompt += "💡 回复格式: /dnd 建卡 <数字>  或  /dnd 建卡 <种族名>"
        return prompt

    def _get_race_detail(self) -> list:
        """种族选择详细版本（用于合并转发）"""
        races = RaceDatabase.get_all_races()
        messages = []

        for race_name in races:
            race = RaceDatabase.get_race(race_name)
            msg = f"🌍 {race_name}\n"
            msg += f"━━━━━━━━━━━━━━━━━━━━\n"
            msg += f"📖 {race.description}\n\n"
            msg += f"📊 属性加成: "
            bonus_parts = []
            for attr, val in race.ability_bonus.items():
                if val > 0:
                    bonus_parts.append(f"{attr}+{val}")
            msg += ", ".join(bonus_parts) + "\n"
            msg += f"⚡ 速度: {race.speed}尺\n"
            if race.darkvision > 0:
                msg += f"👁 黑暗视觉: {race.darkvision}尺\n"
            if race.languages:
                msg += f"🌐 语言: {', '.join(race.languages)}\n"
            if race.traits:
                msg += f"\n✨ 种族特性:\n"
                for trait in race.traits[:4]:
                    desc = RACE_TRAIT_DESCRIPTIONS.get(trait, "")
                    msg += f"  • {trait}\n"
                    if desc:
                        msg += f"    {desc}\n"
            if race.subraces:
                msg += f"\n⭐ 亚种选项: "
                msg += ", ".join([s.name_cn for s in race.subraces])
            messages.append(msg)

        return messages

    def _get_subrace_prompt(self, state: CharacterCreationState) -> str:
        """亚种选择提示"""
        race = RaceDatabase.get_race(state.selected_race)
        if not race or not race.subraces:
            return ""

        prompt = f"🌿 步骤3.5: 选择{state.selected_race}亚种\n\n"
        prompt += f"请选择亚种（已选种族: {state.selected_race}）：\n"
        prompt += "━━━━━━━━━━━━━━━━━━━━\n"

        for i, subrace in enumerate(race.subraces, 1):
            bonus_str = ", ".join([f"{k}+{v}" for k, v in subrace.ability_bonus.items()])
            prompt += f"{i}. {subrace.name_cn} - {bonus_str}\n"
            if subrace.traits:
                prompt += f"   {', '.join(subrace.traits[:2])}\n"

        prompt += "\n━━━━━━━━━━━━━━━━━━━━\n"
        prompt += "💡 回复格式: /dnd 建卡 <数字>  或  /dnd 建卡 <亚种名>\n"
        prompt += "   例如: /dnd 建卡 1   或   /dnd 建卡 高等精灵"
        return prompt

    def _get_class_prompt(self, state: CharacterCreationState) -> str:
        """职业选择简洁提示"""
        race_str = state.selected_race
        if state.selected_subrace:
            race_str += f"({state.selected_subrace})"

        prompt = f"⚔️ 步骤4: 选择职业\n\n"
        prompt += f"请选择你的职业（已选种族: {race_str}）：\n"
        prompt += "━━━━━━━━━━━━━━━━━━━━\n"

        classes = ClassDatabase.get_all_classes()
        for i, class_name in enumerate(classes, 1):
            cls_data = ClassDatabase.get_class(class_name)
            prompt += f"{i}. {class_name:4} d{cls_data.hit_die} HP | 可选{cls_data.skill_choices}项技能\n"

        prompt += "\n━━━━━━━━━━━━━━━━━━━━\n"
        prompt += "💡 回复格式: /dnd 建卡 <数字>  或  /dnd 建卡 <职业名>"
        return prompt

    def _get_class_detail(self) -> list:
        """职业选择详细版本（用于合并转发）"""
        classes = ClassDatabase.get_all_classes()
        messages = []

        for class_name in classes:
            cls_data = ClassDatabase.get_class(class_name)
            msg = f"⚔️ {class_name}\n"
            msg += f"━━━━━━━━━━━━━━━━━━━━\n"
            msg += f"📖 {cls_data.description}\n\n"
            msg += f"🎲 生命骰: d{cls_data.hit_die}\n"
            msg += f"💪 主要属性: {', '.join(cls_data.primary_ability)}\n"
            msg += f"🛡️ 豁免熟练: {', '.join(cls_data.saving_throws)}\n"
            if cls_data.armor_proficiencies:
                msg += f"🛡️ 护甲熟练: {', '.join(cls_data.armor_proficiencies)}\n"
            if cls_data.weapon_proficiencies:
                msg += f"⚔️ 武器熟练: {', '.join(cls_data.weapon_proficiencies)}\n"
            msg += f"\n🎯 可选技能: {cls_data.skill_choices}项\n"
            msg += f"   {', '.join(cls_data.available_skills)}\n"
            if cls_data.spellcasting_ability:
                msg += f"\n✨ 法术施法: {cls_data.spellcasting_ability}\n"
            if cls_data.features:
                msg += f"\n🌟 职业特性:\n"
                for feature in cls_data.features[:4]:
                    desc = CLASS_FEATURE_DESCRIPTIONS.get(feature, "")
                    msg += f"  • {feature}\n"
                    if desc:
                        msg += f"    {desc}\n"
            messages.append(msg)

        return messages

    def _get_skill_detail(self, state: CharacterCreationState) -> list:
        """技能选择详细版本（用于合并转发）"""
        cls_data = ClassDatabase.get_class(state.selected_class)
        if not cls_data:
            return []

        max_skills = cls_data.skill_choices
        available = cls_data.available_skills
        messages = []

        skill_groups = {
            "💪 力量系": ["运动"],
            "🏃 敏捷系": ["杂技", "巧手", "隐匿"],
            "📚 智力系": ["奥秘", "历史", "调查", "自然", "宗教"],
            "👁 感知系": ["驯兽", "洞察", "医药", "察觉", "求生"],
            "✨ 魅力系": ["欺瞒", "威吓", "表演", "说服"]
        }

        for group_name, skills in skill_groups.items():
            available_in_group = [s for s in skills if s in available]
            if available_in_group:
                msg = f"{group_name}\n"
                for skill in available_in_group:
                    ability = Skills.SKILL_ABILITY_MAP.get(skill, "strength")
                    ability_cn = {"strength": "力量", "dexterity": "敏捷", "intelligence": "智力", "wisdom": "感知", "charisma": "魅力"}.get(ability, ability)
                    desc = SKILL_DESCRIPTIONS.get(skill, "")
                    msg += f"  • {skill} ({ability_cn})\n"
                    if desc:
                        msg += f"    {desc}\n"
                messages.append(msg)

        return messages

    def _get_ability_prompt(self, state: CharacterCreationState) -> str:
        """属性分配提示"""
        abilities = state.to_ability_dict()

        prompt = f"📊 步骤5: 属性分配（27点购点制）\n\n"
        prompt += "━━━━━━━━━━━━━━━━━━━━\n"
        prompt += f"📍 剩余点数: {state.remaining_points()} / 27\n"
        prompt += "━━━━━━━━━━━━━━━━━━━━\n\n"

        ability_keys = ["力量", "敏捷", "体质", "智力", "感知", "魅力"]
        emojis = ["💪", "🏃", "💚", "📚", "👁", "✨"]

        for i, (attr, emoji) in enumerate(zip(ability_keys, emojis), 1):
            value = abilities.get(attr, 8)
            mod = (value - 10) // 2
            cost = PointBuyCalculator.get_cost(value)
            mod_str = f"+{mod}" if mod >= 0 else str(mod)
            prompt += f"{i}. {emoji} {attr}: {value} (调整值 {mod_str}) [花费: {cost}点]\n"

        prompt += "\n━━━━━━━━━━━━━━━━━━━━\n"
        prompt += "💡 回复格式: /dnd 建卡 <属性>+/-数值\n"
        prompt += "   例如: /dnd 建卡 力量+2\n\n"
        prompt += "• 批量调整: /dnd 建卡 力量+2 敏捷+1\n"
        prompt += "• 一键预设: /dnd 建卡 战士（详见合并卡片）\n"
        prompt += "• 确认完成: /dnd 建卡 完成\n"
        prompt += "• 重置属性: /dnd 建卡 重置"

        return prompt

    def _get_ability_detail(self, state: CharacterCreationState) -> list:
        """属性分配详细版本（用于合并转发）"""
        race = RaceDatabase.get_race(state.selected_race) if state.selected_race else None
        subrace = RaceDatabase.get_subrace(state.selected_race, state.selected_subrace) if state.selected_subrace else None
        cls_data = ClassDatabase.get_class(state.selected_class) if state.selected_class else None

        messages = []

        msg1 = f"📊 属性分配说明\n"
        msg1 += f"━━━━━━━━━━━━━━━━━━━━\n"
        msg1 += f"🎯 本步骤使用27点购点制分配属性\n\n"
        msg1 += f"📍 属性点来源:\n"
        msg1 += f"• 基础分配: 27点（可自由分配）\n"
        if race:
            race_bonus = race.ability_bonus
            bonus_parts = [f"{k}+{v}" for k, v in race_bonus.items() if v > 0]
            if bonus_parts:
                msg1 += f"• 种族加成: +{', '.join(bonus_parts)}（{race.name_cn}）\n"
        if subrace:
            subrace_bonus = subrace.ability_bonus
            bonus_parts = [f"{k}+{v}" for k, v in subrace_bonus.items() if v > 0]
            if bonus_parts:
                msg1 += f"• 亚种加成: +{', '.join(bonus_parts)}（{subrace.name_cn}）\n"
        msg1 += f"\n💡 详细属性说明:\n"
        msg1 += f"• 力量: 影响近战伤害、跳跃、攀爬\n"
        msg1 += f"• 敏捷: 影响AC、反射豁免、远程攻击\n"
        msg1 += f"• 体质: 影响HP、毒性豁免\n"
        msg1 += f"• 智力: 影响法术伤害、记忆解谜\n"
        msg1 += f"• 感知: 影响感知检定、法术辅助\n"
        msg1 += f"• 魅力: 影响社交、法术引导\n"
        messages.append(msg1)

        preset_descriptions = [
            ("战士", "力量↑↑ 体质↑ 敏捷↓", "适合近战战斗，追求高伤害和生存能力"),
            ("法师", "智力↑↑ 敏捷↑ 体质↓", "追求高法术伤害和防御，适合魔法输出"),
            ("盗贼", "敏捷↑↑ 智力↑ 魅力↑", "高闪避和社交能力，适合潜行和欺骗"),
            ("牧师", "感知↑↑ 魅力↑ 体质↓", "追求治疗和辅助，适合支援角色"),
            ("游侠", "敏捷↑↑ 感知↑ 体质↓", "平衡型战士，擅长远程和自然知识"),
            ("圣武士", "力量↑↑ 魅力↑ 体质↓", "力量与魅力并重，适合神圣战斗"),
            ("吟游诗人", "魅力↑↑ 敏捷↑ 体质↓", "社交达人，多才多艺的表演者"),
            ("野蛮人", "力量↑↑ 体质↑ 敏捷↓", "纯近战战士，高伤害和高HP"),
            ("僧侣", "敏捷↑↑ 力量↑ 体质↓", "速度型战士，擅长徒手格斗"),
            ("德鲁伊", "感知↑↑ 智力↑ 体质↓", "自然法师，变形和自然魔法"),
            ("术士", "魅力↑↑ 体质↑ 敏捷↓", "天生施法者，血统决定魔法"),
            ("奇械师", "智力↑↑ 体质↑ 敏捷↓", "发明家，用科技和魔法创造奇迹"),
            ("感知型", "感知↑↑ 智力↑ 敏捷↓", "感知型角色，适合察觉和求生"),
            ("魅力型", "魅力↑↑ 感知↑ 敏捷↓", "魅力型角色，适合社交和说服"),
            ("智力型", "智力↑↑ 敏捷↑ 体质↓", "智力型角色，适合解谜和魔法"),
        ]

        msg2 = f"📋 一键预设分配方案\n"
        msg2 += f"━━━━━━━━━━━━━━━━━━━━\n"
        msg2 += f"🎯 输入职业名即可一键应用预设\n\n"
        for name, stats, desc in preset_descriptions:
            msg2 += f"⚔️ {name}: {stats}\n"
            msg2 += f"   {desc}\n\n"
        messages.append(msg2)

        msg3 = f"📖 详细属性说明\n"
        msg3 += f"━━━━━━━━━━━━━━━━━━━━\n"
        msg3 += f"💪 力量 (STR)\n"
        msg3 += f"   影响: 近战攻击伤害、跳跃距离、攀爬能力\n"
        msg3 += f"   关键技能: 运动\n\n"
        msg3 += f"🏃 敏捷 (DEX)\n"
        msg3 += f"   影响: AC、反射豁免、反射速度、远程攻击\n"
        msg3 += f"   关键技能: 杂技、巧手、隐匿\n\n"
        msg3 += f"💚 体质 (CON)\n"
        msg3 += f"   影响: 最大HP、毒性豁免、对抗疾病的抵抗\n"
        msg3 += f"   关键豁免: 毒性和需集中注意的效应\n\n"
        msg3 += f"📚 智力 (INT)\n"
        msg3 += f"   影响: 法术伤害（特定职业）、技能检定\n"
        msg3 += f"   关键技能: 奥秘、历史、调查、自然、宗教\n\n"
        msg3 += f"👁 感知 (WIS)\n"
        msg3 += f"   影响: 感知检定、法术辅助（特定职业）\n"
        msg3 += f"   关键技能: 驯兽、洞察、医药、察觉、求生\n\n"
        msg3 += f"✨ 魅力 (CHA)\n"
        msg3 += f"   影响: 社交检定、法术引导（特定职业）\n"
        msg3 += f"   关键技能: 欺瞒、威吓、表演、说服\n"
        messages.append(msg3)

        return messages

    def _get_skills_prompt(self, state: CharacterCreationState) -> str:
        """技能选择提示"""
        cls_data = ClassDatabase.get_class(state.selected_class)
        max_skills = cls_data.skill_choices if cls_data else 2
        available = cls_data.available_skills if cls_data else []

        prompt = f"🎯 步骤6: 选择技能熟练\n\n"
        prompt += f"可选技能数量: {max_skills} 项\n"
        prompt += f"━━━━━━━━━━━━━━━━━━━━\n\n"

        prompt += f"已选技能: {', '.join(state.skill_proficiencies) if state.skill_proficiencies else '无'} ({len(state.skill_proficiencies)}/{max_skills})\n\n"

        prompt += "可选技能列表:\n"

        skill_groups = {
            "💪 力量系": ["运动"],
            "🏃 敏捷系": ["杂技", "巧手", "隐匿"],
            "📚 智力系": ["奥秘", "历史", "调查", "自然", "宗教"],
            "👁 感知系": ["驯兽", "洞察", "医药", "察觉", "求生"],
            "✨ 魅力系": ["欺瞒", "威吓", "表演", "说服"]
        }

        for group_name, skills in skill_groups.items():
            available_in_group = [s for s in skills if s in available]
            if available_in_group:
                prompt += f"{group_name}: {', '.join(available_in_group)}\n"

        prompt += "\n━━━━━━━━━━━━━━━━━━━━\n"
        prompt += "💡 【指令格式说明】\n"
        prompt += "• 单选: /dnd 建卡 运动\n"
        prompt += "• 多选（分隔符支持空格/逗号/顿号）:\n"
        prompt += "   /dnd 建卡 运动 隐匿\n"
        prompt += "   /dnd 建卡 运动,隐匿\n"
        prompt += "• 选满后自动进入下一步"

        return prompt

    def _get_background_prompt(self) -> str:
        """背景选择提示"""
        prompt = "📜 步骤7: 选择背景\n\n"
        prompt += "请选择你的背景：\n"
        prompt += "━━━━━━━━━━━━━━━━━━━━\n"

        backgrounds = BackgroundDatabase.get_all_backgrounds()
        for i, bg_name in enumerate(backgrounds, 1):
            bg = BackgroundDatabase.get_background(bg_name)
            skills_str = ", ".join(bg.skill_proficiencies[:2])
            prompt += f"{i}. {bg_name:4} - 技能: {skills_str}\n"

        prompt += "\n━━━━━━━━━━━━━━━━━━━━\n"
        prompt += "💡 回复格式: /dnd 建卡 <数字>  或  /dnd 建卡 <背景名>"
        return prompt

    def get_background_details(self, bg_name: Optional[str] = None) -> list:
        """获取背景详情"""
        backgrounds = BackgroundDatabase.get_all_backgrounds()
        messages = []

        if bg_name:
            bg = BackgroundDatabase.get_background(bg_name)
            if not bg:
                return [f"❌ 未找到背景: {bg_name}"]

            msg = f"📜 {bg.name_cn}\n"
            msg += f"━━━━━━━━━━━━━━━━━━━━\n"
            msg += f"📖 {bg.description}\n\n"
            msg += f"🎯 技能熟练: {', '.join(bg.skill_proficiencies)}\n"
            if bg.languages > 0:
                msg += f"🌐 额外语言: {bg.languages}门\n"
            if bg.tool_proficiencies:
                msg += f"🔧 工具熟练: {', '.join(bg.tool_proficiencies)}\n"
            if bg.equipment:
                msg += f"🎒 起始装备: {', '.join(bg.equipment)}\n"
            if bg.feature:
                msg += f"\n⭐ 背景特性: {bg.feature}\n"
                desc = BACKGROUND_FEATURE_DESCRIPTIONS.get(bg.feature, bg.feature_description)
                msg += f"   {desc}\n"
            messages.append(msg)
        else:
            for bg_name in backgrounds:
                bg = BackgroundDatabase.get_background(bg_name)
                msg = f"📜 {bg.name_cn}\n"
                msg += f"━━━━━━━━━━━━━━━━━━━━\n"
                msg += f"📖 {bg.description}\n\n"
                msg += f"🎯 技能熟练: {', '.join(bg.skill_proficiencies)}\n"
                if bg.languages > 0:
                    msg += f"🌐 额外语言: {bg.languages}门\n"
                if bg.tool_proficiencies:
                    msg += f"🔧 工具熟练: {', '.join(bg.tool_proficiencies)}\n"
                if bg.equipment:
                    msg += f"🎒 起始装备: {', '.join(bg.equipment)}\n"
                if bg.feature:
                    msg += f"\n⭐ 特性: {bg.feature}\n"
                    desc = BACKGROUND_FEATURE_DESCRIPTIONS.get(bg.feature, "")
                    if desc:
                        msg += f"   {desc}\n"
                messages.append(msg)

        return messages

    def _get_confirm_prompt(self, state: CharacterCreationState) -> str:
        """确认提示"""
        race_str = state.selected_race
        if state.selected_subrace:
            race_str += f"({state.selected_subrace})"

        # 应用种族加成获取最终属性
        temp_ability_obj = AbilityScores(
            strength=state.abilities.strength,
            dexterity=state.abilities.dexterity,
            constitution=state.abilities.constitution,
            intelligence=state.abilities.intelligence,
            wisdom=state.abilities.wisdom,
            charisma=state.abilities.charisma
        )
        final_abilities = apply_race_bonuses(temp_ability_obj, state.selected_race, state.selected_subrace)
        
        char_name = state.character_name if state.character_name else state.user_name

        gender_display = ""
        if state.selected_gender:
            gender_display = f" ({state.selected_gender})"

        prompt = "📋 角色预览\n\n"
        prompt += "━━━━━━━━━━━━━━━━━━━━\n"
        prompt += f"🎭 {char_name}{gender_display}\n"
        prompt += f"{race_str} {state.selected_class} | 等级 1\n"
        prompt += "━━━━━━━━━━━━━━━━━━━━\n\n"

        prompt += "📊 属性（应用种族加成后）:\n"
        ability_keys = ["力量", "敏捷", "体质", "智力", "感知", "魅力"]
        ability_attrs = ["strength", "dexterity", "constitution", "intelligence", "wisdom", "charisma"]
        emojis = ["💪", "🏃", "💚", "📚", "👁", "✨"]

        for attr, attr_en, emoji in zip(ability_keys, ability_attrs, emojis):
            value = getattr(final_abilities, attr_en)
            mod = (value - 10) // 2
            mod_str = f"+{mod}" if mod >= 0 else str(mod)
            prompt += f"{emoji} {attr}: {value} (调整值 {mod_str})\n"

        prompt += f"\n🎯 熟练技能: {', '.join(state.skill_proficiencies)}\n"
        prompt += f"📜 背景: {state.selected_background}\n"
        prompt += "━━━━━━━━━━━━━━━━━━━━\n\n"
        prompt += "💡 回复格式: /dnd 建卡 <确认/取消>\n"
        prompt += "• 确认创建: /dnd 建卡 确认\n"
        prompt += "• 取消创建: /dnd 建卡 取消"

        return prompt

    def get_state_summary(self, user_id: str) -> Optional[str]:
        """获取建卡状态摘要"""
        state = self.get_state(user_id)
        if not state:
            return None

        step_names = {
            CreationStep.RACE: "选择种族",
            CreationStep.SUBRACE: "选择亚种",
            CreationStep.CLASS: "选择职业",
            CreationStep.ABILITY: "分配属性",
            CreationStep.SKILLS: "选择技能",
            CreationStep.BACKGROUND: "选择背景",
            CreationStep.CONFIRM: "确认创建",
            CreationStep.COMPLETE: "已完成"
        }

        summary = f"📋 建卡进度 - {state.user_name}\n"
        summary += f"━━━━━━━━━━━━━━━━━━━━\n"
        summary += f"当前步骤: {step_names.get(state.step, '未知')}\n\n"

        if state.selected_race:
            race_str = state.selected_race
            if state.selected_subrace:
                race_str += f"({state.selected_subrace})"
            summary += f"🌍 种族: {race_str}\n"

        if state.selected_class:
            summary += f"⚔️ 职业: {state.selected_class}\n"

        if state.abilities:
            summary += f"📊 属性: 力量{state.abilities.strength} 敏捷{state.abilities.dexterity} 体质{state.abilities.constitution}\n"
            summary += f"         智力{state.abilities.intelligence} 感知{state.abilities.wisdom} 魅力{state.abilities.charisma}\n"

        if state.skill_proficiencies:
            summary += f"🎯 技能: {', '.join(state.skill_proficiencies)}\n"

        if state.selected_background:
            summary += f"📜 背景: {state.selected_background}\n"

        return summary
