"""
DND/Zero TRPG 插件主文件
基于 D&D 5e 规则的轻量化群组跑团插件

数据来源: 5etools中文站 (https://5e.kiwee.top/)
遵循 Creative Commons 许可证
"""
import random
from pathlib import Path
from typing import Dict

from astrbot.api.event import filter, AstrMessageEvent
from astrbot.api.star import Context, Star
from astrbot.api import logger, AstrBotConfig
from astrbot.api.event import filter as event_filter

import astrbot.api.message_components as Comp

from .util import DataManager, check_permission, get_group_data_path
from .data.loader import DataLoader
from .core import (
    DiceRoller, Character, AbilityScores, CharacterFactory,
    SkillChecker, CombatSystem, SpellDatabase,
    ClassDatabase, RaceDatabase, BackgroundDatabase,
    CharacterCreator, CreationStep,
    TownSystem, MenuSystem, NPCDatabase,
    DailySystem, BackpackSystem, ShopSystem, PartySystem,
    BattleArena, Difficulty, WATERDEEP_ARENA_MONSTERS, ARENA_INSTANCE
)
from .core.full_combat_system import (
    CombatContext, CombatFighter, CombatPhase,
    COMBAT_MANAGER
)
from astrbot.core.utils.astrbot_path import get_astrbot_data_path


class DNDZeroPlugin(Star):
    """DND/Zero TRPG 插件主类"""

    def __init__(self, context: Context, config: AstrBotConfig):
        super().__init__(context)
        self.context = context
        self.config = config
        plugin_data_path = Path(get_astrbot_data_path()) / "plugin_data" / "astrbot_plugin_dnd_zero"
        plugin_data_path.mkdir(parents=True, exist_ok=True)
        self.plugin_data_dir = plugin_data_path
        self.backup_dir = self.plugin_data_dir / "backup"
        self.backup_dir.mkdir(parents=True, exist_ok=True)
        self.data_manager = DataManager(self.plugin_data_dir)
        self.data_loader = DataLoader(self.plugin_data_dir)
        self.skill_checker = SkillChecker()
        self.combat_system = CombatSystem()
        self.character_creator = CharacterCreator()
        self.characters: Dict[str, Character] = {}
        
        self.battle_arena = ARENA_INSTANCE
        self.arena_char_states: Dict[str, Dict] = {}
        self.combat_manager = COMBAT_MANAGER
        self.admin_modes: Dict[str, Dict] = {}

        self.town_system = TownSystem()
        self.npc_database = NPCDatabase()
        self.menu_system = MenuSystem(self.town_system, self.npc_database)
        self.daily_system = DailySystem()
        self.backpack_system = BackpackSystem()
        self.shop_system = ShopSystem()
        self.party_system = PartySystem()
        
        self.ABILITY_CN_TO_EN = {
            "力量": "strength", "敏捷": "dexterity", "体质": "constitution",
            "智力": "intelligence", "感知": "wisdom", "魅力": "charisma"
        }
        self.ABILITY_EN_TO_CN = {v: k for k, v in self.ABILITY_CN_TO_EN.items()}
        self.ABILITY_EMOJI = {
            "strength": "💪", "dexterity": "🏃", "constitution": "❤️",
            "intelligence": "📚", "wisdom": "👁", "charisma": "✨"
        }
        
        self.CLASS_PRESETS = {
            "战士": {"strength": 15, "constitution": 14, "dexterity": 13, 
                    "intelligence": 10, "wisdom": 10, "charisma": 8},
            "法师": {"intelligence": 15, "dexterity": 14, "constitution": 13, 
                    "charisma": 10, "wisdom": 10, "strength": 8},
            "盗贼": {"dexterity": 15, "intelligence": 14, "charisma": 13, 
                    "constitution": 10, "wisdom": 10, "strength": 8},
            "牧师": {"wisdom": 15, "charisma": 14, "constitution": 13, 
                    "intelligence": 10, "dexterity": 10, "strength": 8},
            "游侠": {"dexterity": 15, "wisdom": 14, "constitution": 13, 
                    "intelligence": 10, "charisma": 10, "strength": 8},
            "圣武士": {"strength": 15, "charisma": 14, "constitution": 13, 
                    "wisdom": 10, "intelligence": 10, "dexterity": 8},
            "吟游诗人": {"charisma": 15, "dexterity": 14, "constitution": 13, 
                    "wisdom": 10, "intelligence": 10, "strength": 8},
            "野蛮人": {"strength": 15, "constitution": 14, "dexterity": 13, 
                    "wisdom": 10, "charisma": 10, "intelligence": 8},
            "僧侣": {"dexterity": 15, "strength": 14, "constitution": 13, 
                    "wisdom": 10, "intelligence": 10, "charisma": 8},
            "德鲁伊": {"wisdom": 15, "intelligence": 14, "constitution": 13, 
                    "dexterity": 10, "charisma": 10, "strength": 8},
            "术士": {"charisma": 15, "constitution": 14, "dexterity": 13, 
                    "wisdom": 10, "intelligence": 10, "strength": 8},
            "奇械师": {"intelligence": 15, "constitution": 14, "dexterity": 13, 
                    "wisdom": 10, "charisma": 10, "strength": 8}
        }
        
        self.CLASS_ATTACK_TYPES = {
            "战士": {"damage_dice": "1d8", "range": "melee", "primary": "strength"},
            "法师": {"damage_dice": "1d10", "range": "ranged", "primary": "intelligence"},
            "盗贼": {"damage_dice": "1d8", "range": "melee", "primary": "dexterity"},
            "牧师": {"damage_dice": "1d8", "range": "melee", "primary": "wisdom"},
            "游侠": {"damage_dice": "1d8", "range": "ranged", "primary": "dexterity"},
            "圣武士": {"damage_dice": "1d8", "range": "melee", "primary": "strength"},
            "吟游诗人": {"damage_dice": "1d8", "range": "ranged", "primary": "charisma"},
            "野蛮人": {"damage_dice": "1d12", "range": "melee", "primary": "strength"},
            "僧侣": {"damage_dice": "1d8", "range": "melee", "primary": "dexterity"},
            "德鲁伊": {"damage_dice": "1d8", "range": "melee", "primary": "wisdom"},
            "术士": {"damage_dice": "1d6", "range": "ranged", "primary": "charisma"},
            "奇械师": {"damage_dice": "1d8", "range": "ranged", "primary": "intelligence"}
        }
        
        logger.info("DND/Zero 插件初始化完成")

    async def initialize(self):
        """插件初始化钩子"""
        logger.info("DND/Zero 插件开始初始化...")
        await self._load_plugin_data()
        await self._preload_data()
        logger.info("DND/Zero 插件数据加载完成")

    async def _preload_data(self):
        """预加载常用数据"""
        try:
            await self.data_loader.get_classes()
            await self.data_loader.get_races()
            logger.info("D&D 数据预加载完成")
        except Exception as e:
            logger.warning(f"数据预加载失败: {e}")

    async def _load_plugin_data(self):
        """加载插件数据"""
        characters_data = self.data_manager.load_json("characters.json")
        if characters_data:
            for user_id, char_data in characters_data.items():
                try:
                    abilities = self._parse_abilities(char_data.get('abilities', {}))
                    char = Character(
                        name=char_data.get('name', '未命名'),
                        player_id=user_id,
                        level=char_data.get('level', 1),
                        experience=char_data.get('experience', 0),
                        abilities=abilities,
                        class_name=char_data.get('class_name', ''),
                        subclass=char_data.get('subclass', ''),
                        race=char_data.get('race', ''),
                        subrace=char_data.get('subrace', ''),
                        gender=char_data.get('gender', ''),
                        background=char_data.get('background', ''),
                        hit_points=char_data.get('hit_points', 10),
                        max_hit_points=char_data.get('max_hit_points', 10),
                        armor_class=char_data.get('armor_class', 10),
                        skill_proficiencies=char_data.get('skill_proficiencies', [])
                    )
                    self.characters[user_id] = char
                except Exception as e:
                    logger.error(f"加载角色数据失败 {user_id}: {e}")

    def _save_plugin_data(self):
        """保存插件数据"""
        characters_data = {}
        for user_id, char in self.characters.items():
            characters_data[user_id] = {
                'name': char.name,
                'level': char.level,
                'experience': char.experience,
                'abilities': {
                    'strength': char.abilities.strength,
                    'dexterity': char.abilities.dexterity,
                    'constitution': char.abilities.constitution,
                    'intelligence': char.abilities.intelligence,
                    'wisdom': char.abilities.wisdom,
                    'charisma': char.abilities.charisma
                },
                'class_name': char.class_name,
                'subclass': char.subclass,
                'race': char.race,
                'subrace': getattr(char, 'subrace', ''),
                'gender': getattr(char, 'gender', ''),
                'background': getattr(char, 'background', ''),
                'hit_points': char.hit_points,
                'max_hit_points': char.max_hit_points,
                'armor_class': char.armor_class,
                'skill_proficiencies': getattr(char, 'skill_proficiencies', [])
            }
        self.data_manager.save_json("characters.json", characters_data)

    def _parse_abilities(self, abilities_dict: dict) -> AbilityScores:
        """解析属性字典"""
        key_mapping = {
            "力量": "strength", "str": "strength",
            "敏捷": "dexterity", "dex": "dexterity",
            "体质": "constitution", "con": "constitution",
            "智力": "intelligence", "int": "intelligence",
            "感知": "wisdom", "wis": "wisdom",
            "魅力": "charisma", "cha": "charisma"
        }
        
        values = {
            "strength": 10, "dexterity": 10, "constitution": 10,
            "intelligence": 10, "wisdom": 10, "charisma": 10
        }
        
        for key, value in abilities_dict.items():
            normalized_key = key_mapping.get(key.lower() if isinstance(key, str) else key, key)
            if normalized_key in values:
                values[normalized_key] = value
        
        return AbilityScores(**values)
        
    def _apply_ability_bonus(self, abilities: AbilityScores, bonus_dict: dict) -> AbilityScores:
        """应用属性加值"""
        key_mapping = {
            "力量": "strength", "str": "strength",
            "敏捷": "dexterity", "dex": "dexterity",
            "体质": "constitution", "con": "constitution",
            "智力": "intelligence", "int": "intelligence",
            "感知": "wisdom", "wis": "wisdom",
            "魅力": "charisma", "cha": "charisma"
        }
        
        bonus_values = {
            "strength": 0, "dexterity": 0, "constitution": 0,
            "intelligence": 0, "wisdom": 0, "charisma": 0
        }
        
        for key, value in bonus_dict.items():
            normalized_key = key_mapping.get(key.lower() if isinstance(key, str) else key, key)
            if normalized_key in bonus_values:
                bonus_values[normalized_key] += value
        
        return AbilityScores(
            strength=abilities.strength + bonus_values["strength"],
            dexterity=abilities.dexterity + bonus_values["dexterity"],
            constitution=abilities.constitution + bonus_values["constitution"],
            intelligence=abilities.intelligence + bonus_values["intelligence"],
            wisdom=abilities.wisdom + bonus_values["wisdom"],
            charisma=abilities.charisma + bonus_values["charisma"]
        )

    def _check_group_permission(self, event: AstrMessageEvent) -> bool:
        """检查群组权限"""
        group_id = event.get_group_id()
        if not group_id:
            return False
        whitelist_mode = self.config.get("whitelist_mode", False)
        if whitelist_mode:
            whitelist_groups = self.config.get("whitelist_groups", [])
            if str(group_id) not in [str(g) for g in whitelist_groups]:
                return False
        return True

    def _check_superadmin(self, event: AstrMessageEvent) -> bool:
        """检查超级管理员权限"""
        user_id = event.get_sender_id()
        superadmins = self.config.get("superadmins", [])
        return check_permission(user_id, superadmins)

    def _get_player_data(self, event: AstrMessageEvent) -> Dict:
        """获取玩家数据"""
        user_id = str(event.get_sender_id())
        character = self.characters.get(user_id)
        if character:
            return {
                "gold": character.gold,
                "daily_sign": character.daily_sign,
                "party_id": character.party_id,
                "inventory": character.inventory
            }
        else:
            return {
                "gold": 100,
                "daily_sign": {},
                "party_id": None,
                "inventory": []
            }

    def _get_combat_context(self, group_id: str) -> CombatContext:
        """获取或创建战斗上下文"""
        ctx = self.combat_manager.get_combat(group_id)
        if not ctx:
            ctx = self.combat_manager.create_combat(group_id)
        return ctx

    @staticmethod
    def _format_mod(modifier: int) -> str:
        """格式化调整值"""
        return f"+{modifier}" if modifier >= 0 else str(modifier)

    def _get_ability_name_cn(self, ability_key: str) -> str:
        """获取属性中文名"""
        return self.ABILITY_EN_TO_CN.get(ability_key, ability_key)

    @filter.command_group("dnd")
    def dnd(self):
        """DND 指令组"""
        pass

    @dnd.command("帮助")
    @filter.event_message_type(event_filter.EventMessageType.GROUP_MESSAGE)
    async def dnd_help(self, event: AstrMessageEvent):
        """显示帮助菜单"""
        if not self._check_group_permission(event):
            yield event.plain_result("⚠️ 此群组未被授权使用 DND 插件")
            event.stop_event()
            return

        help_text = """
✨ DND/Zero 群组跑团插件 v0.4.0 ✨

━━━ 📜 基础指令 ━━━
帮助 / menu              显示本菜单
掷骰 / roll <骰子>      掷骰（如 d20, 2d6+3）
先攻 / init              先攻掷骰

━━━ 👤 角色系统 ━━━
建卡 / charcreate         交互式建卡
创建 / create [职业] [种族] 快速建卡
状态 / status           查看角色状态
属性 / abilities        查看属性面板

━━━ 🎯 检定系统 ━━━
技能 / skill <技能>      技能检定
豁免 / save <属性>      豁免检定

━━━ ⚔️ 战斗训练场 ━━━
战斗场                  战斗训练场菜单
战斗场 进入 <难度>      进入训练场（简单/中等/困难）
战斗场 怪物 <难度>      查看怪物列表
战斗场 开始 <数量>      开始战斗
战斗场 状态             查看战斗状态
战斗场 退出             退出训练场
怪物 / monster          查看怪物图鉴

━━━ 🏰 城镇系统 ━━━
城镇 / home              进入深水城南区
区域 / area              查看区域地图
NPC / npc <名称>         与NPC对话
背包 / backpack          查看背包
商店 / shop              进入商店
每日签到 / daily         每日签到

━━━ 📖 其他 ━━━
法术列表 / spells       查看法术列表
法术 / spell <名称>     查询法术
名言 / quote             随机名言

━━━ 🔧 管理员 ━━━
调试 / dndadmin          管理员调试命令

💡 使用 /dnd 战斗场 开始测试！
        """.strip()

        node_list = [
            Comp.Node(
                uin=str(event.get_self_id()),
                name="✨ DND/Zero 帮助",
                content=[Comp.Plain(help_text)]
            )
        ]
        yield event.chain_result([Comp.Nodes(node_list)])

    @dnd.command("menu")
    @filter.event_message_type(event_filter.EventMessageType.GROUP_MESSAGE)
    async def dnd_menu(self, event: AstrMessageEvent):
        """显示帮助菜单"""
        async for result in self.dnd_help(event):
            yield result

    @dnd.command("城镇", alias={"主页", "home"})
    @filter.event_message_type(event_filter.EventMessageType.GROUP_MESSAGE)
    async def dnd_town(self, event: AstrMessageEvent):
        """显示城镇主界面"""
        if not self._check_group_permission(event):
            yield event.plain_result("⚠️ 此群组未被授权使用 DND 插件")
            event.stop_event()
            return

        player_data = self._get_player_data(event)
        menu_text = self.menu_system.get_main_menu(player_data)

        node_list = [
            Comp.Node(
                uin=str(event.get_self_id()),
                name="🌆 深水城 · 南区",
                content=[Comp.Plain(menu_text)]
            )
        ]
        yield event.chain_result([Comp.Nodes(node_list)])

    @dnd.command("roll", alias={"掷骰"})
    @filter.event_message_type(event_filter.EventMessageType.GROUP_MESSAGE)
    async def dnd_roll(self, event: AstrMessageEvent, dice: str = "d20"):
        """掷骰"""
        if not self._check_group_permission(event):
            yield event.plain_result("⚠️ 此群组未被授权使用 DND 插件")
            event.stop_event()
            return

        try:
            result = DiceRoller.roll_from_notation(dice)
            result_text = f"🎲 {event.get_sender_name()} 掷出 {dice}\n━━━━━━━━━━━━━━━━━━━━\n结果: {result.total}\n详情: {str(result)}"
            if result.dice_type == 20 and result.dice_count == 1:
                if 20 in result.rolls:
                    result_text += "\n✨ 大成功！"
                elif 1 in result.rolls:
                    result_text += "\n💀 大失败！"
            yield event.plain_result(result_text)
        except ValueError:
            yield event.plain_result("❌ 无效的骰子格式！\n请使用格式如: d20, 2d6, 1d8+3")

    @dnd.command("create", alias={"创建"})
    @filter.event_message_type(event_filter.EventMessageType.GROUP_MESSAGE)
    async def dnd_create(self, event: AstrMessageEvent, *, args: str = ""):
        """创建角色"""
        if not self._check_group_permission(event):
            yield event.plain_result("⚠️ 此群组未被授权使用 DND 插件")
            event.stop_event()
            return

        user_id = str(event.get_sender_id())
        if user_id in self.characters:
            yield event.plain_result(f"⚠️ 你已经创建过角色了！\n使用 /dnd 状态 查看角色信息。")
            return

        args = args.strip() if args else ""
        if args:
            parts = args.split()
            if len(parts) < 2:
                yield event.plain_result("❌ 快速创建格式错误！\n正确格式: /dnd 创建 [职业] [种族] [背景(可选)]")
                return

            class_name = parts[0]
            race_name = parts[1]

            cls_data = ClassDatabase.get_class(class_name)
            if not cls_data:
                yield event.plain_result(f"❌ 未找到职业: {class_name}")
                return

            race_data = RaceDatabase.get_race(race_name)
            if not race_data:
                yield event.plain_result(f"❌ 未找到种族: {race_name}")
                return

            preset = self.CLASS_PRESETS.get(class_name, self.CLASS_PRESETS["战士"])
            abilities = AbilityScores(**preset)
            final_abilities = self._apply_ability_bonus(abilities, race_data.ability_bonus)

            con_mod = final_abilities.get_modifier("constitution")
            max_hp = cls_data.hit_die + con_mod

            char = Character(
                name=event.get_sender_name(),
                player_id=user_id,
                level=1,
                abilities=final_abilities,
                class_name=class_name,
                race=race_name,
                background="学者",
                hit_points=max_hp,
                max_hit_points=max_hp,
                armor_class=10 + final_abilities.get_modifier("dexterity"),
                skill_proficiencies=cls_data.available_skills[:cls_data.skill_choices]
            )

            self.characters[user_id] = char
            self._save_plugin_data()
            yield event.plain_result(f"✅ 快速角色创建成功！\n\n{char.to_summary()}")
        else:
            state = self.character_creator.start_creation(user_id, event.get_sender_name())
            yield event.plain_result("🎮 欢迎来到角色创建向导！\n\n我将帮助你创建一个完整的D&D角色。\n\n" + self.character_creator.get_current_prompt(user_id))

    @dnd.command("status", alias={"状态"})
    @filter.event_message_type(event_filter.EventMessageType.GROUP_MESSAGE)
    async def dnd_status(self, event: AstrMessageEvent):
        """查看角色状态"""
        if not self._check_group_permission(event):
            yield event.plain_result("⚠️ 此群组未被授权使用 DND 插件")
            event.stop_event()
            return

        user_id = str(event.get_sender_id())
        if user_id not in self.characters:
            yield event.plain_result(f"⚠️ 你还没有创建角色！\n使用 /dnd 创建 创建角色。")
            return

        char = self.characters[user_id]
        yield event.plain_result(char.to_summary())

    @dnd.command("技能")
    @filter.event_message_type(event_filter.EventMessageType.GROUP_MESSAGE)
    async def dnd_skill(self, event: AstrMessageEvent, *, skill: str = ""):
        """技能检定"""
        if not self._check_group_permission(event):
            yield event.plain_result("⚠️ 此群组未被授权使用 DND 插件")
            event.stop_event()
            return

        user_id = str(event.get_sender_id())
        group_id = str(event.get_group_id())
        
        ctx = self.combat_manager.get_combat(group_id)
        in_combat = ctx and ctx.phase != CombatPhase.WAITING
        fighter = ctx.get_fighter_by_sender(user_id) if ctx else None
        
        if in_combat and fighter:
            action_text = "⚔️ **战斗动作**\n━━━━━━━━━━━━━━━━━━━━\n"
            action_text += f"**角色**: {fighter.name}\n"
            action_text += f"**HP**: {fighter.current_hp}/{fighter.max_hp}\n"
            action_text += f"**AC**: {fighter.armor_class}\n"
            action_text += f"**攻击加值**: +{fighter.attack_bonus}\n"
            action_text += f"**伤害骰**: {fighter.damage_dice}\n\n"
            
            action_text += "📋 **可用动作**\n"
            if fighter.action_used:
                action_text += "  ❌ **攻击** - 本回合已使用\n"
            else:
                action_text += "  ⚔️ **攻击** - 普通攻击\n"
            
            action_text += "  🛡️ **防御** - 防御姿态 (AC+2)\n"
            action_text += "  💨 **躲避** - 闪避姿态\n\n"
            
            action_text += "📌 **技能检定说明**\n"
            action_text += "━━━━━━━━━━━━━━━━━━━━\n"
            action_text += "战斗模式下，/dnd 技能 用于查看战斗动作\n"
            action_text += "如需进行技能检定，请在战斗外使用\n\n"
            action_text += "💡 **使用方法**:\n"
            action_text += "`/dnd 攻击` - 查看可攻击目标\n"
            action_text += "`/dnd 攻击 1` - 攻击1号位敌人\n"
            action_text += "`/dnd 防御` - 进入防御姿态\n"
            action_text += "`/dnd 战斗场 状态` - 查看战场\n"
            
            node_list = [
                Comp.Node(
                    uin=str(event.get_self_id()),
                    name="⚔️ 战斗动作菜单",
                    content=[Comp.Plain(action_text)]
                )
            ]
            yield event.chain_result([Comp.Nodes(node_list)])
            return
        
        if not skill:
            yield event.plain_result("🎯 技能列表 (18项技能)\n━━━━━━━━━━━━━━━━━━━━\n💪 力量系: 运动\n🏃 敏捷系: 杂技、巧手、隐匿\n📚 智力系: 奥秘、历史、调查、自然、宗教\n👁 感知系: 驯兽、洞察、医药、察觉、求生\n✨ 魅力系: 欺瞒、威吓、表演、说服\n\n💡 使用 /dnd 技能 <名称> 进行检定")
            return

        if user_id in self.characters:
            char = self.characters[user_id]
            result = self.skill_checker.roll_skill_check(char, skill, dc=10)
        else:
            char = Character(name="无名冒险者", player_id="test", abilities=AbilityScores())
            result = self.skill_checker.roll_skill_check(char, skill, dc=10)

        result_text = f"🎯 技能检定 - {result.skill_name}\n━━━━━━━━━━━━━━━━━━━━\n检定者: {char.name}\n🎲 D20: {result.roll}"
        if result.proficiency_bonus > 0:
            result_text += f"\n⚔️ 熟练加值: +{result.proficiency_bonus}"
        result_text += f"\n📈 总计: {result.total} vs DC 10\n"
        result_text += "✨ 检定成功！" if result.success else "❌ 检定失败！"
        yield event.plain_result(result_text)

    @dnd.command("战斗场")
    @filter.event_message_type(event_filter.EventMessageType.GROUP_MESSAGE)
    async def dnd_arena(self, event: AstrMessageEvent, action: str = "", param: str = ""):
        """战斗训练场"""
        if not self._check_group_permission(event):
            yield event.plain_result("⚠️ 此群组未被授权使用 DND 插件")
            event.stop_event()
            return

        user_id = str(event.get_sender_id())
        sender_name = event.get_sender_name()
        group_id = str(event.get_group_id())

        if action == "":
            arena_text = self.battle_arena.format_arena_menu()
            node_list = [
                Comp.Node(
                    uin=str(event.get_self_id()),
                    name="⚔️ 战斗训练场",
                    content=[Comp.Plain(arena_text)]
                )
            ]
            yield event.chain_result([Comp.Nodes(node_list)])
            
        elif action == "进入":
            difficulty_map = {"简单": Difficulty.EASY, "中等": Difficulty.MEDIUM, "困难": Difficulty.HARD}
            diff = difficulty_map.get(param, Difficulty.MEDIUM)
            diff_name = {"简单": "简单", "中等": "中等", "困难": "困难"}.get(param, "中等")
            
            if user_id not in self.characters:
                yield event.plain_result("❌ 你还没有创建角色！\n使用 /dnd 创建 <职业> <种族> 快速建卡")
                return
            
            char = self.characters[user_id]
            
            self.arena_char_states[user_id] = {
                'hp': char.hit_points,
                'max_hp': char.max_hit_points
            }
            
            ctx = self._get_combat_context(group_id)
            ctx.selected_difficulty = diff
            
            attack_type = self.CLASS_ATTACK_TYPES.get(char.class_name, self.CLASS_ATTACK_TYPES["战士"])
            primary_ability = attack_type["primary"]
            primary_mod = char.abilities.get_modifier(primary_ability)
            
            fighter = CombatFighter(
                fighter_id=user_id,
                name=char.name,
                sender_id=user_id,
                sender_name=sender_name,
                max_hp=char.max_hit_points,
                current_hp=char.max_hit_points,
                armor_class=char.armor_class,
                attack_bonus=char.proficiency_bonus + primary_mod,
                damage_dice=attack_type["damage_dice"],
                damage_bonus=primary_mod,
                abilities={
                    "strength": char.abilities.strength,
                    "dexterity": char.abilities.dexterity,
                    "constitution": char.abilities.constitution,
                    "intelligence": char.abilities.intelligence,
                    "wisdom": char.abilities.wisdom,
                    "charisma": char.abilities.charisma
                },
                spell_slots=char.spell_slots if hasattr(char, 'spell_slots') else {},
                prepared_spells=char.prepared_spells if hasattr(char, 'prepared_spells') else []
            )
            
            ctx.add_ally(fighter)
            
            result_text = f"✅ 你进入了战斗训练场！\n难度: {diff_name}\n职业: {char.class_name}\n攻击类型: {attack_type['damage_dice']} ({primary_ability})\n\n💡 使用命令:\n/dnd 战斗场 怪物 - 查看怪物列表\n/dnd 战斗场 开始 <数量> - 开始战斗"
            yield event.plain_result(result_text)
            
        elif action == "怪物":
            difficulty_map = {"简单": Difficulty.EASY, "中等": Difficulty.MEDIUM, "困难": Difficulty.HARD}
            diff = difficulty_map.get(param, Difficulty.MEDIUM)
            monster_text = self.battle_arena.format_monster_selection(diff)
            node_list = [
                Comp.Node(
                    uin=str(event.get_self_id()),
                    name="👹 怪物列表",
                    content=[Comp.Plain(monster_text)]
                )
            ]
            yield event.chain_result([Comp.Nodes(node_list)])
            
        elif action == "开始":
            try:
                count = int(param) if param else 1
            except ValueError:
                count = 1
            
            ctx = self._get_combat_context(group_id)
            
            if user_id not in ctx.allies:
                yield event.plain_result("❌ 你还没有进入战斗训练场！\n使用 /dnd 战斗场 进入")
                return
            
            diff = ctx.selected_difficulty if ctx.selected_difficulty else Difficulty.MEDIUM
            monsters = self.battle_arena.generate_encounter(diff, count)
            
            for i, monster in enumerate(monsters):
                enemy = CombatFighter(
                    fighter_id=f"enemy_{i}_{monster.name}",
                    name=monster.name,
                    sender_id="enemy",
                    sender_name=monster.name,
                    position=i + 1,
                    original_position=i + 1,
                    max_hp=monster.current_hp,
                    current_hp=monster.current_hp,
                    armor_class=monster.armor_class,
                    attack_bonus=monster.attack_bonus,
                    damage_dice=monster.default_damage,
                    damage_bonus=0,
                    is_enemy=True
                )
                ctx.add_enemy(enemy)
            
            ctx.roll_initiative()
            
            start_text = ctx.get_combat_start_display()
            start_text += "\n📋 **可用指令**\n"
            start_text += "━━━━━━━━━━━━━━━━━━━━\n"
            start_text += "`/dnd 攻击` 或 `/dnd 攻击 <目标>` - 普通攻击\n"
            start_text += "`/dnd 防御` - 防御姿态 (AC+2)\n"
            start_text += "`/dnd 躲避` - 闪避姿态\n"
            start_text += "`/dnd 跳过` - 跳过本回合\n"
            start_text += "`/dnd 战斗场 状态` - 查看战场\n\n"
            start_text += "⚠️ 注意: 每个回合只能进行一次攻击\n"
            start_text += "💡 攻击目标用数字表示 (1, 2, 3...)\n\n"
            start_text += "━━━━━━━━━━━━━━━━━━━━\n"
            start_text += "🎮 **请等待你的回合，使用 `/dnd 攻击 1` 攻击1号位敌人**"
            
            node_list = [
                Comp.Node(
                    uin=str(event.get_self_id()),
                    name="⚔️ 战斗开始！",
                    content=[Comp.Plain(start_text)]
                )
            ]
            yield event.chain_result([Comp.Nodes(node_list)])
            
        elif action == "状态":
            ctx = self.combat_manager.get_combat(group_id)
            if not ctx or ctx.phase == CombatPhase.WAITING:
                yield event.plain_result("⚠️ 当前没有进行中的战斗")
                return
            
            status_text = ctx.get_battlefield_display()
            node_list = [
                Comp.Node(
                    uin=str(event.get_self_id()),
                    name="⚔️ 战斗状态",
                    content=[Comp.Plain(status_text)]
                )
            ]
            yield event.chain_result([Comp.Nodes(node_list)])
            
        elif action == "退出":
            if user_id in self.arena_char_states:
                state = self.arena_char_states[user_id]
                if user_id in self.characters:
                    self.characters[user_id].hit_points = state['hp']
                    self.characters[user_id].max_hit_points = state['max_hp']
                del self.arena_char_states[user_id]
            
            self.combat_manager.end_combat(group_id)
            
            node_list = [
                Comp.Node(
                    uin=str(event.get_self_id()),
                    name="✅ 退出战斗场",
                    content=[Comp.Plain("✅ 已退出战斗训练场，角色状态已恢复。\n\n💡 使用 /dnd 状态 查看角色信息")]
                )
            ]
            yield event.chain_result([Comp.Nodes(node_list)])
            
        else:
            yield event.plain_result("❌ 无效指令！\n使用 /dnd 战斗场 查看帮助")

    @dnd.command("攻击")
    @filter.event_message_type(event_filter.EventMessageType.GROUP_MESSAGE)
    async def dnd_attack(self, event: AstrMessageEvent, *, target: str = ""):
        """战斗模式下的攻击"""
        if not self._check_group_permission(event):
            yield event.plain_result("⚠️ 此群组未被授权使用 DND 插件")
            event.stop_event()
            return

        user_id = str(event.get_sender_id())
        sender_name = event.get_sender_name()
        group_id = str(event.get_group_id())
        
        ctx = self.combat_manager.get_combat(group_id)
        if not ctx or ctx.phase == CombatPhase.WAITING:
            yield event.plain_result("⚠️ 当前没有进行中的战斗\n💡 使用 /dnd 战斗场 进入 开始战斗")
            return
        
        fighter = ctx.get_fighter_by_sender(user_id)
        if not fighter:
            yield event.plain_result("❌ 你没有参与这场战斗！\n💡 使用 /dnd 战斗场 进入 加入战斗")
            return
        
        if not target:
            targets_text = ctx.get_attack_targets_display(fighter)
            result_text = f"📋 **{fighter.name}** - 选择攻击目标\n━━━━━━━━━━━━━━━━━━━━\n"
            result_text += targets_text
            result_text += "\n━━━━━━━━━━━━━━━━━━━━\n"
            result_text += f"💡 使用 `/dnd 攻击 <目标位置>` 进行攻击\n"
            result_text += f"   例如: `/dnd 攻击 1`"
            
            node_list = [
                Comp.Node(
                    uin=str(event.get_self_id()),
                    name="🎯 选择攻击目标",
                    content=[Comp.Plain(result_text)]
                )
            ]
            yield event.chain_result([Comp.Nodes(node_list)])
            return
        
        try:
            target_pos = int(target)
        except ValueError:
            yield event.plain_result(f"❌ 无效的目标: {target}\n💡 目标应该是数字，如 /dnd 攻击 1")
            return
        
        if fighter.action_used:
            yield event.plain_result("❌ 本回合已使用动作！\n💡 使用 /dnd 跳过 跳过回合，等待下回合再行动")
            return
        
        enemies = ctx.get_alive_enemies()
        if target_pos < 1 or target_pos > len(enemies):
            yield event.plain_result(f"❌ 无效的目标位置: {target_pos}\n💡 可用目标: 1-{len(enemies)}")
            return
        
        result = ctx.execute_attack(fighter, target_pos)
        
        if not result["success"]:
            yield event.plain_result(f"❌ {result['message']}")
            return
        
        enemy = enemies[target_pos - 1]
        
        result_text = f"⚔️ **攻击**\n━━━━━━━━━━━━━━━━━━━━\n"
        result_text += f"**攻击者**: 🗡️ **{fighter.name}** (你)\n"
        result_text += f"**目标**: 🛡️ **{enemy.name}** ({target_pos}号位)\n\n"
        result_text += f"🎲 **攻击骰**: {result['attack_roll']} + {result['attack_bonus']} = **{result['attack_total']}**\n"
        result_text += f"🛡️ **目标AC**: {result['target_ac']}\n"
        result_text += "━━━━━━━━━━━━━━━━━━━━\n"
        
        if result["critical"]:
            result_text += "🎯 **暴击！** 自动命中！\n"
            result_text += f"💥 **伤害**: **{result['damage']}**\n"
        elif result["fumble"]:
            result_text += "💀 **大失败！** 攻击失误！\n"
            result_text += f"💥 **伤害**: 0\n"
        elif result["hit"]:
            result_text += "✅ **命中！**\n"
            result_text += f"💥 **伤害**: **{result['damage']}**\n"
        else:
            result_text += "❌ **未命中！**\n"
        
        result_text += f"━━━━━━━━━━━━━━━━━━━━\n"
        
        if result.get("killed"):
            result_text += f"💀 **{enemy.name}** 被击杀！\n"
        
        remaining_hp = enemy.current_hp if not result.get("killed") else 0
        hp_bar = CombatContext._generate_hp_bar(remaining_hp, enemy.max_hp, length=5)
        result_text += f"🛡️ {enemy.name} 剩余: {hp_bar} {remaining_hp}/{enemy.max_hp}\n"
        
        result_text += f"\n📊 **战斗统计**\n"
        allies = ctx.get_alive_allies()
        enemies = ctx.get_alive_enemies()
        result_text += f"我方存活: {len(allies)} | 敌方存活: {len(enemies)}\n"
        
        if ctx.phase == CombatPhase.COMBAT_END:
            ctx._log_event("combat_end", {"result": "victory" if len(enemies) == 0 else "defeat"})
            if user_id in self.arena_char_states:
                state = self.arena_char_states[user_id]
                if user_id in self.characters:
                    self.characters[user_id].hit_points = state['hp']
                del self.arena_char_states[user_id]
            self.combat_manager.end_combat(group_id)
            
            victory = len(enemies) == 0
            result_text = "🏆 **战斗结束！** 🏆\n━━━━━━━━━━━━━━━━━━━━\n"
            result_text += "✨ **胜利！** 所有敌人已被击败！" if victory else "💀 **失败！** 我方全灭..."
            result_text += "\n\n💡 使用 /dnd 战斗场 进入 重新开始"
        
        node_list = [
            Comp.Node(
                uin=str(event.get_self_id()),
                name="⚔️ 攻击结果",
                content=[Comp.Plain(result_text)]
            )
        ]
        yield event.chain_result([Comp.Nodes(node_list)])

    @dnd.command("防御")
    @filter.event_message_type(event_filter.EventMessageType.GROUP_MESSAGE)
    async def dnd_defend(self, event: AstrMessageEvent):
        """战斗模式下的防御"""
        if not self._check_group_permission(event):
            yield event.plain_result("⚠️ 此群组未被授权使用 DND 插件")
            event.stop_event()
            return

        user_id = str(event.get_sender_id())
        group_id = str(event.get_group_id())
        
        ctx = self.combat_manager.get_combat(group_id)
        if not ctx or ctx.phase == CombatPhase.WAITING:
            yield event.plain_result("⚠️ 当前没有进行中的战斗")
            return
        
        fighter = ctx.get_fighter_by_sender(user_id)
        if not fighter:
            yield event.plain_result("❌ 你没有参与这场战斗")
            return
        
        result = ctx.execute_defend(fighter)
        
        if not result["success"]:
            yield event.plain_result(f"❌ {result['message']}")
            return
        
        yield event.plain_result(f"🛡️ **{fighter.name}** 进入防御姿态！\nAC +2，直到下回合开始。")

    @dnd.command("躲避")
    @filter.event_message_type(event_filter.EventMessageType.GROUP_MESSAGE)
    async def dnd_dodge(self, event: AstrMessageEvent):
        """战斗模式下的躲避"""
        if not self._check_group_permission(event):
            yield event.plain_result("⚠️ 此群组未被授权使用 DND 插件")
            event.stop_event()
            return

        user_id = str(event.get_sender_id())
        group_id = str(event.get_group_id())
        
        ctx = self.combat_manager.get_combat(group_id)
        if not ctx or ctx.phase == CombatPhase.WAITING:
            yield event.plain_result("⚠️ 当前没有进行中的战斗")
            return
        
        fighter = ctx.get_fighter_by_sender(user_id)
        if not fighter:
            yield event.plain_result("❌ 你没有参与这场战斗")
            return
        
        result = ctx.execute_dodge(fighter)
        
        if not result["success"]:
            yield event.plain_result(f"❌ {result['message']}")
            return
        
        yield event.plain_result(f"💨 **{fighter.name}** 专注闪避！\n敏捷豁免获得优势，攻击者攻击劣势。")

    @dnd.command("跳过")
    @filter.event_message_type(event_filter.EventMessageType.GROUP_MESSAGE)
    async def dnd_skip(self, event: AstrMessageEvent):
        """跳过回合"""
        if not self._check_group_permission(event):
            yield event.plain_result("⚠️ 此群组未被授权使用 DND 插件")
            event.stop_event()
            return

        user_id = str(event.get_sender_id())
        group_id = str(event.get_group_id())
        
        ctx = self.combat_manager.get_combat(group_id)
        if not ctx or ctx.phase == CombatPhase.WAITING:
            yield event.plain_result("⚠️ 当前没有进行中的战斗")
            return
        
        fighter = ctx.get_fighter_by_sender(user_id)
        if not fighter:
            yield event.plain_result("❌ 你没有参与这场战斗")
            return
        
        fighter.action_used = True
        fighter.bonus_action_used = True
        
        yield event.plain_result(f"⏭️ **{fighter.name}** 跳过回合。")

    @dnd.command("怪物", alias={"monster"})
    @filter.event_message_type(event_filter.EventMessageType.GROUP_MESSAGE)
    async def dnd_monster(self, event: AstrMessageEvent, monster_name: str = ""):
        """查询怪物信息"""
        if not self._check_group_permission(event):
            yield event.plain_result("⚠️ 此群组未被授权使用 DND 插件")
            event.stop_event()
            return

        if monster_name:
            monster_data = WATERDEEP_ARENA_MONSTERS.get(monster_name)
            if monster_data:
                text = f"👹 **{monster_name}**\n━━━━━━━━━━━━━━━━━━━━\n"
                text += f"名称(EN): {monster_data.get('name_en', '-')}\n"
                text += f"挑战等级: CR {monster_data.get('cr', 1)}\n"
                text += f"生命值: {monster_data.get('max_hp', 0)}\n"
                text += f"护甲等级: {monster_data.get('armor_class', 10)}\n"
                text += f"攻击加值: +{monster_data.get('attack_bonus', 0)}\n"
                text += f"伤害: {monster_data.get('damage', '-')}\n"
                text += f"描述: {monster_data.get('description', '-')}\n"
                
                node_list = [
                    Comp.Node(
                        uin=str(event.get_self_id()),
                        name=f"👹 {monster_name}",
                        content=[Comp.Plain(text)]
                    )
                ]
                yield event.chain_result([Comp.Nodes(node_list)])
            else:
                yield event.plain_result(f"❌ 未找到怪物「{monster_name}」\n💡 使用 /dnd 怪物 查看所有怪物")
        else:
            text = "📋 **所有怪物列表**\n━━━━━━━━━━━━━━━━━━━━\n\n"
            text += "🔵 简单难度 (CR 0-0.5):\n"
            for name in ["流浪汉", "街头混混", "醉汉", "巨型老鼠"]:
                text += f"  • {name}\n"
            text += "\n🟡 中等难度 (CR 1-2):\n"
            for name in ["帮派打手", "腐败守卫", "鼠人术士", "黑市拳手"]:
                text += f"  • {name}\n"
            text += "\n🔴 困难难度 (CR 3+):\n"
            for name in ["噬魂帮头目", "城市法师议会探员", "堕落圣武士", "深渊领主的使者"]:
                text += f"  • {name}\n"
            text += "\n━━━━━━━━━━━━━━━━━━━━\n💡 使用 `/dnd 怪物 <名称>` 查看详情"
            
            node_list = [
                Comp.Node(
                    uin=str(event.get_self_id()),
                    name="📋 怪物图鉴",
                    content=[Comp.Plain(text)]
                )
            ]
            yield event.chain_result([Comp.Nodes(node_list)])

    @dnd.command("dndadmin", alias={"调试"})
    @filter.event_message_type(event_filter.EventMessageType.GROUP_MESSAGE)
    async def dnd_debug(self, event: AstrMessageEvent, action: str = "", target: str = ""):
        """管理员调试命令"""
        if not self._check_superadmin(event):
            yield event.plain_result("⚠️ 此指令仅限超级管理员使用")
            event.stop_event()
            return

        user_id = str(event.get_sender_id())
        
        if action == "无敌":
            self.admin_modes[user_id] = {"god_mode": True}
            yield event.plain_result("✨ 无敌模式已开启！")
        elif action == "秒杀":
            self.admin_modes[user_id] = {"one_hit_kill": True}
            yield event.plain_result("💀 秒杀模式已开启！")
        elif action == "死亡":
            if user_id in self.characters:
                self.characters[user_id].hit_points = 0
                yield event.plain_result("💀 角色已死亡")
            else:
                yield event.plain_result("❌ 未找到角色")
        elif action == "满血":
            if user_id in self.characters:
                char = self.characters[user_id]
                char.hit_points = char.max_hit_points
                yield event.plain_result(f"❤️ {char.name} 已恢复满血！")
            else:
                yield event.plain_result("❌ 未找到角色")
        elif action == "状态":
            modes = self.admin_modes.get(user_id, {})
            yield event.plain_result(f"🔧 管理员模式状态\n无敌模式: {'✅' if modes.get('god_mode') else '❌'}\n秒杀模式: {'✅' if modes.get('one_hit_kill') else '❌'}")
        elif action == "关闭":
            if user_id in self.admin_modes:
                del self.admin_modes[user_id]
            yield event.plain_result("✅ 所有管理员模式已关闭")
        else:
            yield event.plain_result("🔧 管理员调试命令\n━━━━━━━━━━━━━━━━━━━━\n无敌/秒杀/死亡/满血/状态/关闭")

    async def on_astrbot_loaded(self):
        """AstrBot 初始化完成的钩子"""
        logger.info("AstrBot 已加载，DND/Zero 插件准备就绪")
