"""
D&D 5e 背景数据库
包含全部13个背景的完整数据
"""
from dataclasses import dataclass, field
from typing import List, Optional, Dict


@dataclass
class Background:
    """D&D 背景"""
    name_cn: str
    name_en: str
    skill_proficiencies: List[str]
    languages: int = 0
    tool_proficiencies: List[str] = field(default_factory=list)
    equipment: List[str] = field(default_factory=list)
    feature: str = ""
    feature_description: str = ""
    suggested_traits: List[str] = field(default_factory=list)
    description: str = ""


class BackgroundDatabase:
    """背景数据库
    
    注意：数据库键使用中文名，与 name_cn 字段一致。
    """

    BACKGROUNDS: Dict[str, Background] = {
        "学者": Background(
            name_cn="学者",
            name_en="Sage",
            skill_proficiencies=["奥秘", "历史"],
            languages=2,
            feature="获取典籍",
            feature_description="在需要查找特定信息时，你知道如何寻找答案。向DM询问时，你总能想起相关的民间传说或学术资料。",
            suggested_traits=["我阅读量巨大，什么领域都有涉猎。", "我相信万事皆有理可循。"],
            description="在图书馆或学院度过早年时光，积累了大量知识。"
        ),
        "商人": Background(
            name_cn="商人",
            name_en="Merchant",
            skill_proficiencies=["洞察", "说服"],
            languages=1,
            tool_proficiencies=["商人工具"],
            equipment=["天平", "代币"],
            feature="商路通达",
            feature_description="你在商路上广有人脉。当你处于繁华城镇或城市时，可以免费获得当地最新的消息和情报。",
            suggested_traits=["我会奉承遇到的每个人，让他们感觉特殊。", "我精于计算，总在权衡利弊。"],
            description="从小商贩成长为富甲一方的商人。"
        ),
        "罪犯": Background(
            name_cn="罪犯",
            name_en="Criminal",
            skill_proficiencies=["欺瞒", "隐匿"],
            tool_proficiencies=["盗贼工具", "一种赌博工具"],
            equipment=["撬锁工具", "赌博筹码"],
            feature="地下联络",
            feature_description="你在犯罪世界的地下联络网中有门路。当处于你熟悉的犯罪活动区域时，你可以获得各种非法货物和情报。",
            suggested_traits=["我对每个人都有所保留。", "我会为正确的事业做错误的事。"],
            description="在街头或黑社会中摸爬滚打。"
        ),
        "艺人": Background(
            name_cn="艺人",
            name_en="Entertainer",
            skill_proficiencies=["杂技", "表演"],
            tool_proficiencies=["一种乐器", "艺人服装"],
            equipment=["乐器", "一面铜镜"],
            feature="闻名遐迩",
            feature_description="你在当地小有名气。当你于酒馆或类似场所表演时，总能获得免费食宿。",
            suggested_traits=["成功在于不懈努力。", "世界是一个舞台，而我就是主角。"],
            description="以表演为生的艺人，擅长音乐、舞蹈或杂耍。"
        ),
        "民间英雄": Background(
            name_cn="民间英雄",
            name_en="Folk Hero",
            skill_proficiencies=["驯兽", "求生"],
            tool_proficiencies=["一种工匠工具"],
            equipment=["铁铲", "皮水袋"],
            feature="乡野名望",
            feature_description="你出身乡野，如今小有名气。当你在农村地区时，人们了解并尊敬你。",
            suggested_traits=["我为受到不公的人挺身而出。", "我的标准很简单：努力工作，公平交易。"],
            description="从平民中崛起的英雄人物。"
        ),
        "隐士": Background(
            name_cn="隐士",
            name_en="Hermit",
            skill_proficiencies=["医药", "宗教"],
            languages=1,
            tool_proficiencies=["草药师工具"],
            equipment=["草药师工具", "睡袋", "日记"],
            feature="隐秘庇护",
            feature_description="你在某处隐秘地点隐居过很长时间，因而对周边地区了如指掌。",
            suggested_traits=["我远离喧嚣，追求内心的平静。", "我在思考后才开口，总能切中要害。"],
            description="远离人群的独居修行者。"
        ),
        "贵族": Background(
            name_cn="贵族",
            name_en="Noble",
            skill_proficiencies=["历史", "说服"],
            languages=1,
            tool_proficiencies=["一种游戏"],
            equipment=["华丽的衣服", "印章戒指"],
            feature="显赫声望",
            feature_description="你的话有分量。你提出的请求通常会被认真对待。",
            suggested_traits=["我对所有人都以礼相待，无论贫富贵贱。", "我以家族的荣誉担保。"],
            description="出身名门望族的特权阶层。"
        ),
        "农民": Background(
            name_cn="农民",
            name_en="Peasant",
            skill_proficiencies=["自然", "求生"],
            tool_proficiencies=["农具"],
            equipment=["草帽", "水壶"],
            feature="乡野生活",
            feature_description="你熟悉农作物种植和家畜饲养，能更好地获取食物。",
            suggested_traits=["我珍惜每一次收获。", "我相信勤劳致富。"],
            description="世代务农的普通百姓。"
        ),
        "船员": Background(
            name_cn="船员",
            name_en="Sailor",
            skill_proficiencies=["运动", "察觉"],
            tool_proficiencies=["导航工具", "水上交通工具"],
            equipment=["绳索", "幸运符"],
            feature="船难幸存者",
            feature_description="你曾在海难中幸存。你知道沉船事件的内情，并在附近海域有不小的名气。",
            suggested_traits=["我会毫不犹豫地为同伴献出生命。", "我工作时唱水手歌。"],
            description="在船上讨生活的航海者。"
        ),
        "士兵": Background(
            name_cn="士兵",
            name_en="Soldier",
            skill_proficiencies=["运动", "威吓"],
            tool_proficiencies=["一种赌博工具", "武器"],
            equipment=["征兵徽章", "骰子"],
            feature="军事传统",
            feature_description="你在军队中服役过。你与其他士兵建立了战友关系。",
            suggested_traits=["我严格遵守纪律。", "胜利才是最重要的。"],
            description="服役于军队的战士。"
        ),
        "流浪者": Background(
            name_cn="流浪者",
            name_en="Urchin",
            skill_proficiencies=["巧手", "隐匿"],
            tool_proficiencies=["盗贼工具", "陶艺工具"],
            equipment=["小刀", "社区地图"],
            feature="街头生存",
            feature_description="你熟悉城市街道，懂得如何在此生存。你总能找到一个躲避风雨的安全之所。",
            suggested_traits=["我总是看人下菜碟。", "我愿意为弱者挺身而出。"],
            description="在街头流浪的孤儿。"
        ),
        "祭司": Background(
            name_cn="祭司",
            name_en="Acolyte",
            skill_proficiencies=["洞察", "宗教"],
            languages=2,
            equipment=["祈祷书", "供香"],
            feature="宗教庇护",
            feature_description="你在教堂或宗教组织中有一定地位。那些与你信仰相同的信徒会为你提供食宿。",
            suggested_traits=["我尊重所有生命。", "我从不宽恕犯罪行为。"],
            description="宗教组织的虔诚成员。"
        ),
        "古怪": Background(
            name_cn="古怪",
            name_en="Outlander",
            skill_proficiencies=["运动", "求生"],
            languages=1,
            tool_proficiencies=["一种乐器"],
            equipment=["乐器", "朝圣用品"],
            feature="流浪者背景",
            feature_description="你足迹遍布各地，对各种地形都有了解。当寻找食物或水源时，你可以利用求生技能。",
            suggested_traits=["我总是保持乐观。", "我喜欢新的挑战。"],
            description="来自偏远地区的漫游者。"
        )
    }

    @classmethod
    def get_all_backgrounds(cls) -> List[str]:
        """获取所有背景名称"""
        return list(cls.BACKGROUNDS.keys())

    @classmethod
    def get_background(cls, name: str) -> Optional[Background]:
        """获取背景数据"""
        name = name.strip()
        if name in cls.BACKGROUNDS:
            return cls.BACKGROUNDS[name]
        for cn, bg_data in cls.BACKGROUNDS.items():
            if bg_data.name_en.lower() == name.lower():
                return bg_data
        return None

    @classmethod
    def get_background_info(cls, name: str) -> Optional[str]:
        """获取背景信息文本"""
        bg = cls.get_background(name)
        if not bg:
            return None

        info = f"📜 {bg.name_cn} ({bg.name_en})\n"
        info += f"━━━━━━━━━━━━━━━━━━━━\n"
        info += f"📖 {bg.description}\n\n"
        info += f"🎯 技能熟练: {', '.join(bg.skill_proficiencies)}\n"

        if bg.languages > 0:
            info += f"📚 可选语言: {bg.languages}门\n"

        if bg.tool_proficiencies:
            info += f"🔧 工具熟练: {', '.join(bg.tool_proficiencies)}\n"

        if bg.equipment:
            info += f"🎒 起始装备: {', '.join(bg.equipment)}\n"

        if bg.feature:
            info += f"\n⭐ 背景特性: {bg.feature}\n"
            info += f"   {bg.feature_description}\n"

        return info

    @classmethod
    def get_background_skill_choice_count(cls, bg_name: str) -> int:
        """获取背景提供技能熟练数量"""
        bg = cls.get_background(bg_name)
        return len(bg.skill_proficiencies) if bg else 0
