"""
D&D 5e 数据加载模块
"""
from .loader import DataLoader

__all__ = ['DataLoader']
