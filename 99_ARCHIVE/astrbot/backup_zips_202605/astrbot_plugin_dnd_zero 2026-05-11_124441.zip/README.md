# AstrBot DND/TRPG 插件

> 基于D&D 5e规则的轻量化群组跑团插件

## ✨ 核心功能

- ✅ **D20骰子系统** - 完整的D&D掷骰引擎
- ✅ **角色创建系统** - 12职业、9种族、13背景
- ✅ **技能检定** - 18项技能全覆盖
- ✅ **战斗系统** - 回合制战斗流程
- ✅ **法术系统** - 核心法术数据库
- ✅ **中文界面** - 友好的中文交互

## 🚀 快速开始

```
/dnd create    # 创建角色
/dnd roll d20 # 掷骰
/dnd status    # 查看角色
/dnd help      # 获取帮助
```

## 📖 详细文档

详见 [docs/USER_GUIDE.md](docs/USER_GUIDE.md)

## 📊 版本信息

| 版本 | 状态 | 日期 |
|------|------|------|
| v0.2.1 | 正式版 | 2026-05-10 |
| v0.2.0 | 正式版 | 2026-05-09 |
| v0.1.0 | 初始版 | 2026-05-09 |

## 📄 许可证

MIT License

## 👨‍💻 作者

MagicalYu

## 🔗 相关链接

- GitHub: https://github.com/MagicalYu/astrbot_plugin_dnd_zero
- AstrBot: https://astrbot.app/
- 数据来源: 5etools中文站 (https://5e.kiwee.top/)

---

**版本**: v0.2.1
**最后更新**: 2026-05-10
