# AstrBot DND/TRPG 插件项目说明

## 📁 项目结构

```
astrbot_plugin_dnd_zero/
├── backup/                      # 备份目录（自动备份）
├── data/                        # 数据目录（存储玩家数据）
├── util/                        # 工具模块目录
│   └── __init__.py             # 工具函数和数据管理
├── main.py                      # 插件主文件 ⭐
├── metadata.yaml                # 插件元数据 ⭐
├── _conf_schema.json            # 配置定义 ⭐
└── requirements.txt            # 依赖列表
```

## 📝 文件说明

### 1. main.py（核心插件文件）
- **类名**: `DNDZeroPlugin`
- **继承**: `Star` 基类
- **主要功能**:
  - 插件初始化和卸载管理
  - 群组权限控制
  - 指令处理（/dnd 指令组）
  - LLM 钩子预留

**已实现指令**:
- `/dnd menu` - 显示帮助菜单
- `/dnd help` - 获取帮助信息
- `/dnd admin reload` - 重载配置（管理员）
- `/dnd admin status` - 查看状态（管理员）

### 2. metadata.yaml（插件元数据）
```yaml
name: astrbot_plugin_dnd_zero
desc: 基于简化D&D规则的群友TRPG跑团插件
version: v0.1.0
author: MagicalYu
display_name: DND/Zero 群组跑团
```

### 3. _conf_schema.json（配置文件）
```json
{
    "superadmins": [],           # 超级管理员列表
    "whitelist_mode": false,      # 启用群白名单
    "whitelist_groups": [],       # 白名单群组ID
    "dm_model": "gpt-4o"          # DM大模型选择
}
```

### 4. util/__init__.py（工具模块）
提供的功能：
- `DataManager` - 数据管理器（JSON 读写）
- `format_dice_result()` - 格式化掷骰结果
- `check_permission()` - 权限检查
- `get_group_data_path()` - 获取群组数据路径

## 🚀 使用方法

### 安装插件
1. 将插件文件夹复制到 AstrBot 的 `data/plugins/` 目录
2. 重启 AstrBot 或在 WebUI 中点击"重载插件"

### 配置插件
1. 在 AstrBot WebUI 的插件管理页面配置：
   - 添加超级管理员 QQ 号
   - 设置是否启用白名单模式
   - 配置白名单群组 ID
   - 选择 DM 大模型

### 使用指令
在群聊中使用：
```
/dnd menu     # 查看帮助菜单
/dnd help     # 获取帮助
/dnd admin status   # 查看插件状态（管理员）
```

## 🔧 扩展指南

### 添加新指令
在 `main.py` 的 `DNDZeroPlugin` 类中添加：

```python
@dnd.command("新指令")
@filter.event_message_type(event_filter.EventMessageType.GROUP_MESSAGE)
async def new_command(self, event: AstrMessageEvent):
    """指令说明"""
    yield event.plain_result("指令响应")
```

### 存储玩家数据
```python
# 使用 DataManager
player_data = self.data_manager.load_json("players.json")
self.data_manager.save_json("players.json", new_data)
```

### 调用 LLM
```python
provider_id = await self.context.get_current_chat_provider_id(umo=event.unified_msg_origin)
llm_resp = await self.context.llm_generate(
    chat_provider_id=provider_id,
    prompt="你的提示词"
)
```

## 📋 开发规范

遵循 AstrBot 插件开发规范：
- ✅ 继承 `Star` 基类
- ✅ 使用异步编程（async/await）
- ✅ 使用 `filter` 装饰器注册指令
- ✅ 消息回复使用 `@filter.event_message_type`
- ✅ 配置使用 `AstrBotConfig`
- ✅ 数据存储在 `data/` 目录
- ✅ 不使用 `requests` 库，使用 `httpx`
- ✅ 使用 ruff 格式化代码

## 🔒 权限控制

### 超级管理员
- 可执行 `/dnd admin` 指令
- 配置检查：`self._check_superadmin(event)`

### 群组权限
- 白名单模式：`whitelist_mode = true`
- 非白名单模式：所有群组可用
- 权限检查：`self._check_group_permission(event)`

## 📞 技术支持

- GitHub: https://github.com/MagicalYu/astrbot_plugin_dnd_zero
- 插件市场: https://plugins.astrbot.app/

## 📄 许可证

MIT License

## 👨‍💻 作者

MagicalYu

---

**版本**: v0.1.0  
**创建日期**: 2026-05-09  
**最后更新**: 2026-05-09
