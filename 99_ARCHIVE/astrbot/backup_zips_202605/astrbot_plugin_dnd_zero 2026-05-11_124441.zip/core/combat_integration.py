"""
D&D/Zero 战斗系统集成
将角色、职业、技能、法术适配到新战斗系统
"""
from typing import List, Optional, Dict, Tuple
from .combat_position import AttackRange, MELEE_RANGE, RANGED_RANGE, PIERCE_RANGE
from .combat_unit import CombatUnit, PlayerUnit, MonsterUnit, create_monster
from .combat_skill import Skill, SkillDatabase
from .combat_manager import CombatManager
from .character import Character
from .spell import Spell


class CombatAdapter:
    """战斗适配器 - 将角色转换为战斗单位"""

    @classmethod
    def character_to_player_unit(cls, character: Character) -> PlayerUnit:
        """将角色卡转换为玩家战斗单位"""
        player_unit = PlayerUnit(
            unit_id=f"player_{character.character_id}",
            name=character.name,
            unit_type="player",
            player_id=character.character_id,
            player_name=character.name,
            class_name=character.class_name,
            level=character.level,
            max_hp=character.max_hp,
            current_hp=character.current_hp,
            armor_class=character.armor_class,
            speed=character.speed,
            proficiency_bonus=character.proficiency_bonus,
            abilities={
                "strength": character.abilities.strength,
                "dexterity": character.abilities.dexterity,
                "constitution": character.abilities.constitution,
                "intelligence": character.abilities.intelligence,
                "wisdom": character.abilities.wisdom,
                "charisma": character.abilities.charisma,
            },
            racial_traits=[r.name for r in character.race.traits] if character.race else [],
            class_features=[],
            attack_bonus=cls._calculate_attack_bonus(character),
            damage_bonus=cls._calculate_damage_bonus(character),
            spell_slots=cls._get_spell_slots(character),
            prepared_spells=[s.name for s in character.prepared_spells] if hasattr(character, 'prepared_spells') else [],
            weapon_range=cls._get_weapon_range(character),
            default_weapon=SkillDatabase.get_default_attack(character.class_name),
            default_damage=cls._get_default_damage(character)
        )

        return player_unit

    @classmethod
    def _calculate_attack_bonus(cls, character: Character) -> int:
        """计算攻击加值"""
        attack_modifier = character.abilities.get_modifier(character.primary_attack_ability)
        return attack_modifier + character.proficiency_bonus

    @classmethod
    def _calculate_damage_bonus(cls, character: Character) -> int:
        """计算伤害加值"""
        return character.abilities.get_modifier(character.primary_attack_ability)

    @classmethod
    def _get_weapon_range(cls, character: Character) -> AttackRange:
        """获取武器攻击范围"""
        if character.class_name in ["法师", "术士", "吟游诗人"]:
            return RANGED_RANGE

        if character.class_name == "游侠" and "弓" in str(character.equipment):
            return RANGED_RANGE

        return MELEE_RANGE

    @classmethod
    def _get_default_damage(cls, character: Character) -> str:
        """获取默认伤害骰"""
        damage_table = {
            "战士": "1d8",
            "野蛮人": "1d12",
            "圣武士": "1d8",
            "游侠": "1d8",
            "盗贼": "1d8",
            "僧侣": "1d8",
            "法师": "1d10",
            "术士": "1d6",
            "牧师": "1d8",
            "德鲁伊": "1d8",
            "吟游诗人": "1d8",
            "奇械师": "1d8"
        }

        return damage_table.get(character.class_name, "1d6")

    @classmethod
    def _get_spell_slots(cls, character: Character) -> Dict[int, int]:
        """获取法术位"""
        spellcaster_classes = ["法师", "术士", "牧师", "德鲁伊", "吟游诗人", "圣武士", "奇械师"]

        if character.class_name not in spellcaster_classes:
            return {}

        spell_slots = {}
        level = character.level

        if level >= 1:
            spell_slots[1] = 2
        if level >= 3:
            spell_slots[2] = 2
        if level >= 5:
            spell_slots[3] = 2
        if level >= 7:
            spell_slots[4] = 1
        if level >= 9:
            spell_slots[5] = 1

        return spell_slots

    @classmethod
    def update_character_from_combat(cls, character: Character, player_unit: PlayerUnit):
        """战斗结束后更新角色数据"""
        character.current_hp = player_unit.current_hp
        character.temp_hp = player_unit.temp_hp


class MonsterCombatIntegration:
    """怪物战斗集成"""

    @classmethod
    def create_encounter(cls, difficulty: str = "normal", party_level: int = 1) -> List[MonsterUnit]:
        """创建遭遇"""
        encounters = {
            "easy": ["哥布林", "哥布林"],
            "normal": ["哥布林", "哥布林", "狼人"],
            "hard": ["狼人", "狼人", "食尸鬼"],
            "boss": ["牛头人"]
        }

        monster_types = encounters.get(difficulty, encounters["normal"])

        monsters = []
        for i, monster_type in enumerate(monster_types):
            monster = create_monster(monster_type, position=i+1)
            if monster:
                cls._scale_monster(monster, party_level)
                monsters.append(monster)

        return monsters

    @classmethod
    def _scale_monster(cls, monster: MonsterUnit, party_level: int):
        """缩放怪物属性"""
        if party_level > monster.cr:
            scaling = (party_level - monster.cr) * 0.1
            monster.max_hp = int(monster.max_hp * (1 + scaling))
            monster.current_hp = monster.max_hp
            monster.attack_bonus += (party_level - monster.cr) // 2


class SkillCombatIntegration:
    """技能战斗集成"""

    @classmethod
    def get_combat_skills(cls, class_name: str) -> List[Skill]:
        """获取职业的战斗技能"""
        return SkillDatabase.get_skills_by_class(class_name)

    @classmethod
    def format_skill_list(cls, skills: List[Skill]) -> str:
        """格式化技能列表"""
        text = "📋 **可用技能**\n"
        text += "━━━━━━━━━━━━━━━━━━━━\n\n"

        standard = [s for s in skills if s.action_type == "action"]
        bonus = [s for s in skills if s.action_type == "bonus_action"]
        reaction = [s for s in skills if s.action_type == "reaction"]

        if standard:
            text += "📌 **标准动作**\n"
            for skill in standard:
                text += f"  • {skill.name_cn} ({skill.skill_type})\n"
            text += "\n"

        if bonus:
            text += "⚡ **附赠动作**\n"
            for skill in bonus:
                text += f"  • {skill.name_cn}\n"
            text += "\n"

        if reaction:
            text += "🔄 **反应**\n"
            for skill in reaction:
                text += f"  • {skill.name_cn}\n"

        return text


class SpellCombatIntegration:
    """法术战斗集成"""

    @classmethod
    def convert_spell_to_skill(cls, spell: Spell, caster_level: int) -> Optional[Skill]:
        """将法术转换为战斗技能"""
        if spell.level == 0:
            damage = f"{caster_level // 2 + 1}d10"
        elif spell.level == 1:
            damage = "2d10"
        elif spell.level == 2:
            damage = "3d10"
        elif spell.level == 3:
            damage = "4d10"
        else:
            damage = "5d10"

        save_dc = 8 + caster_level // 4
        save_ability = "dexterity"

        if spell.school in ["防护", "预言"]:
            save_ability = "wisdom"
        elif spell.school in ["附魔", "惑控"]:
            save_ability = "charisma"

        skill = Skill(
            skill_id=f"spell_{spell.name}",
            name=spell.name,
            name_cn=spell.name,
            skill_type="attack" if spell.damage else "effect",
            range=4,
            range_start=1,
            damage=damage if spell.damage else "0",
            damage_type=spell.damage_type if hasattr(spell, 'damage_type') else "force",
            action_type="action",
            spell_level=spell.level,
            spell_save_dc=save_dc,
            spell_save_ability=save_ability,
            requires_attack=spell.attack_roll if hasattr(spell, 'attack_roll') else False,
            description=spell.description if hasattr(spell, 'description') else ""
        )

        return skill


class ItemCombatIntegration:
    """道具战斗集成"""

    USABLE_ITEMS = {
        "治疗药水": {"heal": "2d4+2", "action": "action"},
        "中级治疗药水": {"heal": "4d4+4", "action": "action"},
        "高级治疗药水": {"heal": "8d4+8", "action": "action"},
        "防护药水": {"ac_bonus": 2, "duration": 1, "action": "bonus_action"},
        "力量药水": {"str_bonus": 2, "duration": 1, "action": "bonus_action"},
        "敏捷药水": {"dex_bonus": 2, "duration": 1, "action": "bonus_action"},
        "火把": {"damage": "1d6", "damage_type": "fire", "range": 2, "start": 1},
        "匕首投掷": {"damage": "1d4", "range": 4, "start": 1}
    }

    @classmethod
    def get_item_skill(cls, item_name: str) -> Optional[Dict]:
        """获取道具对应的战斗技能"""
        for key, value in cls.USABLE_ITEMS.items():
            if key in item_name:
                return value
        return None

    @classmethod
    def format_inventory(cls, items: List[str]) -> str:
        """格式化背包（战斗可用物品高亮）"""
        text = "🎒 **背包**\n"
        text += "━━━━━━━━━━━━━━━━━━━━\n\n"

        usable = []
        others = []

        for item in items:
            if cls.get_item_skill(item):
                usable.append(item)
            else:
                others.append(item)

        if usable:
            text += "⚔️ **战斗可用**\n"
            for item in usable:
                skill = cls.get_item_skill(item)
                text += f"  • {item}"
                if "heal" in skill:
                    text += f" (治疗{skill['heal']})"
                text += "\n"
            text += "\n"

        if others:
            text += "📦 **其他物品**\n"
            for item in others[:10]:
                text += f"  • {item}\n"

        return text
