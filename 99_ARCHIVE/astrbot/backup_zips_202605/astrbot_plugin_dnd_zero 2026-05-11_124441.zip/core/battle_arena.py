"""
D&D/Zero 战斗训练场系统
城镇新增区域 - 独立于副本的战斗测试场所
"""
import random
import uuid
from dataclasses import dataclass, field
from typing import List, Optional, Dict, Tuple
from enum import Enum

from .combat_position import AttackRange, MELEE_RANGE, RANGED_RANGE, PIERCE_RANGE
from .combat_unit import CombatUnit, PlayerUnit, MonsterUnit
from .combat_skill import Skill, SkillDatabase
from .combat_manager import CombatManager


class Difficulty(Enum):
    """难度等级"""
    EASY = "easy"        # 简单
    MEDIUM = "medium"    # 中等
    HARD = "hard"        # 困难


@dataclass
class BattleArenaMonster:
    """战斗场怪物模板 - 贴合深水城背景"""
    monster_id: str
    name: str
    name_en: str
    cr: int

    max_hp: int
    armor_class: int
    attack_bonus: int
    damage: str
    damage_type: str = "physical"

    description: str = ""
    special_abilities: List[str] = field(default_factory=list)

    behavior_script: str = "aggressive"
    target_priority: List[str] = field(default_factory=list)

    xp_reward: int = 0
    gold_reward: int = 0

    def to_monster_unit(self, position: int = 1) -> MonsterUnit:
        """转换为战斗单位"""
        return MonsterUnit(
            unit_id=f"arena_{self.monster_id}_{uuid.uuid4().hex[:8]}",
            name=self.name,
            unit_type="monster",
            position=position,
            original_position=position,
            max_hp=self.max_hp,
            current_hp=self.max_hp,
            armor_class=self.armor_class,
            attack_bonus=self.attack_bonus,
            damage_bonus=0,
            monster_role="warrior",
            cr=self.cr,
            behavior_script=self.behavior_script,
            target_priority=self.target_priority,
            special_abilities=self.special_abilities,
            xp_reward=self.xp_reward,
            weapon_range=MELEE_RANGE,
            default_damage=self.damage
        )


WATERDEEP_ARENA_MONSTERS = {
    # ===== 简单难度（1-3级角色）=====
    "流浪汉": {
        "name": "流浪汉",
        "name_en": "Vagrant",
        "cr": 0.125,
        "max_hp": 4,
        "armor_class": 10,
        "attack_bonus": 2,
        "damage": "1d4",
        "description": "深水城街头的落魄流浪者，被逼无奈时也会拿起武器",
        "behavior_script": "aggressive",
        "target_priority": ["front_row"],
        "xp_reward": 10,
        "gold_reward": 5
    },
    "街头混混": {
        "name": "街头混混",
        "name_en": "Thug",
        "cr": 0.5,
        "max_hp": 18,
        "armor_class": 11,
        "attack_bonus": 4,
        "damage": "1d6+2",
        "description": "南区帮派的底层打手，为了几个铜板什么都干",
        "behavior_script": "aggressive",
        "target_priority": ["front_row"],
        "xp_reward": 50,
        "gold_reward": 15
    },
    "醉汉": {
        "name": "醉汉",
        "name_en": "Drunkard",
        "cr": 0.25,
        "max_hp": 12,
        "armor_class": 10,
        "attack_bonus": 3,
        "damage": "1d4+1",
        "description": "醉月亭里喝多了的酒鬼，攻击毫无章法",
        "behavior_script": "aggressive",
        "target_priority": ["front_row", "low_hp"],
        "xp_reward": 25,
        "gold_reward": 10
    },
    "老鼠": {
        "name": "巨型老鼠",
        "name_en": "Giant Rat",
        "cr": 0.125,
        "max_hp": 7,
        "armor_class": 12,
        "attack_bonus": 4,
        "damage": "1d4+2",
        "description": "在下水道中变异的巨型老鼠，携带疾病",
        "behavior_script": "aggressive",
        "target_priority": ["low_hp"],
        "special_abilities": ["disease_bite"],
        "xp_reward": 10,
        "gold_reward": 0
    },

    # ===== 中等难度（4-7级角色）=====
    "帮派打手": {
        "name": "帮派打手",
        "name_en": "Gang Enforcer",
        "cr": 1,
        "max_hp": 32,
        "armor_class": 14,
        "attack_bonus": 5,
        "damage": "1d8+3",
        "description": "噬魂帮的专业打手，装备精良、配合默契",
        "behavior_script": "aggressive",
        "target_priority": ["front_row"],
        "xp_reward": 100,
        "gold_reward": 30
    },
    "腐败守卫": {
        "name": "腐败守卫",
        "name_en": "Corrupt Guard",
        "cr": 1,
        "max_hp": 28,
        "armor_class": 16,
        "attack_bonus": 5,
        "damage": "1d8+3",
        "description": "被金钱收买的城市守卫，背叛了誓言",
        "behavior_script": "defensive",
        "target_priority": ["back_row", "squishy"],
        "xp_reward": 100,
        "gold_reward": 50
    },
    "鼠人术士": {
        "name": "鼠人术士",
        "name_en": "Wererat Warlock",
        "cr": 2,
        "max_hp": 45,
        "armor_class": 12,
        "attack_bonus": 4,
        "damage": "1d10+2",
        "damage_type": "poison",
        "description": "鼠人氏族中的施法者，掌握着禁忌的毒系魔法",
        "behavior_script": "supportive",
        "target_priority": ["back_row", "low_hp"],
        "special_abilities": ["poison_spell", "cure_poison"],
        "spellcasting": True,
        "xp_reward": 200,
        "gold_reward": 75
    },
    "黑市商人": {
        "name": "黑市拳手",
        "name_en": "Pit Fighter",
        "cr": 2,
        "max_hp": 52,
        "armor_class": 15,
        "attack_bonus": 6,
        "damage": "2d6+4",
        "description": "地下拳场的冠军，为生存而战",
        "behavior_script": "aggressive",
        "target_priority": ["low_hp"],
        "xp_reward": 200,
        "gold_reward": 100
    },

    # ===== 困难难度（8+级角色）=====
    "噬魂帮头目": {
        "name": "噬魂帮头目",
        "name_en": "Soul Reaver Leader",
        "cr": 3,
        "max_hp": 68,
        "armor_class": 15,
        "attack_bonus": 6,
        "damage": "2d6+3",
        "damage_type": "necrotic",
        "description": "噬魂帮的领袖，窃取他人生命力为力量来源",
        "behavior_script": "aggressive",
        "target_priority": ["low_hp", "back_row"],
        "special_abilities": ["life_drain", "charm_person"],
        "xp_reward": 500,
        "gold_reward": 200
    },
    "城市法师议会探员": {
        "name": "城市法师议会探员",
        "name_en": "Magister Agent",
        "cr": 4,
        "max_hp": 55,
        "armor_class": 13,
        "attack_bonus": 5,
        "damage": "2d8+2",
        "damage_type": "force",
        "description": "城市法师议会的执法者，精通各种攻击法术",
        "behavior_script": "defensive",
        "target_priority": ["back_row", "squishy"],
        "special_abilities": ["fireball", "shield", "lightning_bolt"],
        "spellcasting": True,
        "xp_reward": 700,
        "gold_reward": 300
    },
    "堕落圣武士": {
        "name": "堕落圣武士",
        "name_en": "Fallen Paladin",
        "cr": 5,
        "max_hp": 85,
        "armor_class": 18,
        "attack_bonus": 7,
        "damage": "2d8+4",
        "damage_type": "radiant",
        "description": "曾经的光明侍者，如今被黑暗力量腐蚀",
        "behavior_script": "aggressive",
        "target_priority": ["front_row"],
        "special_abilities": ["divine_smite", "lay_on_hands", "aura_of_protection"],
        "xp_reward": 1000,
        "gold_reward": 400
    },
    "深渊领主的使者": {
        "name": "深渊领主的使者",
        "name_en": "Demon Lord Emissary",
        "cr": 6,
        "max_hp": 110,
        "armor_class": 16,
        "attack_bonus": 8,
        "damage": "2d10+5",
        "damage_type": "fire",
        "description": "来自深渊的高阶恶魔，试图在深水城建立据点",
        "behavior_script": "aggressive",
        "target_priority": ["back_row", "caster"],
        "special_abilities": ["fireball", "fear", "teleport"],
        "legendary_actions": 2,
        "xp_reward": 1500,
        "gold_reward": 600
    }
}


DIFFICULTY_SCALING = {
    Difficulty.EASY: {
        "monster_count_range": [1, 2],
        "hp_multiplier": 0.8,
        "damage_multiplier": 0.75,
        "ac_multiplier": 0.95,
        "description": "适合1-3级冒险者"
    },
    Difficulty.MEDIUM: {
        "monster_count_range": [2, 3],
        "hp_multiplier": 1.0,
        "damage_multiplier": 1.0,
        "ac_multiplier": 1.0,
        "description": "适合4-7级冒险者"
    },
    Difficulty.HARD: {
        "monster_count_range": [3, 4],
        "hp_multiplier": 1.3,
        "damage_multiplier": 1.2,
        "ac_multiplier": 1.05,
        "description": "适合8+级冒险者"
    }
}


class BattleArena:
    """战斗训练场"""

    def __init__(self):
        self.arena_id: str = str(uuid.uuid4())[:8].upper()
        self.current_combat: Optional[CombatManager] = None
        self.in_combat: bool = False
        self.debug_mode: bool = True

        self.battle_log: List[Dict] = []

    def get_available_monsters(self, difficulty: Difficulty) -> List[str]:
        """获取可用怪物列表"""
        monsters_by_cr = {
            (0, 0.5): ["流浪汉", "醉汉", "老鼠", "街头混混"],
            (0.5, 2): ["帮派打手", "腐败守卫", "鼠人术士", "黑市拳手"],
            (2, 10): ["噬魂帮头目", "城市法师议会探员", "堕落圣武士", "深渊领主的使者"]
        }

        for cr_range, monsters in monsters_by_cr.items():
            if difficulty == Difficulty.EASY and cr_range[1] <= 0.5:
                return monsters
            elif difficulty == Difficulty.MEDIUM and cr_range[0] < 2:
                return monsters
            elif difficulty == Difficulty.HARD and cr_range[0] >= 2:
                return monsters

        return list(WATERDEEP_ARENA_MONSTERS.keys())

    def generate_encounter(self, difficulty: Difficulty,
                         count: int = None) -> List[MonsterUnit]:
        """生成遭遇"""
        scaling = DIFFICULTY_SCALING[difficulty]

        if count is None:
            count_range = scaling["monster_count_range"]
            count = random.randint(count_range[0], count_range[1])

        available = self.get_available_monsters(difficulty)
        selected = random.sample(available, min(count, len(available)))

        monsters = []
        for i, monster_name in enumerate(selected):
            template = WATERDEEP_ARENA_MONSTERS.get(monster_name)
            if template:
                monster = MonsterUnit(
                    unit_id=f"arena_{monster_name}_{uuid.uuid4().hex[:8]}",
                    name=template["name"],
                    unit_type="monster",
                    position=i + 1,
                    original_position=i + 1,
                    max_hp=int(template["max_hp"] * scaling["hp_multiplier"]),
                    current_hp=int(template["max_hp"] * scaling["hp_multiplier"]),
                    armor_class=int(template["armor_class"] * scaling["ac_multiplier"]),
                    attack_bonus=template["attack_bonus"],
                    damage_bonus=0,
                    monster_role="warrior",
                    cr=template["cr"],
                    behavior_script=template.get("behavior_script", "aggressive"),
                    target_priority=template.get("target_priority", ["front_row"]),
                    special_abilities=template.get("special_abilities", []),
                    xp_reward=template["xp_reward"],
                    weapon_range=MELEE_RANGE,
                    default_damage=template["damage"]
                )
                monsters.append(monster)

        return monsters

    def format_monster_selection(self, difficulty: Difficulty) -> str:
        """格式化怪物选择菜单"""
        monsters = self.get_available_monsters(difficulty)

        text = f"⚔️ **战斗训练场 - 怪物选择**\n"
        text += f"━━━━━━━━━━━━━━━━━━━━\n\n"
        text += f"**难度**: {difficulty.value}\n"
        text += f"**说明**: {DIFFICULTY_SCALING[difficulty]['description']}\n\n"

        text += "**可选怪物**:\n"
        for i, monster_name in enumerate(monsters):
            template = WATERDEEP_ARENA_MONSTERS[monster_name]
            text += f"  {i+1}. {monster_name} (CR {template['cr']})\n"
            text += f"     HP: {template['max_hp']} | AC: {template['armor_class']}\n"
            text += f"     伤害: {template['damage']}\n"
            text += f"     {template['description']}\n\n"

        text += "━━━━━━━━━━━━━━━━━━━━\n"
        text += "**指令格式**:\n"
        text += "`/dnd 战斗场 开始 <数量>`\n"
        text += "例如: `/dnd 战斗场 开始 2`\n"

        return text

    def format_arena_menu(self) -> str:
        """格式化战斗场菜单"""
        text = "⚔️ **战斗训练场** ⚔️\n"
        text += "━━━━━━━━━━━━━━━━━━━━\n\n"
        text += "**位置**: 深水城南区·角斗场\n"
        text += "**功能**: 独立于副本的实战训练场所\n\n"

        text += "**可用难度**:\n"
        text += "  1️⃣ **简单** - 1-3级冒险者\n"
        text += "     怪物: 流浪汉、街头混混、醉汉等\n"
        text += "     数量: 1-2只\n\n"

        text += "  2️⃣ **中等** - 4-7级冒险者\n"
        text += "     怪物: 帮派打手、腐败守卫、鼠人术士等\n"
        text += "     数量: 2-3只\n\n"

        text += "  3️⃣ **困难** - 8+级冒险者\n"
        text += "     怪物: 帮派头目、堕落圣武士、深渊使者等\n"
        text += "     数量: 3-4只\n\n"

        text += "**组队支持**: ✅ 最多4人组队进入\n\n"

        text += "━━━━━━━━━━━━━━━━━━━━\n"
        text += "**指令**:\n"
        text += "`/dnd 战斗场 进入 <难度>` - 选择难度\n"
        text += "`/dnd 战斗场 怪物 <难度>` - 查看怪物列表\n"
        text += "`/dnd 战斗场 开始 <数量>` - 开始战斗\n"

        return text

    def log_battle_event(self, event_type: str, data: Dict):
        """记录战斗事件（用于调试）"""
        if self.debug_mode:
            self.battle_log.append({
                "type": event_type,
                "data": data,
                "timestamp": uuid.uuid4().hex[:8]
            })

    def format_debug_card(self) -> str:
        """生成调试卡片"""
        if not self.battle_log:
            return ""

        text = "📋 **战斗调试日志**\n"
        text += "━━━━━━━━━━━━━━━━━━━━\n\n"

        for log in self.battle_log[-20:]:
            event_type = log["type"]
            data = log["data"]

            if event_type == "combat_start":
                text += f"🎮 【战斗开始】\n"
                text += f"   战斗ID: {data.get('combat_id')}\n"
                text += f"   我方: {data.get('ally_count')}人\n"
                text += f"   敌方: {data.get('enemy_count')}人\n\n"

            elif event_type == "turn_start":
                text += f"🔄 【回合开始】第{data.get('round')}轮\n"
                text += f"   当前: {data.get('unit_name')}\n\n"

            elif event_type == "attack":
                text += f"⚔️ 【攻击】\n"
                text += f"   攻击者: {data.get('attacker')}\n"
                text += f"   目标: {data.get('target')}\n"
                text += f"   技能: {data.get('skill')}\n"
                text += f"   🎲 攻击骰: {data.get('attack_roll')}\n"
                text += f"   攻击加值: +{data.get('attack_bonus')}\n"
                text += f"   总计: {data.get('attack_total')}\n"
                text += f"   目标AC: {data.get('target_ac')}\n"
                text += f"   结果: {data.get('hit_result')}\n"

                if data.get('damage_result'):
                    text += f"   💥 伤害: {data.get('damage_result')}\n"
                text += "\n"

            elif event_type == "skill":
                text += f"✨ 【技能】{data.get('skill_name')}\n"
                text += f"   施法者: {data.get('caster')}\n"
                text += f"   目标: {data.get('target')}\n"
                text += f"   结果: {data.get('result')}\n\n"

            elif event_type == "heal":
                text += f"💚 【治疗】\n"
                text += f"   治疗者: {data.get('healer')}\n"
                text += f"   目标: {data.get('target')}\n"
                text += f"   治疗量: {data.get('heal_amount')}\n\n"

            elif event_type == "death_save":
                text += f"💀 【死亡豁免】\n"
                text += f"   单位: {data.get('unit_name')}\n"
                text += f"   掷骰: {data.get('roll')}\n"
                text += f"   结果: {data.get('result')}\n"
                text += f"   成功: {data.get('success_count')}/3\n"
                text += f"   失败: {data.get('fail_count')}/3\n\n"

            elif event_type == "position_change":
                text += f"🔄 【换位】\n"
                text += f"   单位: {data.get('unit')}\n"
                text += f"   从{data.get('from')}号位到{data.get('to')}号位\n\n"

            elif event_type == "turn_end":
                text += f"⏭️ 【回合结束】\n"
                text += f"   单位: {data.get('unit_name')}\n\n"

            elif event_type == "combat_end":
                text += f"🏆 【战斗结束】\n"
                text += f"   结果: {data.get('result')}\n"
                text += f"   胜利: {data.get('victory')}\n"
                text += f"   存活: {data.get('survivors')}\n"
                text += f"   XP奖励: {data.get('xp')}\n"
                text += f"   金币: {data.get('gold')}\n\n"

        return text

    def format_full_combat_debug(self, combat: CombatManager) -> str:
        """生成完整战斗调试信息"""
        text = "⚔️ **完整战斗调试信息** ⚔️\n"
        text += "━━━━━━━━━━━━━━━━━━━━\n\n"

        text += "【战斗基本信息】\n"
        text += f"  战斗ID: {combat.combat_id}\n"
        text += f"  回合数: 第{combat.round_number}轮\n"
        text += f"  当前状态: {combat.combat_state}\n"
        text += f"  短休剩余: {combat.short_rest_available}次\n\n"

        text += "【我方单位】\n"
        for pos in [1, 2, 3, 4]:
            unit = combat.ally_units.get(pos)
            if unit:
                text += self._format_unit_debug(unit, pos, True)
        text += "\n"

        text += "【敌方单位】\n"
        for pos in [1, 2, 3, 4]:
            unit = combat.enemy_units.get(pos)
            if unit:
                text += self._format_unit_debug(unit, pos, False)
        text += "\n"

        text += "【先攻顺序】\n"
        for i, unit in enumerate(combat.initiative_order):
            marker = "→" if i == combat.current_turn_index else " "
            status = "💀" if unit.is_dead else ("😵" if unit.is_unconscious else "⚔️")
            text += f"  {marker}{i+1}. {status} {unit.name} (位置{unit.position})\n"
        text += "\n"

        text += "【回合日志】\n"
        for log in combat.turn_log[-10:]:
            text += f"  - {log}\n"

        return text

    def _format_unit_debug(self, unit: CombatUnit, position: int, is_ally: bool) -> str:
        """格式化单位调试信息"""
        faction = "我方" if is_ally else "敌方"

        text = f"  {position}号位 [{faction}] {unit.name}\n"
        text += f"    HP: {unit.current_hp}/{unit.max_hp}\n"
        text += f"    AC: {unit.armor_class} (有效: {unit.get_effective_ac()})\n"
        text += f"    攻击加值: +{unit.attack_bonus}\n"
        text += f"    伤害: {unit.default_damage if hasattr(unit, 'default_damage') else 'N/A'}\n"

        if hasattr(unit, 'class_name'):
            text += f"    职业: {unit.class_name} Lv{unit.level}\n"

        if hasattr(unit, 'cr'):
            text += f"    CR: {unit.cr}\n"

        text += f"    属性: STR{unit.abilities.get('strength', 10)}({unit.get_modifier('strength'):+d}) "
        text += f"DEX{unit.abilities.get('dexterity', 10)}({unit.get_modifier('dexterity'):+d}) "
        text += f"CON{unit.abilities.get('constitution', 10)}({unit.get_modifier('constitution'):+d})\n"

        if hasattr(unit, 'abilities') and 'intelligence' in unit.abilities:
            text += f"           INT{unit.abilities.get('intelligence', 10)}({unit.get_modifier('intelligence'):+d}) "
            text += f"WIS{unit.abilities.get('wisdom', 10)}({unit.get_modifier('wisdom'):+d}) "
            text += f"CHA{unit.abilities.get('charisma', 10)}({unit.get_modifier('charisma'):+d})\n"

        text += f"    状态: "
        if unit.is_dead:
            text += "死亡 💀\n"
        elif unit.is_unconscious:
            text += f"昏迷 😵 (豁免成功{unit.death_saves.get('success',0)}/失败{unit.death_saves.get('fail',0)})\n"
        else:
            status = []
            if unit.action_used:
                status.append("动作已用")
            if unit.bonus_action_used:
                status.append("附赠已用")
            if unit.reaction_available:
                status.append("反应可用")
            else:
                status.append("反应已用")
            if unit.defending:
                status.append("防御中")
            if unit.dodging:
                status.append("躲避中")
            if unit.is_taunted:
                status.append("被嘲讽")
            text += ", ".join(status) if status else "正常" + "\n"

        if unit.conditions:
            text += f"    状态效果: {', '.join(unit.conditions)}\n"

        if hasattr(unit, 'spell_slots') and unit.spell_slots:
            text += f"    法术位: {unit.spell_slots}\n"

        return text


ARENA_INSTANCE = BattleArena()
