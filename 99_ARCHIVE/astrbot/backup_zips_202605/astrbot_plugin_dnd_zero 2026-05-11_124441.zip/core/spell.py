"""
D&D 5e 法术系统
法术查询、施放、法术位管理
"""
from dataclasses import dataclass, field
from typing import List, Optional, Dict
from enum import Enum


class SpellLevel(Enum):
    """法术环阶"""
    CANTRIP = 0
    LEVEL_1 = 1
    LEVEL_2 = 2
    LEVEL_3 = 3
    LEVEL_4 = 4
    LEVEL_5 = 5
    LEVEL_6 = 6
    LEVEL_7 = 7
    LEVEL_8 = 8
    LEVEL_9 = 9


class SpellSchool(Enum):
    """法术学派"""
    ABJURATION = "防护"
    CONJURATION = "咒术"
    DIVINATION = "预言"
    ENCHANTMENT = "附魔"
    EVOCATION = "塑能"
    ILLUSION = "幻术"
    NECROMANCY = "亡灵"
    TRANSMUTATION = "变化"


class CastingTime(Enum):
    """施法时间"""
    ACTION = "1个动作"
    BONUS_ACTION = "1个附赠动作"
    REACTION = "1个反应"
    MINUTE = "1分钟或更长"
    HOUR = "1小时或更长"


class SpellRange(Enum):
    """施法距离"""
    SELF = "自身"
    TOUCH = "触及"
    SIGHT = "视线内"
    SPECIAL = "特殊"


class SpellDuration(Enum):
    """持续时间"""
    INSTANTANEOUS = "立即"
    CONCENTRATION = "专注（最长1分钟）"
    MINUTE = "1分钟"
    HOUR = "1小时"
    DAY = "24小时"
    SPECIAL = "特殊"


@dataclass
class SpellComponent:
    """法术成分"""
    verbal: bool = False
    somatic: bool = False
    material: bool = False
    material_description: str = ""


@dataclass
class Spell:
    """法术"""
    name: str
    level: int
    school: str
    casting_time: str
    range: str
    components: SpellComponent
    duration: str
    description: str

    is_ritual: bool = False
    is_concentration: bool = False

    attack_type: Optional[str] = None
    save_dc: Optional[int] = None
    save_ability: Optional[str] = None

    damage_type: Optional[str] = None
    damage_scaling: Optional[str] = None

    higher_level_effect: Optional[str] = None

    classes: List[str] = field(default_factory=list)
    source: str = "PHB"

    def get_level_string(self) -> str:
        """获取环阶字符串"""
        if self.level == 0:
            return "戏法"
        return f"{self.level}环"

    def can_cast_at_level(self, character_level: int) -> bool:
        """判断角色等级是否能施放此法术"""
        if character_level >= 1 and self.level <= character_level:
            return True
        return False


@dataclass
class SpellSlot:
    """法术位"""
    level: int
    used: bool = False

    def use(self):
        """使用法术位"""
        self.used = True

    def restore(self):
        """恢复法术位"""
        self.used = False

    def __str__(self) -> str:
        status = "已用" if self.used else "可用"
        return f"{self.level}环 [{status}]"


@dataclass
class Spellcasting:
    """施法能力"""
    ability: str
    spell_save_dc: int
    spell_attack_bonus: int
    spell_slots: Dict[int, List[SpellSlot]] = field(default_factory=dict)
    known_spells: List[str] = field(default_factory=list)
    prepared_spells: List[str] = field(default_factory=list)

    def get_available_slots(self, level: int) -> int:
        """获取指定环阶可用的法术位数量"""
        slots = self.spell_slots.get(level, [])
        return sum(1 for slot in slots if not slot.used)

    def use_spell_slot(self, level: int) -> bool:
        """尝试使用法术位"""
        slots = self.spell_slots.get(level, [])
        for slot in slots:
            if not slot.used:
                slot.use()
                return True
        return False

    def restore_all_slots(self):
        """恢复所有法术位"""
        for level in self.spell_slots:
            for slot in self.spell_slots[level]:
                slot.restore()


class SpellDatabase:
    """法术数据库"""

    COMMON_SPELLS = {
        "fireball": Spell(
            name="火球术",
            level=3,
            school="塑能",
            casting_time="1个动作",
            range="150尺",
            components=SpellComponent(verbal=True, somatic=True, material=True, material_description="一撮硫磺和磷粉"),
            duration="立即",
            description="一个火球在指定点爆炸。区域内所有生物必须进行敏捷豁免，失败受到8d6火焰伤害，成功伤害减半。",
            damage_type="火焰",
            save_ability="dexterity",
            higher_level_effect="当你用3环或更高法术位施展时，法术伤害每个等级增加1d6。",
            classes=["法师", "牧师", "术士"]
        ),
        "magic_missile": Spell(
            name="魔法飞弹",
            level=1,
            school="塑能",
            casting_time="1个动作",
            range="120尺",
            components=SpellComponent(verbal=True, somatic=True),
            duration="立即",
            description="你创造三支导弹，每支对目标造成1d4+1力伤害。导弹同时命中。",
            attack_type="ranged",
            higher_level_effect="每升一环多创造1枚导弹。",
            classes=["法师", "术士"]
        ),
        "cure_wounds": Spell(
            name="疗伤术",
            level=1,
            school="防护",
            casting_time="1个动作",
            range="触及",
            components=SpellComponent(verbal=True, somatic=True),
            duration="立即",
            description="生物恢复1d8+你的施法属性调整值的生命值。",
            higher_level_effect="每升一环治疗伤害增加1d8。",
            classes=["吟游诗人", "牧师", "德鲁伊", "圣武士", "游侠"]
        ),
        "shield": Spell(
            name="护盾术",
            level=1,
            school="防护",
            casting_time="1个动作",
            range="自身",
            components=SpellComponent(verbal=True, somatic=True),
            duration="1轮",
            description="一个隐形的护盾围绕着你。在你的回合内，AC获得+5加值，直到回合结束。",
            classes=["法师", "圣武士", "术士"]
        ),
        "lightning_bolt": Spell(
            name="闪电束",
            level=3,
            school="塑能",
            casting_time="1个动作",
            range="自身（100尺线）",
            components=SpellComponent(verbal=True, somatic=True, material=True, material_description="一根琥珀棒和兽毛"),
            duration="立即",
            description="你释放一道闪电。在一条100尺长、5尺宽的线上的每个生物必须进行敏捷豁免。失败受到8d6闪电伤害，成功伤害减半。",
            damage_type="闪电",
            save_ability="dexterity",
            higher_level_effect="每升一环伤害增加1d6。",
            classes=["法师", "术士", "德鲁伊", "游侠"]
        ),
        "healing_word": Spell(
            name="治愈真言",
            level=1,
            school="防护",
            casting_time="1个附赠动作",
            range="60尺",
            components=SpellComponent(verbal=True),
            duration="立即",
            description="一个生物恢复1d4+你的施法属性调整值的生命值。",
            higher_level_effect="每升一环治疗伤害增加1d4。",
            classes=["吟游诗人", "牧师", "德鲁伊", "游侠"]
        ),
        "sleep": Spell(
            name="睡眠术",
            level=1,
            school="附魔",
            casting_time="1个动作",
            range="90尺",
            components=SpellComponent(verbal=True, somatic=True, material=True, material_description="一把细砂、花瓣或蟋蟀"),
            duration="1分钟",
            description="此法术使生物陷入魔法沉睡。投掷5d8；总数是你能影响的生命值上限。",
            is_concentration=True,
            classes=["吟游诗人", "法师", "术士"]
        ),
        "fire_bolt": Spell(
            name="火焰箭",
            level=0,
            school="塑能",
            casting_time="1个动作",
            range="120尺",
            components=SpellComponent(verbal=True, somatic=True),
            duration="立即",
            description="你对一个目标投掷一团火焰。造成1d10火焰伤害。",
            damage_type="火焰",
            attack_type="ranged",
            classes=["法师", "术士", "德鲁伊"]
        )
    }

    @classmethod
    def get_spell(cls, name: str) -> Optional[Spell]:
        """获取法术"""
        return cls.COMMON_SPELLS.get(name.lower())

    @classmethod
    def get_all_spells(cls) -> List[Spell]:
        """获取所有法术"""
        return list(cls.COMMON_SPELLS.values())

    @classmethod
    def get_spells_by_level(cls, level: int) -> List[Spell]:
        """按环阶获取法术"""
        return [s for s in cls.COMMON_SPELLS.values() if s.level == level]

    @classmethod
    def get_spells_by_school(cls, school: str) -> List[Spell]:
        """按学派获取法术"""
        return [s for s in cls.COMMON_SPELLS.values() if s.school == school]

    @classmethod
    def get_spells_by_class(cls, class_name: str) -> List[Spell]:
        """按职业获取法术"""
        return [s for s in cls.COMMON_SPELLS.values() if class_name in s.classes]

    @classmethod
    def get_cantrips(cls) -> List[Spell]:
        """获取所有戏法"""
        return [s for s in cls.COMMON_SPELLS.values() if s.level == 0]

    @classmethod
    def search_spells(cls, query: str) -> List[Spell]:
        """搜索法术"""
        query_lower = query.lower()
        return [
            s for s in cls.COMMON_SPELLS.values()
            if query_lower in s.name.lower() or query_lower in s.school.lower()
        ]


class SpellCaster:
    """施法者"""

    def __init__(self, spellcasting: Spellcasting):
        self.spellcasting = spellcasting

    def prepare_spell(self, spell: Spell):
        """准备法术"""
        if spell.name not in self.spellcasting.known_spells:
            raise ValueError(f"你不知道这个法术: {spell.name}")

        if spell.name not in self.spellcasting.prepared_spells:
            self.spellcasting.prepared_spells.append(spell.name)

    def unprepare_spell(self, spell: Spell):
        """取消准备"""
        if spell.name in self.spellcasting.prepared_spells:
            self.spellcasting.prepared_spells.remove(spell.name)

    def can_cast(self, spell: Spell) -> bool:
        """检查是否可以施放"""
        if spell.name not in self.spellcasting.prepared_spells:
            return False

        if spell.level == 0:
            return True

        return self.spellcasting.get_available_slots(spell.level) > 0

    def cast(self, spell: Spell) -> bool:
        """施放法术"""
        if not self.can_cast(spell):
            return False

        if spell.level > 0:
            self.spellcasting.use_spell_slot(spell.level)

        return True

    def get_spell_list_summary(self) -> str:
        """获取法术列表摘要"""
        lines = ["📖 **已知法术**:"]
        lines.append("\n🎯 **已准备**:")
        for spell_name in self.spellcasting.prepared_spells:
            spell = SpellDatabase.get_spell(spell_name)
            if spell:
                lines.append(f"  • {spell.name} ({spell.get_level_string()})")

        lines.append("\n🔮 **法术位**:")
        for level in range(1, 10):
            available = self.spellcasting.get_available_slots(level)
            total = self.spellcasting.spell_slots.get(level, 0)
            if total > 0:
                lines.append(f"  {level}环: {available}/{total}")

        return "\n".join(lines)
