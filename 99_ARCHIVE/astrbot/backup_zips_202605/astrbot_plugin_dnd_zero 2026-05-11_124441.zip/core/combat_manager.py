"""
D&D/Zero 战斗管理器
回合制战斗流程、行动解析、伤害计算
"""
import random
import uuid
from dataclasses import dataclass, field
from typing import List, Optional, Dict, Tuple, Any
from enum import Enum

from .combat_position import PositionManager, AttackRange, MELEE_RANGE, RANGED_RANGE, PIERCE_RANGE
from .combat_unit import CombatUnit, PlayerUnit, MonsterUnit, MONSTER_TEMPLATES, create_monster
from .combat_skill import Skill, SkillDatabase, SKILL_TEMPLATES


@dataclass
class DamageResult:
    """伤害结果"""
    base_damage: int
    rolls: List[int]
    modifier: int
    total: int
    is_critical: bool = False
    damage_type: str = "physical"

    def __str__(self) -> str:
        roll_str = "+".join(map(str, self.rolls))
        result = f"💥 伤害: [{roll_str}]"
        if self.modifier != 0:
            result += f" + {self.modifier}"
        result += f" = **{self.total}**"
        if self.is_critical:
            result += " (暴击!)"
        result += f" [{self.damage_type}]"
        return result


@dataclass
class AttackResult:
    """攻击结果"""
    attack_bonus: int
    roll: int
    total: int
    target_ac: int
    hit: bool = False
    critical_hit: bool = False
    critical_fumble: bool = False

    def __str__(self) -> str:
        result = f"⚔️ 攻击检定\n"
        result += f"━━━━━━━━━━━━━━━━━━━━\n"
        result += f"D20: **{self.roll}** + {self.attack_bonus} = **{self.total}**\n"
        result += f"目标AC: {self.target_ac}\n"
        result += f"━━━━━━━━━━━━━━━━━━━━\n"

        if self.critical_hit:
            result += "🎯 **暴击！自动命中！**"
        elif self.critical_fumble:
            result += "💀 **大失败！攻击失手！**"
        elif self.hit:
            result += "✅ **命中！**"
        else:
            result += "❌ **未命中！**"

        return result


@dataclass
class CombatActionResult:
    """行动结果"""
    success: bool
    action_name: str
    attacker: CombatUnit
    target: Optional[CombatUnit]
    attack_result: Optional[AttackResult] = None
    damage_result: Optional[DamageResult] = None
    heal_result: Optional[int] = None
    message: str = ""
    effects: List[str] = field(default_factory=list)


class CombatManager:
    """战斗管理器"""

    def __init__(self):
        self.combat_id: str = str(uuid.uuid4())[:8].upper()
        self.position_manager: PositionManager = PositionManager()

        self.ally_units: Dict[int, PlayerUnit] = {}
        self.enemy_units: Dict[int, MonsterUnit] = {}

        self.initiative_order: List[CombatUnit] = []
        self.current_turn_index: int = 0
        self.round_number: int = 1

        self.turn_start_time: float = 0
        self.turn_time_limit: int = 90

        self.combat_state: str = "waiting"
        self.short_rest_available: int = 1
        self.long_rest_available: bool = False
        self.encounters_since_rest: int = 0

        self.turn_log: List[Dict] = []

    def roll_d20(self, bonus: int = 0, advantage: bool = False,
                  disadvantage: bool = False) -> Tuple[int, bool, bool]:
        """投D20"""
        rolls = [random.randint(1, 20), random.randint(1, 20)]

        if advantage and not disadvantage:
            roll = max(rolls)
        elif disadvantage and not advantage:
            roll = min(rolls)
        else:
            roll = rolls[0]

        is_critical = (roll == 20)
        is_fumble = (roll == 1)

        return roll + bonus, is_critical, is_fumble

    def roll_damage(self, damage_dice: str, is_critical: bool = False) -> DamageResult:
        """投伤害骰"""
        import re

        total = 0
        rolls = []
        modifier = 0

        parts = damage_dice.replace("+", " ").replace("-", " -").split()
        for part in parts:
            if 'd' in part:
                match = re.match(r'(\d+)d(\d+)', part)
                if match:
                    count = int(match.group(1))
                    sides = int(match.group(2))
                    for _ in range(count):
                        r = random.randint(1, sides)
                        rolls.append(r)
                        total += r
                    if is_critical:
                        for _ in range(count):
                            r = random.randint(1, sides)
                            rolls.append(r)
                            total += r
            else:
                try:
                    modifier += int(part)
                except ValueError:
                    pass

        return DamageResult(
            base_damage=total,
            rolls=rolls,
            modifier=modifier,
            total=total + modifier,
            is_critical=is_critical
        )

    async def start_combat(self, party: List[PlayerUnit],
                          enemies: List[MonsterUnit]) -> str:
        """开启战斗"""
        self.combat_state = "initiative"

        self._assign_positions(party, enemies)
        await self._roll_initiative()

        self.combat_state = "active"
        self.turn_start_time = 0

        return self._generate_combat_start_text()

    def _assign_positions(self, party: List[PlayerUnit],
                         enemies: List[MonsterUnit]):
        """分配站位"""
        tank_classes = ["战士", "野蛮人", "圣武士"]
        support_classes = ["牧师", "德鲁伊", "吟游诗人"]

        sorted_party = []
        tanks = [p for p in party if p.class_name in tank_classes]
        supports = [p for p in party if p.class_name in support_classes]
        others = [p for p in party if p not in tanks + supports]

        sorted_party = tanks + others + supports

        for i, unit in enumerate(sorted_party):
            unit.position = i + 1
            unit.original_position = i + 1
            self.ally_units[i + 1] = unit
            self.position_manager.assign_position(unit, i + 1, is_ally=True)

        sorted_enemies = sorted(enemies, key=lambda x: x.cr, reverse=True)
        for i, unit in enumerate(sorted_enemies):
            unit.position = i + 1
            unit.original_position = i + 1
            self.enemy_units[i + 1] = unit
            self.position_manager.assign_position(unit, i + 1, is_ally=False)

    async def _roll_initiative(self):
        """自动先攻排序"""
        all_units = list(self.ally_units.values()) + list(self.enemy_units.values())

        for unit in all_units:
            dex_mod = unit.get_modifier("dexterity")
            roll, _, _ = self.roll_d20(0)
            unit.initiative = roll + dex_mod

        self.initiative_order = sorted(
            all_units,
            key=lambda x: (x.initiative, x.get_modifier("dexterity")),
            reverse=True
        )

    async def process_player_action(self, player_id: str, action: str,
                                   params: Dict) -> str:
        """处理玩家动作"""
        current_unit = self.get_current_unit()

        if not current_unit or current_unit.unit_type != "player":
            return "❌ 当前不是玩家回合"

        if current_unit.player_id != player_id:
            return "❌ 这不是你的回合"

        if action == "attack":
            return await self._execute_attack(current_unit, params)
        elif action == "skill":
            return await self._execute_skill(current_unit, params)
        elif action == "swap":
            return await self._execute_swap(current_unit, params)
        elif action == "defend":
            return await self._execute_defend(current_unit)
        elif action == "dodge":
            return await self._execute_dodge(current_unit)
        elif action == "skip":
            return await self._skip_turn(current_unit)
        elif action == "item":
            return await self._use_item(current_unit, params)
        else:
            return f"❌ 未知动作: {action}"

    async def _execute_attack(self, attacker: CombatUnit, params: Dict) -> str:
        """执行普通攻击"""
        target_pos = params.get("target_position", 1)
        skill_id = params.get("skill_id", attacker.default_weapon if hasattr(attacker, 'default_weapon') else "sword_attack")

        alive_count = len(self.position_manager.get_alive_units(is_ally=False))

        if attacker.unit_type == "player":
            skill = SkillDatabase.get_skill(skill_id)
        else:
            skill = SkillDatabase.get_skill("sword_attack")

        if not skill:
            return f"❌ 未知技能: {skill_id}"

        can_use, error_msg = skill.can_use(attacker, target_pos, alive_count)
        if not can_use:
            return f"❌ {error_msg}"

        target = self.position_manager.get_unit_at_combat_position(target_pos, is_ally=False)

        if not target:
            return "❌ 目标不存在"

        attack_bonus = attacker.attack_bonus
        if hasattr(attacker, 'get_modifier'):
            attack_bonus += attacker.get_modifier("strength")

        attack_roll, is_crit, is_fumble = self.roll_d20(attack_bonus)
        target_ac = target.get_effective_ac()

        hit = is_crit or (not is_fumble and attack_roll >= target_ac)

        result = CombatActionResult(
            success=True,
            action_name=skill.name_cn,
            attacker=attacker,
            target=target,
            attack_result=AttackResult(
                attack_bonus=attack_bonus,
                roll=attack_roll,
                total=attack_roll,
                target_ac=target_ac,
                hit=hit,
                critical_hit=is_crit,
                critical_fumble=is_fumble
            )
        )

        if hit:
            damage_result = self.roll_damage(skill.damage, is_crit)

            if "str" in skill.damage.lower():
                damage_result.total += attacker.get_modifier("strength")
                damage_result.modifier = attacker.get_modifier("strength")

            target.take_damage(damage_result.total)
            result.damage_result = damage_result

            if target.is_unconscious:
                result.effects.append(f"💀 {target.name} 陷入昏迷！")

        attacker.action_used = True

        return self._format_action_result(result)

    async def _execute_skill(self, attacker: CombatUnit, params: Dict) -> str:
        """执行技能"""
        skill_id = params.get("skill_id")
        target_pos = params.get("target_position", 1)

        skill = SkillDatabase.get_skill(skill_id)
        if not skill:
            return f"❌ 未知技能: {skill_id}"

        alive_count = len(self.position_manager.get_alive_units(
            is_ally=skill.target_ally))

        can_use, error_msg = skill.can_use(attacker, target_pos, alive_count)
        if not can_use:
            return f"❌ {error_msg}"

        if skill.action_type == "action" and attacker.action_used:
            return "❌ 标准动作已使用"
        if skill.action_type == "bonus_action" and attacker.bonus_action_used:
            return "❌ 附赠动作已使用"

        if skill.skill_type == "heal":
            return await self._execute_heal(attacker, skill, target_pos)
        elif skill.skill_type == "attack":
            return await self._execute_spell_attack(attacker, skill, target_pos)
        elif skill.skill_type == "effect":
            return await self._execute_effect(attacker, skill, target_pos)

        return "❌ 未实现的技能类型"

    async def _execute_heal(self, caster: CombatUnit, skill: Skill,
                          target_pos: int) -> str:
        """执行治疗"""
        target = self.position_manager.get_unit_at_combat_position(
            target_pos, is_ally=True)

        if not target:
            return "❌ 治疗目标不存在"

        heal_roll = self.roll_damage(skill.heal)
        target.heal(heal_roll.total)

        result = CombatActionResult(
            success=True,
            action_name=skill.name_cn,
            attacker=caster,
            target=target,
            heal_result=heal_roll.total
        )

        if skill.action_type == "bonus_action":
            caster.bonus_action_used = True
        else:
            caster.action_used = True

        return f"✨ **{caster.name}** 对 **{target.name}** 施放 **{skill.name_cn}**！\n" \
               f"💚 治疗: {heal_roll.total} HP\n" \
               f"❤️ {target.name} 当前HP: {target.current_hp}/{target.max_hp}"

    async def _execute_spell_attack(self, caster: CombatUnit, skill: Skill,
                                   target_pos: int) -> str:
        """执行法术攻击"""
        target = self.position_manager.get_unit_at_combat_position(
            target_pos, is_ally=False)

        if not target:
            return "❌ 目标不存在"

        attack_bonus = caster.attack_bonus + caster.get_modifier("intelligence")

        if skill.requires_attack:
            attack_roll, is_crit, is_fumble = self.roll_d20(attack_bonus)
            target_ac = target.get_effective_ac()
            hit = is_crit or (not is_fumble and attack_roll >= target_ac)
        else:
            target_save = random.randint(1, 20) + target.get_modifier(skill.spell_save_ability)
            dc = skill.spell_save_dc
            hit = target_save < dc
            is_crit = False
            is_fumble = False
            attack_roll = target_save

        result = CombatActionResult(
            success=True,
            action_name=skill.name_cn,
            attacker=caster,
            target=target,
            attack_result=AttackResult(
                attack_bonus=attack_bonus if skill.requires_attack else 0,
                roll=attack_roll,
                total=attack_roll,
                target_ac=target.get_effective_ac() if skill.requires_attack else skill.spell_save_dc,
                hit=hit,
                critical_hit=is_crit,
                critical_fumble=is_fumble
            )
        )

        if hit:
            damage_result = self.roll_damage(skill.damage, is_crit)

            if not skill.requires_attack and skill.half_damage_on_save:
                target_save = random.randint(1, 20) + target.get_modifier(skill.spell_save_ability)
                if target_save >= skill.spell_save_dc:
                    damage_result.total //= 2

            target.take_damage(damage_result.total)
            damage_result.damage_type = skill.damage_type
            result.damage_result = damage_result

        caster.action_used = True

        return self._format_action_result(result)

    async def _execute_effect(self, caster: CombatUnit, skill: Skill,
                           target_pos: int) -> str:
        """执行效果技能"""
        if skill.effect == "taunt_all":
            for pos, enemy in self.enemy_units.items():
                if enemy and not enemy.is_dead and not enemy.is_unconscious:
                    enemy.is_taunted = True
                    enemy.taunt_source = caster.unit_id

            caster.action_used = True

            return f"🛡️ **{caster.name}** 发动 **嘲讽**！\n" \
                   f"所有敌人被迫攻击 {caster.name}！"

        elif skill.effect == "pull":
            target = self.position_manager.get_unit_at_combat_position(
                target_pos, is_ally=False)

            if target:
                success, msg = self.position_manager.force_position_change(target, 3)
                caster.action_used = True

                if success:
                    return f"⚡ **{caster.name}** 发动 **拖拽**！\n{msg}"
                else:
                    return f"❌ 拖拽失败"

        return "❌ 未实现的效果"

    async def _execute_swap(self, unit: CombatUnit, params: Dict) -> str:
        """执行换位"""
        new_position = params.get("new_position", 2)

        if unit.is_dead or unit.is_unconscious:
            return "❌ 无法移动"

        if unit.movement_used:
            return "❌ 本回合已使用移动"

        success = self.position_manager.swap_positions(unit, new_position)

        if success:
            unit.movement_used = True

            occupant = self.position_manager.get_unit_at(new_position, unit.unit_type == "player")
            if occupant:
                return f"🔄 **{unit.name}** 与 **{occupant.name}** 交换位置到 {new_position}号位"
            else:
                return f"🔄 **{unit.name}** 移动到 {new_position}号位"
        else:
            return "❌ 换位失败"

    async def _execute_defend(self, unit: CombatUnit) -> str:
        """执行防御"""
        unit.action_used = True
        unit.defending = True
        unit.temp_ac_bonus = 2

        return f"🛡️ **{unit.name}** 进入防御姿态！\n" \
               f"AC +2，直到下回合开始"

    async def _execute_dodge(self, unit: CombatUnit) -> str:
        """执行躲避"""
        unit.action_used = True
        unit.dodging = True
        unit.dex_saves_advantage = True

        return f"💨 **{unit.name}** 专注闪避！\n" \
               f"敏捷豁免获得优势，攻击者攻击劣势"

    async def _skip_turn(self, unit: CombatUnit) -> str:
        """跳过回合"""
        self._next_turn()
        return f"⏭️ **{unit.name}** 跳过回合"

    async def _use_item(self, unit: CombatUnit, params: Dict) -> str:
        """使用物品"""
        item_name = params.get("item_name", "")

        if "血瓶" in item_name or "治疗" in item_name:
            heal_dice = "1d4+1"
            heal = self.roll_damage(heal_dice)
            unit.heal(heal.total)

            unit.action_used = True

            return f"💊 **{unit.name}** 使用 **{item_name}**！\n" \
                   f"💚 恢复 {heal.total} HP\n" \
                   f"❤️ 当前HP: {unit.current_hp}/{unit.max_hp}"

        return f"❌ 未知物品: {item_name}"

    async def process_monster_turn(self) -> str:
        """处理怪物回合"""
        current_unit = self.get_current_unit()

        if not current_unit or current_unit.unit_type != "monster":
            return ""

        action, target = current_unit.decide_action(
            self.position_manager.get_alive_units(is_ally=True))

        if action == "attack" and target:
            params = {
                "skill_id": "sword_attack",
                "target_position": self.position_manager.get_combat_position(
                    target.position, is_ally=True)
            }
            return await self._execute_attack(current_unit, params)

        self._next_turn()
        return f"⏭️ **{current_unit.name}** 结束回合"

    def get_current_unit(self) -> Optional[CombatUnit]:
        """获取当前回合单位"""
        if self.initiative_order and 0 <= self.current_turn_index < len(self.initiative_order):
            return self.initiative_order[self.current_turn_index]
        return None

    def _next_turn(self):
        """进入下一回合"""
        current_unit = self.get_current_unit()

        if current_unit:
            current_unit.reset_turn()

            if current_unit.is_unconscious:
                success, msg, saves = current_unit.roll_death_save()
                self.turn_log.append({
                    "type": "death_save",
                    "unit": current_unit.name,
                    "result": saves
                })

        self.current_turn_index += 1

        if self.current_turn_index >= len(self.initiative_order):
            self.current_turn_index = 0
            self.round_number += 1

            for unit in self.initiative_order:
                if unit.concentration_spell:
                    unit.concentration_duration -= 1
                    if unit.concentration_duration <= 0:
                        unit.concentration_spell = None

    def _check_combat_end(self) -> bool:
        """检查战斗是否结束"""
        ally_alive = any(not u.is_dead for u in self.ally_units.values())
        enemy_alive = any(not u.is_dead for u in self.enemy_units.values())

        return not ally_alive or not enemy_alive

    def _format_action_result(self, result: CombatActionResult) -> str:
        """格式化行动结果"""
        text = f"⚔️ **{result.attacker.name}** 使用 **{result.action_name}**"

        if result.target:
            text += f" 攻击 **{result.target.name}**\n"

            if result.attack_result:
                text += f"\n{str(result.attack_result)}"

            if result.damage_result:
                text += f"\n{str(result.damage_result)}"
                text += f"\n💔 {result.target.name} 剩余HP: {result.target.current_hp}/{result.target.max_hp}"

            for effect in result.effects:
                text += f"\n{effect}"
        else:
            text += f"\n{result.message}"

        return text

    def _generate_combat_start_text(self) -> str:
        """生成战斗开始文本"""
        text = "⚔️ **战斗开始！** ⚔️\n"
        text += "━━━━━━━━━━━━━━━━━━━━\n\n"

        text += "【我方】\n"
        for pos in [1, 2, 3, 4]:
            unit = self.ally_units.get(pos)
            if unit and not unit.is_dead:
                text += f"  {pos}号位 🛡️ {unit.name} HP: {unit.current_hp}/{unit.max_hp}\n"

        text += "\n【敌方】\n"
        for pos in [1, 2, 3, 4]:
            unit = self.enemy_units.get(pos)
            if unit and not unit.is_dead:
                text += f"  {pos}号位 ⚔️ {unit.name} HP: {unit.current_hp}/{unit.max_hp}\n"

        text += "\n【先攻顺序】\n"
        for i, unit in enumerate(self.initiative_order):
            status = "💀" if unit.is_dead else ("😵" if unit.is_unconscious else "⚔️")
            marker = "→" if i == self.current_turn_index else " "
            text += f"  {marker} {i+1}. {status} {unit.name}\n"

        return text

    def get_battlefield_display(self) -> str:
        """获取战场显示"""
        text = "⚔️ **战斗状态**\n"
        text += "━━━━━━━━━━━━━━━━━━━━\n\n"

        text += "【我方】\n"
        for pos in [1, 2, 3, 4]:
            unit = self.ally_units.get(pos)
            if unit and not unit.is_dead:
                hp_bar = self._generate_hp_bar(unit.current_hp, unit.max_hp)
                status = "💀" if unit.is_dead else ("😵" if unit.is_unconscious else "🛡️")
                text += f"  {pos}号位 {status} {unit.name} {hp_bar}\n"
            else:
                text += f"  {pos}号位 [空]\n"

        text += "\n【敌方】\n"
        for pos in [1, 2, 3, 4]:
            unit = self.enemy_units.get(pos)
            if unit and not unit.is_dead:
                hp_bar = self._generate_hp_bar(unit.current_hp, unit.max_hp)
                status = "💀" if unit.is_dead else ("😵" if unit.is_unconscious else "⚔️")
                text += f"  {pos}号位 {status} {unit.name} {hp_bar}\n"
            else:
                text += f"  {pos}号位 [空]\n"

        current = self.get_current_unit()
        if current:
            text += f"\n**当前回合**: {current.name}\n"
            text += f"**回合数**: 第{self.round_number}轮\n"

        return text

    @staticmethod
    def _generate_hp_bar(current: int, maximum: int, length: int = 10) -> str:
        """生成HP条"""
        if maximum <= 0:
            return "[-----------]"

        ratio = current / maximum
        filled = int(ratio * length)
        empty = length - filled

        if ratio > 0.6:
            color = "🟢"
        elif ratio > 0.3:
            color = "🟡"
        else:
            color = "🔴"

        return f"{color}[{'█' * filled}{'░' * empty}] {current}/{maximum}"

    def get_action_menu(self, unit: CombatUnit) -> str:
        """获取动作菜单"""
        text = f"📋 **{unit.name}** - 选择动作\n"
        text += "━━━━━━━━━━━━━━━━━━━━\n\n"

        if not unit.action_used:
            text += "📌 **标准动作**:\n"
            text += "  1️⃣ 攻击 [attack]\n"
            text += "  2️⃣ 技能 [skill]\n"
            text += "  3️⃣ 换位 [swap]\n"
            text += "  4️⃣ 防御 [defend]\n"
            text += "  5️⃣ 躲避 [dodge]\n"
            text += "  6️⃣ 使用物品 [item]\n\n"
        else:
            text += "📌 标准动作已使用\n\n"

        if not unit.bonus_action_used:
            text += "⚡ **附赠动作**:\n"
            text += "  7️⃣ 治疗 [heal]\n"
            text += "  8️⃣ 副手攻击 [offhand]\n\n"
        else:
            text += "⚡ 附赠动作已使用\n\n"

        if unit.reaction_available:
            text += "🔄 **反应** 可用\n\n"
        else:
            text += "🔄 反应已使用\n\n"

        text += "⏭️ 跳过回合 [skip]\n"

        return text
