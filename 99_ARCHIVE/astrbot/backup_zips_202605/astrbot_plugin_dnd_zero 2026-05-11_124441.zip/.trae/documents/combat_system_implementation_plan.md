# D&D/Zero 战斗系统 v0.4.0 实现计划

> **计划制定日期**: 2026-05-10
> **开发者**: MagicalYu
> **目标版本**: v0.4.0
> **文档版本**: v1.0

---

## 一、需求确认总结

### 1.1 核心设计决策

| 决策项 | 用户选择 | 说明 |
|--------|----------|------|
| **参战人数** | 1-4人弹性 | 支持单人/组队混合冒险 |
| **先攻机制** | 系统自动处理 | 开战后自动排序，无需玩家手动 |
| **怪物行动** | 代码AI+LLM混合 | 怪物不由玩家控制，自动决策 |
| **战斗文本** | 预设+关键LLM | 预设格式+关键场景LLM增强 |
| **休息机制** | 短休+长休 | 副本内支持短休长休 |
| **借机攻击** | 双方都有 | 玩家和敌人都有机会触发 |
| **仇恨机制** | 站位自动仇恨 | 前排自动吸引近战 |
| **战斗节奏** | 时间限制 | 每回合有倒计时 |
| **动作系统** | 职业化简化 | 适配简化但保留职业特色 |
| **倒地处理** | D&D昏迷+死亡豁免 | 经典D&D规则 |
| **怪物AI** | 怪物职业化 | 每种怪物有预设行为脚本 |
| **LLM接口** | 自定义API Key | 插件内调用外部LLM |

### 1.2 成功标准

- 玩家可以通过 `/dnd 战斗开始` 开启一场完整战斗
- 4号位线性站位系统正确运行（4321 vs 1234）
- 攻击范围绑定于**技能/武器**而非职业：
  - 近战武器/技能只能攻击敌方 1-2号位
  - 远程武器可攻击敌方 1-4号位
  - 法术可攻击敌方 1-4号位
  - 突进技能可攻击敌方 3-4号位
- 特殊技能（如战士冲锋、法师闪现）可以突破职业限制攻击远程位置
- 站位战术动作（换位、前压、后撤）正常工作
- 借机攻击在适当条件触发
- 倒地角色进入昏迷状态，死亡豁免生效
- 短休/长休系统正确恢复资源
- 怪物AI按预设行为脚本行动
- 预设战斗文本+关键场景LLM增强
- 单人模式自动适配（可用预设NPC队友）

---

## 二、整体战斗架构设计

### 2.1 战斗状态机

```
┌─────────────────────────────────────────────────────────────────┐
│                        战斗状态机                                │
└─────────────────────────────────────────────────────────────────┘

    ┌──────────┐    发起战斗    ┌──────────┐    全部倒下    ┌──────────┐
    │          │ ─────────────→ │          │ ────────────→ │          │
    │  等待    │                │ 先攻排序  │                │  战斗中  │
    │  开始    │ ←───────────── │  阶段    │ ←─────────── │  进行    │
    │          │   取消/退出     │          │   回合结束    │          │
    └──────────┘                └──────────┘                └──────────┘
                                                                    ↓
    ┌──────────┐    短休请求    ┌──────────┐    长休请求    ┌──────────┐
    │          │ ─────────────→ │          │ ────────────→ │          │
    │  结束    │                │  休整    │                │  恢复    │
    │          │ ←───────────── │  阶段    │ ←─────────── │  阶段    │
    │          │   继续战斗      │          │   继续战斗    │          │
    └──────────┘                └──────────┘                └──────────┘
```

### 2.2 战斗层级架构

```
┌─────────────────────────────────────────────────────────────────┐
│                    战斗系统层级架构                               │
├─────────────────────────────────────────────────────────────────┤
│  【第四层】战斗表现层                                            │
│  • 战斗文本生成（预设模板 + LLM增强）                           │
│  • 战斗状态显示（站位图、HP条、状态图标）                       │
│  • 回合提示与倒计时                                             │
├─────────────────────────────────────────────────────────────────┤
│  【第三层】战斗逻辑层                                            │
│  • CombatManager - 战斗管理器                                   │
│  • InitiativeSystem - 先攻排序系统                               │
│  • TurnSystem - 回合控制系统                                     │
│  • RestSystem - 休息系统（短休/长休）                           │
├─────────────────────────────────────────────────────────────────┤
│  【第二层】战斗实体层                                            │
│  • CombatUnit - 战斗单位基类                                     │
│  • PlayerUnit - 玩家单位（角色卡）                               │
│  • MonsterUnit - 怪物单位                                       │
│  • PositionManager - 站位管理器                                 │
│  • ActionResolver - 行动解析器                                  │
├─────────────────────────────────────────────────────────────────┤
│  【第一层】D&D规则层                                            │
│  • AbilityCalculator - 属性计算                                  │
│  • DamageCalculator - 伤害计算                                   │
│  • SpellSystem - 法术系统                                       │
│  • ConditionSystem - 状态效果系统                               │
└─────────────────────────────────────────────────────────────────┘
```

### 2.3 4号位线性站位机制

**核心设计**：
```
┌─────────────────────────────────────────────────────────────────┐
│                    4号位线性站位示意图                           │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│   【我方阵营】           │          【敌方阵营】                 │
│                          │                                      │
│      [4号位] 后排辅助     │     [4号位] 后排辅助                  │
│         ↑                │         ↑                            │
│      [3号位] 中排输出     │     [3号位] 中排输出                  │
│         ↑                │         ↑                            │
│      [2号位] 中排战士     │     [2号位] 中排战士                  │
│         ↑                │         ↑                            │
│      [1号位] 前排坦克     │     [1号位] 前排坦克                  │
│                          │                                      │
│   4321 (从后往前)        │      1234 (从前往后)                  │
│                          │                                      │
└─────────────────────────────────────────────────────────────────┘
```

**空位处理规则（简化版 - 存活单位压缩）**：

```
┌─────────────────────────────────────────────────────────────────┐
│              简化版空位处理：存活单位压缩                         │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  【核心原则】                                                   │
│  • 死亡单位的位置永久保留（仅用于复活判定）                       │
│  • 战斗攻击时，只考虑存活单位的位置                               │
│  • 存活的敌人自动「压缩」为1、2、3、4号位                        │
│  • 近战攻击始终只能攻击「前两个存活敌人」                         │
│                                                                  │
│  【简化逻辑示例】                                               │
│                                                                  │
│  情况1：敌人3、4号位死亡                                        │
│    → 只有1、2号位敌人存活                                        │
│    → 近战攻击 → 只能选择攻击1号位或2号位                        │
│    → 3、4号位视为不存在（因为没有存活敌人）                       │
│                                                                  │
│  情况2：我方只剩4号位法师存活                                    │
│    → 敌人近战攻击 → 法师被视为「1号位」                          │
│    → 近战敌人可以攻击法师                                       │
│                                                                  │
│  情况3：敌人只剩4号位敌人存活                                    │
│    → 近战攻击 → 4号位敌人被视为「1号位」                        │
│    → 近战敌人可以攻击（因为是唯一存活的敌人）                     │
│                                                                  │
│  情况4：复活机制                                                │
│    → 战士在1号位死亡 → 位置1被「战士尸体」占据                   │
│    → 牧师使用复活术 → 战士回到位置1（需要目标位置为空）          │
│    → 如果位置1已被其他存活角色占据 → 复活失败或需先换位          │
│                                                                  │
│  【UI显示简化】                                                 │
│    → 战斗界面只显示存活的单位                                    │
│    → 死亡的单位不显示在站位图中                                  │
│    → 但系统内部保留死亡单位的原始位置记录                         │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

**站位限制技能（新增战术机制）**：

```
┌─────────────────────────────────────────────────────────────────┐
│                  站位限制技能机制                                 │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  【核心概念】                                                   │
│  • 某些技能要求使用者必须站在特定位置才能使用                     │
│  • 这是额外的战术限制，增加策略深度                              │
│  • 敌人也可以拥有站位限制技能，形成博弈                          │
│                                                                  │
│  【示例：职业站位限制】                                         │
│                                                                  │
│  战士系站位限制：                                               │
│  • 嘲讽 → 必须站在1号位，否则无法使用                           │
│  • 盾牌格挡 → 必须站在1号位或2号位，否则无法使用                 │
│  • 破甲攻击 → 必须站在1号位，获得额外伤害                       │
│                                                                  │
│  法师系站位限制：                                               │
│  • 奥术飞弹（强化版）→ 必须站在4号位，增加伤害/次数            │
│  • 防护罩 → 必须站在4号位，为全队提供护盾                      │
│  • 闪现术 → 可以从任意位置使用，但站在4号位时额外获得位移       │
│                                                                  │
│  【敌人拉人技能示例】                                           │
│                                                                  │
│  敌人「拖拽」技能：                                            │
│  • 敌人使用拖拽技能，目标是我方4号位                            │
│  • 如果4号位是法师 → 法师被拉到3号位（如果3号位为空）          │
│  • 如果3号位有角色 → 法师和3号位角色互换位置                    │
│  • 效果：法师被强制离开4号位，无法使用4号位专属技能              │
│                                                                  │
│  战术考量：                                                     │
│  • 队伍需要保护关键位置的角色                                   │
│  • 前排需要阻止敌人接近后排                                     │
│  • 可以用「换位」技能让角色回到理想位置                         │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

**位置状态枚举**：
| 状态 | 说明 | 战斗攻击 |
|------|------|----------|
| 存活 | 有敌人/友方单位 | 正常攻击，视为对应号位 |
| 死亡 | 尸体占位，仅用于复活 | 不参与战斗，不显示在站位图 |
| 空位 | 从未有人 | 不参与战斗 |

**攻击范围规则**（数值简化版）：

| 攻击手段类型 | 范围参数 | 说明 | 示例 |
|-------------|---------|------|------|
| 近战武器攻击 | max=2, min=1 | 只能攻击前2个存活单位 | 剑、斧、徒手 |
| 远程武器攻击 | max=4, min=1 | 只能攻击前4个存活单位 | 弓、弩、投掷武器 |
| 法术攻击 | max=4, min=1 | 只能攻击前4个存活单位 | 所有法术 |
| 突进技能 | max=2, min=3 | 攻击第3、4个存活单位 | 战士冲锋、法师闪现 |

**核心设计**：
1. `max_position`: 最大可攻击位置数（基于存活单位）
2. `min_position`: 最小起始位置（用于突进等技能）

**示例**：
- 近战武器：max=2, min=1 → 攻击存活单位[1, 2]
- 远程武器：max=4, min=1 → 攻击存活单位[1, 2, 3, 4]
- 突进技能：max=2, min=3 → 攻击存活单位[3, 4]
- 如果只有2个存活单位，突进技能无法使用（因为需要3、4号位）

**设计理念**：
1. 攻击范围绑定于**技能/武器本身**，而非角色职业
2. 站位限制绑定于**特定技能**，提供战术深度
3. 敌人可以通过技能改变我方站位，增加挑战性、法师闪现 |
| 嘲讽效果 | 强制敌人攻击前排 | 战士嘲讽 |

**设计理念**：攻击范围绑定于**技能/武器本身**，而非角色职业。战士可以用近战攻击前排，也可以学习/获得远程技能攻击后排。

---

## 三、参战角色/怪物标准化数据结构

### 3.1 CombatUnit 基类

```python
@dataclass
class CombatUnit:
    """战斗单位基类"""
    unit_id: str
    name: str
    unit_type: str  # "player" | "monster"

    # 站位属性
    position: int = 1  # 当前位置（1-4号位）
    original_position: int = 1  # 原始站位（用于复活）
    is_original_position: bool = True  # 是否在原始位置

    # 核心战斗属性
    max_hp: int
    current_hp: int
    temp_hp: int = 0
    armor_class: int = 10
    speed: int = 30

    # D&D核心属性
    proficiency_bonus: int = 2
    abilities: AbilityScores

    # 攻击属性
    attack_bonus: int = 0
    damage_bonus: int = 0
    weapon_damage: str = "1d6"  # 默认徒手

    # 职业/怪物类型
    class_name: str = ""
    level: int = 1

    # 动作资源
    action_used: bool = False
    bonus_action_used: bool = False
    reaction_available: bool = True
    movement_used: bool = False

    # 法术资源
    spell_slots: Dict[int, int] = field(default_factory=dict)  # {环阶: 剩余数量}
    prepared_spells: List[str] = field(default_factory=list)

    # 状态效果
    conditions: List[str] = field(default_factory=list)  # ["眩晕", "中毒"]
    concentration_spell: Optional[str] = None

    # 死亡豁免
    death_saves: Dict[str, int] = field(default_factory=lambda: {"success": 0, "fail": 0})
    is_unconscious: bool = False
    is_dead: bool = False

    # 位置锁定（被嘲讽）
    is_taunted: bool = False
    taunt_source: Optional[str] = None

    def get_position_status(self) -> str:
        """获取位置状态"""
        if self.is_dead:
            return "dead"
        elif self.is_unconscious:
            return "unconscious"
        else:
            return "alive"

    def revive_at_original_position(self) -> bool:
        """在原始位置复活（用于复活术）

        Returns:
            bool: 是否可以复活到原始位置
        """
        if not self.is_dead:
            return False

        # 复活时回到原始位置
        self.position = self.original_position
        self.is_original_position = True
        self.is_dead = False
        self.is_unconscious = False
        self.current_hp = 1  # 复活后1HP
        self.death_saves = {"success": 0, "fail": 0}

        return True

    def swap_to_position(self, new_position: int) -> bool:
        """换到新位置

        Args:
            new_position: 新位置（1-4）

        Returns:
            bool: 是否成功换位
        """
        if new_position not in [1, 2, 3, 4]:
            return False

        old_position = self.position
        self.position = new_position
        self.is_original_position = (new_position == self.original_position)

        return True
```

### 3.2 PlayerUnit 玩家单位

```python
@dataclass
class PlayerUnit(CombatUnit):
    """玩家战斗单位"""
    unit_type: str = "player"
    player_id: str
    player_name: str
    character: Character  # 引用角色卡数据

    # 职业特性
    class_features: List[str] = field(default_factory=list)
    racial_traits: List[str] = field(default_factory=list)

    # 熟练加值
    saving_throws: Dict[str, bool] = field(default_factory=dict)  # {属性: 是否熟练}
    skill_proficiencies: List[str] = field(default_factory=list)

    # 装备加成
    equipment_bonus: Dict[str, int] = field(default_factory=dict)
```

### 3.3 MonsterUnit 怪物单位

```python
@dataclass
class MonsterUnit(CombatUnit):
    """怪物战斗单位"""
    unit_type: str = "monster"

    # 怪物类型（职业化）
    monster_role: str = "warrior"  # warrior | ranger | mage | support | elite | boss
    cr: int = 1  # 挑战等级

    # 行为脚本
    behavior_script: str = "aggressive"  # aggressive | defensive | supportive | boss
    target_priority: List[str] = field(default_factory=list)  # ["front_row", "low_hp", "squishy"]

    # 特殊能力
    special_abilities: List[str] = field(default_factory=list)
    legendary_actions: int = 0

    # 掉落奖励
    xp_reward: int = 0
    loot_table: List[Dict] = field(default_factory=list)

    # 攻击模式
    melee_attack: bool = True
    ranged_attack: bool = False
    spellcasting: bool = False
    spell_list: List[str] = field(default_factory=list)
```

### 3.4 战斗系统常量定义

```python
class ActionType(Enum):
    """动作类型"""
    STANDARD_ACTION = "action"      # 标准动作
    BONUS_ACTION = "bonus_action"   # 附赠动作
    REACTION = "reaction"           # 反应
    FREE_ACTION = "free_action"    # 自由动作
    MOVEMENT = "movement"           # 移动

class ConditionType(Enum):
    """状态效果类型"""
    BLINDED = "目盲"
    CHARMED = "魅惑"
    DEAFENED = "耳聋"
    FRIGHTENED = "恐惧"
    GRAPPLED = "擒抱"
    INCAPACITATED = "虚弱"
    INVISIBLE = "隐形"
    PARALYZED = "麻痹"
    PETRIFIED = "石化"
    POISONED = "中毒"
    PRONE = "倒地"
    RESTRAINED = "束缚"
    STUNNED = "震慑"
    UNCONSCIOUS = "昏迷"
    EXHAUSTION = "力竭"

# ============================================================
# 攻击范围系统（最终简化版）
# ============================================================

class AttackRange:
    """攻击范围（极简数值版）

    核心设计：只用两个数值定义攻击范围
    - range: 可攻击的位置数量
    - start: 从第几个位置开始（可选，默认1）

    判定逻辑：
        可攻击位置 = [start, start+1, ..., start+range-1]

    示例：
        普通攻击: range=2, start=1 → 可攻击 [1, 2]
        远程攻击: range=4, start=1 → 可攻击 [1, 2, 3, 4]
        突进斩: range=2, start=3 → 可攻击 [3, 4]
    """
    def __init__(self, range: int = 2, start: int = 1):
        self.range = range      # 可攻击位置数量
        self.start = start      # 起始位置

    def can_attack(self, combat_position: int, alive_count: int) -> bool:
        """判断是否可以攻击指定战斗位置

        Args:
            combat_position: 战斗位置（1-4）
            alive_count: 存活单位总数

        Returns:
            bool: 是否可以攻击
        """
        if combat_position > alive_count:
            return False

        return self.start <= combat_position <= self.start + self.range - 1

    def get_attackable_positions(self, alive_count: int) -> List[int]:
        """获取所有可攻击的战斗位置

        Args:
            alive_count: 存活单位总数

        Returns:
            List[int]: 可攻击的位置列表
        """
        positions = []
        end_pos = min(self.start + self.range - 1, alive_count)

        for pos in range(self.start, end_pos + 1):
            positions.append(pos)

        return positions

    def __repr__(self):
        return f"AttackRange(range={self.range}, start={self.start})"

# 预设攻击范围常量
MELEE_RANGE = AttackRange(range=2, start=1)      # 近战：前2个
RANGED_RANGE = AttackRange(range=4, start=1)     # 远程：全部
PIERCE_RANGE = AttackRange(range=2, start=3)     # 突进：后排2个
```

```python
# 技能定义示例（JSON格式）
SKILL_TEMPLATES = {
    "sword_attack": {
        "name": "普通攻击",
        "name_cn": "挥剑攻击",
        "range": 2,          # 攻击范围：前2个
        "start": 1,           # 从第1个开始
        "damage": "1d8",     # 伤害骰
        "action": "action",  # 动作类型
    },
    "bow_attack": {
        "name": "远程攻击",
        "name_cn": "弓箭射击",
        "range": 4,           # 攻击范围：全部
        "start": 1,
        "damage": "1d6",
        "action": "action",
    },
    "charge": {
        "name": "冲锋",
        "name_cn": "战士冲锋",
        "range": 2,           # 攻击范围：后排2个
        "start": 3,           # 从第3个开始
        "damage": "2d6",
        "action": "action",
        "desc": "突进到后排进行攻击"
    },
    "fireball": {
        "name": "火球术",
        "name_cn": "火球术",
        "range": 4,
        "start": 1,
        "damage": "8d6",
        "save_type": "dexterity",
        "save_dc": 15,
        "action": "action",
        "level": 3,
    },
    "taunt": {
        "name": "嘲讽",
        "name_cn": "嘲讽",
        "range": 4,
        "start": 1,
        "action": "action",
        "required_position": 1,  # 必须站在1号位
        "effect": "强制所有敌人攻击自己"
    },
    "shield_bash": {
        "name": "盾击",
        "name_cn": "盾牌猛击",
        "range": 2,
        "start": 1,
        "damage": "1d6+str",
        "action": "action",
        "required_position": [1, 2],  # 必须站在前2个位置
    },
    "arcane_blast_power": {
        "name": "奥术冲击（强化）",
        "name_cn": "奥术冲击",
        "range": 4,
        "start": 1,
        "damage": "5d10",
        "action": "action",
        "required_position": 4,  # 必须站在4号位
        "bonus": "4号位时伤害+50%"
    },
    "healing_word": {
        "name": "治疗真言",
        "name_cn": "治愈真言",
        "range": 4,
        "start": 1,
        "heal": "1d4",
        "action": "bonus_action",
        "target_ally": True,  # 治疗友方
    },
    "drag": {
        "name": "拖拽",
        "name_cn": "拖拽",
        "range": 4,
        "start": 1,
        "action": "action",
        "effect": "pull",     # 拉人效果
        "target_position": 3,  # 拉到3号位
    }
}
```

---

## 攻击范围设计（最终版总结）

### 核心概念

**位置系统**：
- 每个单位占据1-4号位中的某个位置
- 死亡单位的位置保留（用于复活）
- **战斗时只计算存活单位**

**攻击范围判定**：
```python
# 判定公式
可攻击位置 = [start, start+1, ..., start+range-1]

# 与存活单位数量取交集
实际可攻击 = 取交集(可攻击位置, [1, 2, ..., 存活数量])
```

### 攻击范围示例表

| 技能/攻击 | range | start | 可攻击位置 | 适用场景 |
|-----------|-------|-------|-----------|----------|
| 普通攻击 | 2 | 1 | [1, 2] | 近战武器默认 |
| 远程攻击 | 4 | 1 | [1, 2, 3, 4] | 弓箭、投掷武器 |
| 法术攻击 | 4 | 1 | [1, 2, 3, 4] | 所有法术 |
| 冲锋突进 | 2 | 3 | [3, 4] | 战士冲锋、法师闪现 |
| 治疗友方 | 4 | 1 | [1, 2, 3, 4] | 所有治疗技能 |

### 动态示例

**情况1：敌人3、4号位死亡**
```
敌人存活：[1号位哥布林, 2号位狼人]
可用位置：[1, 2]
近战攻击(2,1)：可攻击[1, 2] → 正确 ✅
```

**情况2：只剩法师在4号位存活**
```
敌人存活：[4号位法师]
可用位置：[1]  # 法师被视为1号位
近战攻击(2,1)：可攻击[1] → 可攻击法师 ✅
远程攻击(4,1)：可攻击[1] → 可攻击法师 ✅
```

**情况3：突进技能（range=2, start=3）**
```
敌人存活：[1, 2, 3, 4] → 可攻击[3, 4]
敌人存活：[1, 2] → 可攻击[] → 无法使用 ✅
敌人存活：[1, 2, 3] → 可攻击[3] → 可攻击3号位
```

### 判定代码

```python
def can_use_skill(skill_range: int, skill_start: int,
                 combat_position: int, alive_count: int) -> bool:
    """判定技能是否可使用"""
    if combat_position > alive_count:
        return False

    attackable = list(range(skill_start, skill_start + skill_range))
    return combat_position in attackable
```

---

## 四、站位规则与攻击权限判定

### 4.1 站位判定系统（简化版）

```python
class PositionManager:
    """站位管理器 - 简化版：存活单位压缩"""

    def __init__(self):
        self.ally_positions: Dict[int, Optional[CombatUnit]] = {
            1: None, 2: None, 3: None, 4: None
        }
        self.enemy_positions: Dict[int, Optional[CombatUnit]] = {
            1: None, 2: None, 3: None, 4: None
        }

    def get_alive_units(self, is_ally: bool) -> List[CombatUnit]:
        """获取所有存活单位（按位置排序）

        核心设计：只返回存活的单位，死亡单位不参与战斗
        """
        positions = self.ally_positions if is_ally else self.enemy_positions
        alive_units = []

        for pos in [1, 2, 3, 4]:
            unit = positions.get(pos)
            if unit and not unit.is_dead and not unit.is_unconscious:
                alive_units.append(unit)

        return alive_units

    def get_alive_positions(self, is_ally: bool) -> List[int]:
        """获取所有存活单位的位置列表

        Returns:
            [1, 2, 3, 4] 中哪些位置有存活单位
        """
        positions = self.ally_positions if is_ally else self.enemy_positions
        alive_positions = []

        for pos in [1, 2, 3, 4]:
            unit = positions.get(pos)
            if unit and not unit.is_dead and not unit.is_unconscious:
                alive_positions.append(pos)

        return alive_positions

    def get_combat_position(self, actual_position: int, is_ally: bool) -> int:
        """将实际位置转换为战斗位置

        例如：只有3号位存活 → 战斗位置为1
        例如：1、4号位存活 → 战斗位置为[1, 2]

        Args:
            actual_position: 实际位置（1-4）
            is_ally: 是否是我方

        Returns:
            战斗位置（1-4）
        """
        alive_positions = self.get_alive_positions(is_ally)

        if not alive_positions:
            return 0

        if actual_position not in alive_positions:
            return 0

        return alive_positions.index(actual_position) + 1

    def can_attack_position(self, attacker: CombatUnit, target_combat_pos: int,
                            attack_range: AttackRange, target_is_ally: bool = False) -> bool:
        """判定是否可以攻击某战斗位置

        Args:
            attacker: 攻击者
            target_combat_pos: 目标战斗位置（1-4，基于存活单位计算）
            attack_range: 攻击范围
            target_is_ally: 目标是否是我方
        """
        alive_positions = self.get_alive_positions(target_is_ally)

        if not alive_positions:
            return False

        if target_combat_pos > len(alive_positions):
            return False

        actual_target_pos = alive_positions[target_combat_pos - 1]

        if attack_range == AttackRange.MELEE_ONLY:
            return target_combat_pos in [1, 2]
        elif attack_range == AttackRange.RANGED_ONLY:
            return True
        elif attack_range == AttackRange.ALL_RANGE:
            return True
        elif attack_range == AttackRange.PIERCE_BACK:
            return target_combat_pos in [3, 4]

        return False

    def get_unit_at_combat_position(self, combat_pos: int,
                                    is_ally: bool) -> Optional[CombatUnit]:
        """根据战斗位置获取单位

        Args:
            combat_pos: 战斗位置（1-4）
            is_ally: 是否是我方

        Returns:
            对应战斗位置的存活单位
        """
        alive_positions = self.get_alive_positions(is_ally)

        if not alive_positions or combat_pos > len(alive_positions):
            return None

        actual_pos = alive_positions[combat_pos - 1]
        return self.get_unit_at(actual_pos, is_ally)

    def get_valid_targets(self, attacker: CombatUnit,
                         attack_range: AttackRange,
                         target_is_ally: bool = False) -> List[CombatUnit]:
        """获取有效目标列表

        简化设计：只返回存活的单位
        """
        alive_units = self.get_alive_units(target_is_ally)
        valid_targets = []

        for i, unit in enumerate(alive_units):
            combat_pos = i + 1

            if self.can_attack_position(attacker, combat_pos, attack_range, target_is_ally):
                valid_targets.append(unit)

        return valid_targets

    def assign_position(self, unit: CombatUnit, position: int,
                       is_ally: bool = None) -> bool:
        """分配单位到指定位置"""
        if position not in [1, 2, 3, 4]:
            return False

        if is_ally is None:
            is_ally = (unit.unit_type == "player")

        unit.position = position
        unit.original_position = position

        if is_ally:
            self.ally_positions[position] = unit
        else:
            self.enemy_positions[position] = unit

        return True

    def swap_positions(self, unit: CombatUnit, new_position: int) -> bool:
        """交换位置（可与空位交换）"""
        if new_position not in [1, 2, 3, 4]:
            return False

        if unit.is_dead or unit.is_unconscious:
            return False

        current_position = unit.position
        is_ally = (unit.unit_type == "player")
        occupant = self.get_unit_at(new_position, is_ally)

        if occupant and not occupant.is_dead and not occupant.is_unconscious:
            if occupant.unit_type == unit.unit_type:
                occupant.position = current_position
                if is_ally:
                    self.ally_positions[current_position] = occupant
                else:
                    self.enemy_positions[current_position] = occupant
            else:
                return False

        if is_ally:
            self.ally_positions[current_position] = None
            self.ally_positions[new_position] = unit
        else:
            self.enemy_positions[current_position] = None
            self.enemy_positions[new_position] = unit

        unit.swap_to_position(new_position)
        return True

    def force_position_change(self, target_unit: CombatUnit,
                             new_position: int) -> Tuple[bool, str]:
        """强制改变单位位置（用于敌人拉人等技能）

        Args:
            target_unit: 目标单位
            new_position: 新位置

        Returns:
            (是否成功, 描述信息)
        """
        if target_unit.is_dead or target_unit.is_unconscious:
            return False, "目标无法移动"

        is_ally = (target_unit.unit_type == "player")
        current_pos = target_unit.position

        occupant = self.get_unit_at(new_position, is_ally)

        if occupant and not occupant.is_dead and not occupant.is_unconscious:
            occupant.position = current_pos
            if is_ally:
                self.ally_positions[current_pos] = occupant
            else:
                self.enemy_positions[current_pos] = occupant
        else:
            if is_ally:
                self.ally_positions[current_pos] = None
            else:
                self.enemy_positions[current_pos] = None

        if is_ally:
            self.ally_positions[new_position] = target_unit
        else:
            self.enemy_positions[new_position] = target_unit

        target_unit.swap_to_position(new_position)

        return True, f"{target_unit.name} 被移动到{new_position}号位"

    def check_position_restriction(self, unit: CombatUnit,
                                   skill_id: str) -> Tuple[bool, str]:
        """检查技能站位限制

        Args:
            unit: 使用技能的单位
            skill_id: 技能ID

        Returns:
            (是否满足限制, 错误信息)
        """
        skill = SkillDatabase.SKILLS.get(skill_id)
        if not skill:
            return True, ""

        required_position = skill.get("required_position")

        if required_position is None:
            return True, ""

        current_pos = unit.position
        if current_pos != required_position:
            return False, f"该技能需要站在{required_position}号位才能使用"

        return True, ""

    def get_battlefield_display(self, is_ally: bool) -> Dict:
        """获取战斗显示数据（简化版，只显示存活单位）

        Returns:
            {
                "alive_positions": [1, 2, 3, 4],  # 有存活单位的位置
                "units": [(位置, 单位名, HP比例), ...]
            }
        """
        positions = self.ally_positions if is_ally else self.enemy_positions
        alive_units = []

        for pos in [1, 2, 3, 4]:
            unit = positions.get(pos)
            if unit and not unit.is_dead and not unit.is_unconscious:
                hp_ratio = unit.current_hp / unit.max_hp
                alive_units.append({
                    "position": pos,
                    "name": unit.name,
                    "hp_ratio": hp_ratio,
                    "conditions": unit.conditions.copy()
                })

        return {
            "alive_count": len(alive_units),
            "units": alive_units
        }
```

### 4.2 攻击权限判定（基于技能/武器，而非职业）

```python
class AttackPermissionChecker:
    """攻击权限检查器"""

    # 攻击手段的攻击范围定义
    ATTACK_RANGE_BY_WEAPON = {
        # 近战武器
        "sword": AttackRange.MELEE_ONLY,       # 剑
        "axe": AttackRange.MELEE_ONLY,         # 斧
        "unarmed": AttackRange.MELEE_ONLY,     # 徒手
        "dagger": AttackRange.MELEE_ONLY,      # 匕首（短）
        "greatsword": AttackRange.MELEE_ONLY,  # 大剑

        # 远程武器
        "bow": AttackRange.RANGED_ONLY,        # 弓
        "crossbow": AttackRange.RANGED_ONLY,    # 弩
        "thrown": AttackRange.RANGED_ONLY,      # 投掷

        # 法术（全部可攻击1-4号位）
        "spell": AttackRange.ALL_RANGE,         # 法术
        "cantrip": AttackRange.ALL_RANGE,       # 戏法

        # 特殊技能
        "charge": AttackRange.PIERCE_BACK,      # 冲锋（突进）
        "dash": AttackRange.PIERCE_BACK,        # 冲刺（突进）
        "teleport": AttackRange.ALL_RANGE,      # 闪现（全距离）
    }

    @classmethod
    def get_attack_range_by_weapon(cls, weapon_or_skill: str) -> AttackRange:
        """根据武器/技能类型获取攻击范围

        Args:
            weapon_or_skill: 武器ID或技能ID

        Returns:
            AttackRange: 攻击范围枚举
        """
        return cls.ATTACK_RANGE_BY_WEAPON.get(
            weapon_or_skill.lower(),
            AttackRange.MELEE_ONLY  # 默认近战
        )

    @classmethod
    def can_attack_target_with_skill(cls, attacker: CombatUnit,
                                      target: CombatUnit,
                                      skill_id: str) -> bool:
        """检查攻击者使用指定技能是否可以攻击目标

        核心设计：攻击范围绑定于技能/武器，而非角色职业

        Args:
            attacker: 攻击者
            target: 目标
            skill_id: 使用的技能/武器ID

        Returns:
            bool: 是否可以攻击
        """
        # 获取该技能的攻击范围
        attack_range = cls.get_attack_range_by_weapon(skill_id)
        target_pos = target.position

        # 死亡/昏迷状态
        if target.is_dead or target.is_unconscious:
            return False

        # 嘲讽状态：被嘲讽时只能攻击嘲讽源
        if target.is_taunted and target.taunt_source != attacker.unit_id:
            return target.taunt_source == attacker.unit_id

        # 站位判定
        return PositionManager().can_attack_position(
            attacker, target_pos, attack_range)

    @classmethod
    def get_available_targets_by_skill(cls, attacker: CombatUnit,
                                     enemies: Dict[int, CombatUnit],
                                     skill_id: str) -> List[CombatUnit]:
        """获取使用指定技能的所有可用目标

        Args:
            attacker: 攻击者
            enemies: 敌人站位字典
            skill_id: 使用的技能/武器ID

        Returns:
            List[CombatUnit]: 可攻击的目标列表
        """
        attack_range = cls.get_attack_range_by_weapon(skill_id)
        valid_targets = []

        for pos, enemy in enemies.items():
            if enemy and not enemy.is_dead and not enemy.is_unconscious:
                if PositionManager().can_attack_position(attacker, pos, attack_range):
                    valid_targets.append(enemy)

        return valid_targets
```

### 4.3 技能/武器定义表

```python
class SkillDatabase:
    """技能数据库 - 定义所有可用的攻击技能及其攻击范围"""

    SKILLS = {
        # === 近战技能（攻击1-2号位）===
        "melee_basic": {
            "name": "近战攻击",
            "name_cn": "普通攻击",
            "attack_range": AttackRange.MELEE_ONLY,
            "damage": "1d6",
            "action_type": ActionType.STANDARD_ACTION,
            "description": "使用近战武器进行攻击"
        },
        "unarmed_strike": {
            "name": "徒手打击",
            "name_cn": "徒手攻击",
            "attack_range": AttackRange.MELEE_ONLY,
            "damage": "1d4",
            "action_type": ActionType.STANDARD_ACTION,
            "description": "徒手搏斗"
        },
        "offhand_attack": {
            "name": "副手攻击",
            "name_cn": "双武器攻击",
            "attack_range": AttackRange.MELEE_ONLY,
            "damage": "1d6",
            "action_type": ActionType.BONUS_ACTION,
            "description": "副手武器攻击（需要主手已攻击）"
        },

        # === 远程技能（攻击1-4号位）===
        "ranged_basic": {
            "name": "远程攻击",
            "name_cn": "远程攻击",
            "attack_range": AttackRange.RANGED_ONLY,
            "damage": "1d6",
            "action_type": ActionType.STANDARD_ACTION,
            "description": "使用弓/弩进行远程攻击"
        },
        "thrown_weapon": {
            "name": "武器投掷",
            "name_cn": "投掷武器",
            "attack_range": AttackRange.RANGED_ONLY,
            "damage": "1d4",
            "action_type": ActionType.STANDARD_ACTION,
            "description": "投掷武器进行攻击"
        },

        # === 突进技能（攻击3-4号位）===
        "charge": {
            "name": "冲锋",
            "name_cn": "战士冲锋",
            "attack_range": AttackRange.PIERCE_BACK,
            "damage": "2d6",
            "action_type": ActionType.STANDARD_ACTION,
            "description": "突进到后排，对3-4号位敌人发起攻击",
            "requires": "本回合未移动"
        },
        "teleport_strike": {
            "name": "闪现斩",
            "name_cn": "法师闪现斩",
            "attack_range": AttackRange.PIERCE_BACK,
            "damage": "2d8",
            "action_type": ActionType.STANDARD_ACTION,
            "description": "传送到后排敌人身边进行攻击",
            "cost": "消耗1个法术位"
        },

        # === 法术技能（攻击1-4号位）===
        "magic_missile": {
            "name": "魔法飞弹",
            "name_cn": "魔法飞弹",
            "attack_range": AttackRange.ALL_RANGE,
            "damage": "3d4+3",
            "action_type": ActionType.STANDARD_ACTION,
            "school": "塑能",
            "level": 1,
            "description": "发射魔法飞弹攻击目标"
        },
        "fireball": {
            "name": "火球术",
            "name_cn": "火球术",
            "attack_range": AttackRange.ALL_RANGE,
            "damage": "8d6",
            "save_type": "dexterity",
            "save_dc": 15,
            "action_type": ActionType.STANDARD_ACTION,
            "school": "塑能",
            "level": 3,
            "aoe": True,
            "description": "区域内所有敌人进行敏捷豁免"
        },
        "healing_word": {
            "name": "治愈真言",
            "name_cn": "治愈真言",
            "attack_range": AttackRange.ALL_RANGE,
            "heal": "1d4",
            "action_type": ActionType.BONUS_ACTION,
            "school": "防护",
            "level": 1,
            "description": "治疗一个盟友"
        },
    }
```

        # 按仇恨优先级排序（站位自动仇恨）
        valid_targets.sort(key=lambda x: x.position)
        return valid_targets
```

---

## 五、完整战斗回合执行流程

### 5.1 CombatManager 战斗管理器

```python
class CombatManager:
    """战斗管理器"""

    def __init__(self):
        self.combat_id: str = str(uuid.uuid4())[:8].upper()
        self.ally_units: Dict[int, PlayerUnit] = {}
        self.enemy_units: Dict[int, MonsterUnit] = {}
        self.position_manager: PositionManager = PositionManager()
        self.initiative_order: List[CombatUnit] = []
        self.current_turn_index: int = 0
        self.round_number: int = 1
        self.turn_start_time: float = 0
        self.turn_time_limit: int = 90  # 秒
        self.combat_state: str = "waiting"  # waiting | initiative | active | paused | ended
        self.rest_available: int = 1  # 短休次数

        # LLM接口
        self.llm_enabled: bool = True
        self.llm_api_key: str = ""
        self.llm_endpoint: str = ""

    async def start_combat(self, party: List[PlayerUnit],
                          enemies: List[MonsterUnit]) -> str:
        """开启战斗"""
        self.combat_state = "initiative"

        # 分配站位
        await self._assign_positions(party, enemies)

        # 自动先攻排序
        await self._roll_initiative()

        # 生成战斗开始文本
        start_text = await self._generate_combat_start_text()

        self.combat_state = "active"
        self.turn_start_time = time.time()

        return start_text

    async def _roll_initiative(self):
        """自动先攻排序"""
        all_units = list(self.ally_units.values()) + list(self.enemy_units.values())

        for unit in all_units:
            dex_mod = unit.abilities.get_modifier("dexterity")
            roll_result = DiceRoller.roll_d20()
            unit.initiative = roll_result.total + dex_mod

        # 排序
        self.initiative_order = sorted(
            all_units,
            key=lambda x: (x.initiative, x.abilities.dexterity),
            reverse=True
        )

    async def _assign_positions(self, party: List[PlayerUnit],
                                enemies: List[MonsterUnit]):
        """分配站位"""
        # 玩家按职业分配位置（坦克优先1号位）
        tank_classes = ["战士", "野蛮人", "圣武士"]
        support_classes = ["牧师", "德鲁伊", "吟游诗人"]

        sorted_party = []
        tanks = [p for p in party if p.class_name in tank_classes]
        supports = [p for p in party if p.class_name in support_classes]
        others = [p for p in party if p not in tanks + supports]

        sorted_party = tanks + others + supports

        for i, unit in enumerate(sorted_party):
            unit.position = i + 1
            self.ally_units[i + 1] = unit

        # 敌人分配（简单策略：按CR排序）
        sorted_enemies = sorted(enemies, key=lambda x: x.cr, reverse=True)
        for i, unit in enumerate(sorted_enemies):
            unit.position = i + 1
            self.enemy_units[i + 1] = unit

    async def process_turn(self, action: str, params: Dict) -> str:
        """处理当前回合动作"""
        current_unit = self.initiative_order[self.current_turn_index]

        # 检查超时
        if time.time() - self.turn_start_time > self.turn_time_limit:
            return await self._auto_skip_turn(current_unit)

        # 解析动作
        result_text = await self._execute_action(current_unit, action, params)

        # 检查战斗结束
        if self._check_combat_end():
            return await self._end_combat()

        # 下一回合
        await self._next_turn()

        return result_text

    async def _execute_action(self, unit: CombatUnit, action: str,
                             params: Dict) -> str:
        """执行动作"""
        if action == "attack":
            return await self._execute_attack(unit, params)
        elif action == "spell":
            return await self._execute_spell(unit, params)
        elif action == "move":
            return await self._execute_move(unit, params)
        elif action == "swap":
            return await self._execute_swap(unit, params)
        elif action == "defend":
            return await self._execute_defend(unit)
        elif action == "use_item":
            return await self._execute_use_item(unit, params)
        else:
            return f"❌ 无效动作: {action}"

    async def _next_turn(self):
        """进入下一回合"""
        current_unit = self.initiative_order[self.current_turn_index]

        # 重置动作状态
        current_unit.action_used = False
        current_unit.bonus_action_used = False
        current_unit.movement_used = False
        current_unit.reaction_available = True

        # 更新索引
        self.current_turn_index += 1
        if self.current_turn_index >= len(self.initiative_order):
            self.current_turn_index = 0
            self.round_number += 1

        # 检查专注是否被打断
        self._check_concentration()

        self.turn_start_time = time.time()

    def _check_combat_end(self) -> bool:
        """检查战斗是否结束"""
        ally_alive = any(not u.is_dead for u in self.ally_units.values())
        enemy_alive = any(not u.is_dead for u in self.enemy_units.values())

        if not ally_alive or not enemy_alive:
            return True
        return False

    async def _end_combat(self) -> str:
        """结束战斗"""
        self.combat_state = "ended"

        ally_alive = any(not u.is_dead for u in self.ally_units.values())
        if ally_alive:
            # 胜利
            rewards = await self._calculate_rewards()
            result_text = await self._generate_victory_text(rewards)
        else:
            # 失败
            result_text = await self._generate_defeat_text()

        return result_text
```

### 5.2 回合流程时序图

```
┌─────────────────────────────────────────────────────────────────┐
│                    战斗回合时序图                                 │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  【战斗开始】                                                     │
│      │                                                          │
│      ▼                                                          │
│  ┌─────────────────┐                                            │
│  │  1. 分配站位    │  ← 坦克1号位、输出2-3号位、脆皮4号位       │
│  └────────┬────────┘                                            │
│           ▼                                                      │
│  ┌─────────────────┐                                            │
│  │  2. 先攻排序    │  ← 自动D20+敏捷调整                          │
│  └────────┬────────┘                                            │
│           ▼                                                      │
│  ┌─────────────────┐                                            │
│  │  3. 生成战斗文本 │  ← 预设+LLM（关键场景）                     │
│  └────────┬────────┘                                            │
│           ▼                                                      │
│  ════════════════════════════════════════════════               │
│                    【战斗循环】                                   │
│  ════════════════════════════════════════════════               │
│      │                                                          │
│      ▼ [回合开始]                                                │
│  ┌─────────────────┐                                            │
│  │ 4. 显示回合信息  │  ← 当前行动者、倒计时                       │
│  └────────┬────────┘                                            │
│           ▼                                                      │
│  ┌─────────────────┐                                            │
│  │ 5. 玩家选择动作  │  ← 攻击/技能/换位/休息/道具/跳过          │
│  └────────┬────────┘                                            │
│           ▼                                                      │
│  ┌─────────────────┐                                            │
│  │ 6. 执行动作      │  ← 判定命中、伤害、状态                    │
│  └────────┬────────┘                                            │
│           ▼                                                      │
│  ┌─────────────────┐                                            │
│  │ 7. 生成结果文本  │  ← 预设格式+LLM增强                        │
│  └────────┬────────┘                                            │
│           ▼                                                      │
│  ┌─────────────────┐                                            │
│  │ 8. 检查触发事件  │  ← 借机攻击、嘲讽、专注打断                │
│  └────────┬────────┘                                            │
│           ▼                                                      │
│  ┌─────────────────┐                                            │
│  │ 9. 检查战斗结束  │  ← 敌人全灭/玩家全灭                       │
│  └────────┬────────┘                                            │
│           │ [继续]                                               │
│      ┌────┴────┐                                                │
│      │         │                                                │
│      ▼         ▼                                                │
│  【回合结束】  【下一回合】                                        │
│      │         │                                                │
│      │    ┌────┴────┐                                           │
│      │    │ 重置动作 │                                           │
│      │    └────┬────┘                                           │
│      │         │                                                │
│      └────►【回合开始】                                          │
│                                                                  │
│  ════════════════════════════════════════════════               │
│                                                                  │
│      ▼ [战斗结束]                                                │
│  ┌─────────────────┐                                            │
│  │ 10. 结算奖励    │  ← XP、金币、掉落                          │
│  └────────┬────────┘                                            │
│           ▼                                                      │
│  ┌─────────────────┐                                            │
│  │ 11. 生成结束文本 │  ← 预设+LLM                                │
│  └─────────────────┘                                            │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

---

## 六、所有可执行行动列表

### 6.1 行动分类树

```
【战斗行动】
│
├── 📌 标准动作（Standard Action）- 每回合1次
│   ├── ⚔️ 近战攻击（Melee Attack）
│   │   ├── 普通攻击
│   │   ├── 双武器攻击（战士5级+）
│   │   └── 武器投掷
│   │
│   ├── 🏹 远程攻击（Ranged Attack）
│   │   └── 弓/弩/投掷武器
│   │
│   ├── ✨ 法术攻击（Spell Attack）
│   │   ├── 攻击型法术（魔法飞弹、火焰箭）
│   │   └── 豁免型法术（火球术、闪电束）
│   │
│   ├── 🛡️ 防御动作（Defend）
│   │   └── 本回合AC+2，下回合开始时生效
│   │
│   ├── 🏃 撤离（Dodge）
│   │   └── 敏捷豁免优势，敌人攻击劣势
│   │
│   ├── 🙈 隐藏（Hide）
│   │   └── 敏捷(隐匿)检定，成功后AC+2
│   │
│   ├── 🔧 准备动作（Ready）
│   │   └── 准备触发动作
│   │
│   └── 🆘 帮助（Help）
│       └── 指定目标下回合攻击获得优势
│
├── ⚡ 附赠动作（Bonus Action）- 每回合最多1次
│   ├── 🗡️ 副手攻击（Off-hand Attack）
│   ├── ✨ 戏法施放（Cantrip）
│   ├── 💬 诗人激励（Bard Inspiration）
│   └── 💊 药水使用（Use Potion）
│
├── 🔄 反应动作（Reaction）- 满足条件时
│   ├── ⚔️ 借机攻击（Opportunity Attack）
│   ├── 🛡️ 借机防御（Defensive Attack）
│   └── ✨ 法术反应（Spell Reaction）
│
└── 🚶 移动动作（Movement）
    ├── ↔️ 自由移动（Free Movement）
    ├── 🔄 换位（Swap Position）
    ├── ⬆️ 前压（Push Forward）
    ├── ⬇️ 后撤（Fall Back）
    ├── 💨 冲锋（Charge）- 消耗额外移动
    └── 🏃 撤离（Disengage）- 防止借机攻击
```

### 6.2 行动执行器

```python
class ActionResolver:
    """行动解析器"""

    async def execute_attack(self, attacker: CombatUnit, target_pos: int,
                            skill_id: str = "melee_basic") -> AttackResult:
        """执行攻击

        核心设计：攻击范围取决于使用的技能/武器，而非角色职业

        Args:
            attacker: 攻击者
            target_pos: 目标位置（1-4）
            skill_id: 使用的技能/武器ID

        Returns:
            AttackResult: 攻击结果
        """
        target = self._get_target_at(target_pos)
        if not target:
            return AttackResult(success=False, message="目标不存在")

        # 获取技能定义
        skill = SkillDatabase.SKILLS.get(skill_id)
        if not skill:
            return AttackResult(success=False, message=f"未知技能: {skill_id}")

        # 检查攻击范围（基于技能，而非职业）
        if not AttackPermissionChecker.can_attack_target_with_skill(attacker, target, skill_id):
            attack_range = skill.get("attack_range", AttackRange.MELEE_ONLY)
            if attack_range == AttackRange.MELEE_ONLY:
                return AttackResult(success=False, message="该技能只能攻击前排敌人（1-2号位）")
            elif attack_range == AttackRange.PIERCE_BACK:
                return AttackResult(success=False, message="该技能只能攻击后排敌人（3-4号位）")
            else:
                return AttackResult(success=False, message="目标不在攻击范围内")

        # 标记动作已用
        attacker.action_used = True

        # 计算攻击加值
        attack_bonus = attacker.attack_bonus

        # 法术使用法术攻击加值
        if skill.get("school"):
            attack_bonus = attacker.get_spell_attack_bonus()

        # 投掷攻击骰
        attack_roll = DiceRoller.roll_attack(attack_bonus)

        # 命中判定
        hit = attack_roll.is_critical or (attack_roll.total >= target.armor_class)

        # 计算伤害
        damage = 0
        if hit:
            # 获取技能伤害
            if skill.get("damage"):
                damage_roll = DiceRoller.roll_from_notation(skill["damage"])
                damage = damage_roll.total

            # 加上属性修正
            damage += attacker.damage_bonus

            # 偷袭（盗贼技能）
            if skill_id in ["sneak_attack", "backstab"]:
                sneak_damage = DiceRoller.roll_from_notation("1d6")
                damage += sneak_damage.total

            # 战士双武器攻击
            if skill_id == "offhand_attack":
                # 副手不加上属性修正
                damage = damage_roll.total

            target.current_hp -= damage

        # 生成结果文本
        result = AttackResult(
            success=True,
            attack_roll=attack_roll,
            hit=hit,
            damage=damage,
            target_hp=target.current_hp,
            message=await self._generate_attack_text(attacker, target, hit, damage)
        )

        # 检查借机攻击触发
        if hit and attacker.unit_type == "player":
            await self._check_opportunity_attacks(target)

        return result

    async def execute_spell(self, caster: CombatUnit, spell_name: str,
                          target_pos: int = None) -> SpellResult:
        """执行法术"""
        spell = SpellDatabase.get_spell(spell_name)
        if not spell:
            return SpellResult(success=False, message=f"未知法术: {spell_name}")

        # 检查法术位
        if spell.level > 0:
            if caster.spell_slots.get(spell.level, 0) <= 0:
                return SpellResult(success=False, message="法术位不足")

            caster.spell_slots[spell.level] -= 1

        caster.action_used = True

        # 执行法术效果
        if spell.attack_type:
            # 攻击型法术
            target = self._get_target_at(target_pos)
            result = await self._process_spell_attack(caster, spell, target)
        else:
            # 豁免型法术
            result = await self._process_spell_save(caster, spell, target_pos)

        return result

    async def execute_swap(self, unit: CombatUnit, new_position: int) -> bool:
        """执行换位"""
        if new_position == unit.position:
            return False

        # 检查目标位置是否被占用
        occupant = self.position_manager.get_unit_at(new_position)
        if occupant and occupant.unit_type == unit.unit_type:
            # 同阵营可互换
            occupant.position = unit.position
            unit.position = new_position
        elif not occupant:
            # 空位直接移动
            old_pos = unit.position
            unit.position = new_position
        else:
            return False

        # 触发借机攻击
        if unit.unit_type == "ally":
            await self._check_opportunity_attacks(unit)

        return True

    async def execute_defend(self, unit: CombatUnit) -> bool:
        """执行防御动作"""
        unit.action_used = True
        unit.defending = True
        unit.temp_ac_bonus = 2
        return True

    async def execute_dodge(self, unit: CombatUnit) -> bool:
        """执行躲避"""
        unit.action_used = True
        unit.dodging = True
        unit.dex_saves_advantage = True
        return True

    async def _check_opportunity_attacks(self, moving_unit: CombatUnit):
        """检查借机攻击"""
        enemies = self._get_enemies_of(moving_unit)

        for pos, enemy in enemies.items():
            if enemy.reaction_available:
                # 借机攻击
                result = await self.execute_attack(enemy, moving_unit.position,
                                                  "opportunity")
                enemy.reaction_available = False

                # 通知玩家
                await self._notify_opportunity_attack(enemy, moving_unit, result)
```

---

## 七、借机攻击触发规则

### 7.1 借机攻击触发条件

```python
class OpportunityAttackRules:
    """借机攻击规则"""

    TRIGGER_CONDITIONS = {
        # 触发条件 : 触发描述
        "movement": "目标离开你的触及范围",
        "swap_forward": "目标向前排换位",
        "swap_backward": "目标向后排换位",
        "stand_up": "目标从倒地状态站起",
    }

    @classmethod
    def can_trigger_opportunity_attack(cls, attacker: CombatUnit,
                                       target: CombatUnit,
                                       trigger_type: str) -> bool:
        """判断是否可以触发借机攻击"""

        # 检查反应是否可用
        if not attacker.reaction_available:
            return False

        # 检查目标是否在触及范围内
        if trigger_type in ["movement", "swap_forward", "swap_backward"]:
            # 近战单位才能借机
            if not AttackPermissionChecker.get_attack_range(attacker) == AttackRange.MELEE_ONLY:
                return False

            # 检查位置是否相邻
            if abs(attacker.position - target.position) > 2:
                return False

        # 检查目标是否可见/可攻击
        if target.is_invisible and "invisible" not in attacker.special_senses:
            return False

        return True

    @classmethod
    async def process_opportunity_attack(cls, attacker: CombatUnit,
                                        target: CombatUnit,
                                        trigger_type: str) -> str:
        """处理借机攻击"""
        if not cls.can_trigger_opportunity_attack(attacker, target, trigger_type):
            return ""

        attacker.reaction_available = False

        # 执行借机攻击
        result = await ActionResolver().execute_attack(
            attacker, target.position, "opportunity")

        # 生成描述文本
        trigger_desc = cls.TRIGGER_CONDITIONS.get(trigger_type, "离开")
        text = f"⚡ **借机攻击！** {attacker.name} 对 {target.name} 发起借机攻击！\n"
        text += f"触发原因：{target.name} {trigger_desc}\n"
        text += result.message

        return text
```

### 7.2 借机攻击流程图

```
┌─────────────────────────────────────────────────────────────────┐
│                    借机攻击触发流程                               │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  【触发事件】                                                     │
│      │                                                          │
│      ├──► 玩家/敌人移动离开邻接位置                              │
│      │                                                          │
│      ├──► 玩家/敌人向前/后换位                                  │
│      │                                                          │
│      └──► 玩家/敌人从倒地状态站起                               │
│                                                                  │
│      ▼                                                          │
│  ┌─────────────────┐                                            │
│  │ 检查触发条件    │                                            │
│  │ • 反应是否可用  │                                            │
│  │ • 是否近战单位  │                                            │
│  │ • 位置是否相邻  │                                            │
│  └────────┬────────┘                                            │
│           │ [满足]                                               │
│           ▼                                                      │
│  ┌─────────────────┐                                            │
│  │ 执行借机攻击    │                                            │
│  │ • 消耗反应      │                                            │
│  │ • 正常攻击判定  │                                            │
│  │ • 正常伤害计算  │                                            │
│  └────────┬────────┘                                            │
│           ▼                                                      │
│  ┌─────────────────┐                                            │
│  │ 生成描述文本    │ ← 预设格式: "{攻击者}对{目标}发起借机攻击！" │
│  └────────┬────────┘                                            │
│           ▼                                                      │
│      【通知所有玩家】                                             │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

---

## 八、单人模式 & 四人组队模式适配

### 8.1 模式检测与适配

```python
class CombatModeAdapter:
    """战斗模式适配器"""

    @classmethod
    def detect_mode(cls, party: List[PlayerUnit]) -> str:
        """检测战斗模式"""
        active_members = [p for p in party if p and not p.is_dead]

        if len(active_members) == 1:
            return "solo"
        elif len(active_members) <= 4:
            return "small_party"
        else:
            return "full_party"

    @classmethod
    async def adjust_combat(cls, party: List[PlayerUnit],
                           enemies: List[MonsterUnit]) -> Tuple[List, List]:
        """适配战斗规模"""

        mode = cls.detect_mode(party)

        if mode == "solo":
            # 单人模式：生成预设NPC队友
            party, enemies = await cls._adjust_for_solo(party, enemies)
        elif mode == "small_party":
            # 小队模式：减少敌人数量/CR
            party, enemies = await cls._adjust_for_small_party(party, enemies)

        return party, enemies

    @classmethod
    async def _adjust_for_solo(cls, party: List[PlayerUnit],
                               enemies: List[MonsterUnit]) -> Tuple[List, List]:
        """单人模式适配"""

        # 生成NPC队友
        npc_tank = await cls._generate_npc("tank", party[0].level)
        npc_healer = await cls._generate_npc("healer", party[0].level)

        party = [party[0], npc_tank, npc_healer]

        # 减少敌人
        enemy_count = max(2, len(enemies) - 1)
        enemies = enemies[:enemy_count]

        # 降低敌人CR
        for enemy in enemies:
            enemy.cr = max(1, enemy.cr - 1)
            enemy.max_hp = int(enemy.max_hp * 0.8)

        return party, enemies

    @classmethod
    async def _generate_npc(cls, npc_type: str, level: int) -> PlayerUnit:
        """生成NPC队友"""
        npc_templates = {
            "tank": {
                "name": "守卫骑士",
                "class_name": "战士",
                "hp_ratio": 1.2,
            },
            "healer": {
                "name": "神殿僧侣",
                "class_name": "牧师",
                "hp_ratio": 0.8,
            }
        }

        template = npc_templates.get(npc_type, npc_templates["tank"])

        npc = PlayerUnit(
            unit_id=f"npc_{npc_type}_{uuid.uuid4()[:4]}",
            name=template["name"],
            unit_type="player",
            player_id="npc",
            player_name=template["name"],
            class_name=template["class_name"],
            level=level,
            max_hp=int(10 * level * template["hp_ratio"]),
            current_hp=int(10 * level * template["hp_ratio"]),
            abilities=AbilityScores(strength=14, dexterity=12, constitution=14,
                                   intelligence=10, wisdom=14, charisma=10),
            is_npc=True,
            npc_behavior="auto"  # NPC自动行动
        )

        return npc
```

### 8.2 模式对比

| 模式 | 玩家人数 | NPC队友 | 敌人数量 | 难度调整 |
|------|----------|---------|----------|----------|
| 单人 | 1人 | 2-3个预设NPC | 2-3个 | CR-1, HP×0.8 |
| 小队 | 2-3人 | 0-1个预设NPC | 3-4个 | CR-1, HP×0.9 |
| 满队 | 4人 | 0 | 4 | 标准 |

---

## 九、D&D时间系统适配

### 9.1 休息系统

```python
class RestSystem:
    """休息系统"""

    def __init__(self):
        self.short_rest_available: int = 1
        self.long_rest_available: bool = False
        self.combat_encounters_since_rest: int = 0

    async def request_short_rest(self, party: List[PlayerUnit]) -> str:
        """请求短休"""
        if self.short_rest_available <= 0:
            return "❌ 本次副本无法再短休"

        self.short_rest_available -= 1

        # 短休效果
        for unit in party:
            if not unit.is_dead:
                # 生命值恢复：1d6+体质调整
                heal_roll = DiceRoller.roll_d6() + unit.abilities.get_modifier("constitution")
                unit.current_hp = min(unit.max_hp, unit.current_hp + heal_roll)

                # 战士/盗贼：恢复使用次数特性
                if unit.class_name in ["战士", "盗贼"]:
                    pass  # 恢复短休特性

        return await self._generate_rest_text("short")

    async def request_long_rest(self, party: List[PlayerUnit]) -> str:
        """请求长休"""
        # 长休要求：至少经过1次战斗，且短休次数用尽
        if self.combat_encounters_since_rest < 1:
            return "❌ 需要至少经历1场战斗才能长休"

        # 长休效果
        for unit in party:
            if not unit.is_dead:
                # 恢复全部HP
                unit.current_hp = unit.max_hp
                unit.temp_hp = 0

                # 恢复所有法术位
                for level in unit.spell_slots:
                    unit.spell_slots[level] = MAX_SPELL_SLOTS[level]

                # 移除所有力竭等级
                if "力竭" in unit.conditions:
                    unit.conditions.remove("力竭")

        # 重置短休次数
        self.short_rest_available = 1

        return await self._generate_rest_text("long")

    def check_rest_eligibility(self) -> Dict:
        """检查休息资格"""
        return {
            "can_short_rest": self.short_rest_available > 0,
            "can_long_rest": self.combat_encounters_since_rest >= 1,
            "short_rest_remaining": self.short_rest_available,
            "encounters_since_rest": self.combat_encounters_since_rest
        }
```

### 9.2 法术位系统

```python
# 法术位上限表（每职业略有不同，这里用通用表）
MAX_SPELL_SLOTS = {
    1: 0,  # 0环（戏法）无限使用
    1: 2,  # 1环
    2: 0,  # 2环
    3: 0,  # 3环
    4: 0,  # 4环
    5: 0,  # 5环
    6: 0,  # 6环
    7: 0,  # 7环
    8: 0,  # 8环
    9: 0,  # 9环
}

class SpellSlotManager:
    """法术位管理器"""

    def __init__(self, spellcaster: PlayerUnit):
        self.spellcaster = spellcaster
        self.spell_slots = copy.deepcopy(MAX_SPELL_SLOTS)

        # 根据职业调整上限
        self._adjust_slots_by_class()

    def _adjust_slots_by_class(self):
        """根据职业调整法术位"""
        if self.spellcaster.class_name == "战士":
            return  # 战士无法术

        # 简化处理：1-5级每环1个
        for i in range(1, min(self.spellcaster.level + 1, 6)):
            self.spell_slots[i] = 1

    def use_slot(self, level: int) -> bool:
        """使用法术位"""
        if self.spell_slots.get(level, 0) <= 0:
            return False
        self.spell_slots[level] -= 1
        return True

    def restore_all(self):
        """恢复所有法术位"""
        for level in self.spell_slots:
            self.spell_slots[level] = MAX_SPELL_SLOTS[level]
        self._adjust_slots_by_class()
```

---

## 十、倒地与死亡豁免

### 10.1 昏迷与死亡豁免系统

```python
class DeathSaveSystem:
    """死亡豁免系统"""

    @classmethod
    async def process_unconscious(cls, unit: CombatUnit) -> str:
        """处理昏迷"""
        unit.is_unconscious = True
        unit.death_saves = {"success": 0, "fail": 0}
        unit.conditions.append("昏迷")

        # 昏迷状态：倒地、自动失败力量/敏捷检定
        text = f"💀 **{unit.name}** 陷入昏迷！\n"
        text += f"每回合需要进行死亡豁免（3次成功存活，3次失败死亡）\n"

        return text

    @classmethod
    async def roll_death_save(cls, unit: CombatUnit) -> DeathSaveResult:
        """投掷死亡豁免"""
        if not unit.is_unconscious:
            return DeathSaveResult(error="单位未昏迷")

        # 投D20
        roll = random.randint(1, 20)

        # 自动成功/失败
        if roll == 20:
            # 大成功：立即恢复1HP并苏醒
            unit.is_unconscious = False
            unit.current_hp = 1
            unit.conditions.remove("昏迷")
            return DeathSaveResult(
                success=True, critical=True, hp_restored=1,
                message=f"✨ **20！大成功！** {unit.name} 立即苏醒，恢复1HP！"
            )

        if roll == 1:
            # 大失败：算2次失败
            unit.death_saves["fail"] += 2
            message = f"💀 **1！大失败！** {unit.name} 算作2次失败！"
        else:
            # 正常判定
            dc = 10
            save_roll = roll + unit.abilities.get_modifier("constitution")

            if save_roll >= dc:
                unit.death_saves["success"] += 1
                message = f"✅ **成功！** ({roll} vs DC{dc})"
            else:
                unit.death_saves["fail"] += 1
                message = f"❌ **失败！** ({roll} vs DC{dc})"

        # 检查结局
        if unit.death_saves["success"] >= 3:
            # 存活
            unit.is_unconscious = False
            unit.current_hp = 1
            unit.conditions.remove("昏迷")
            unit.conditions.append("倒地")  # 倒地需要用动作站起
            message += f"\n🎉 **{unit.name}** 稳定！苏醒但仍倒在地上（需要动作站起）"

        elif unit.death_saves["fail"] >= 3:
            # 死亡
            unit.is_dead = True
            message += f"\n☠️ **{unit.name}** 死亡！"

        # 每次豁免自动受到1级力竭
        if "力竭" in unit.conditions:
            exhausted_level = unit.conditions.count("力竭")
            if exhausted_level < 6:
                unit.conditions.append("力竭")
        else:
            unit.conditions.append("力竭")

        return DeathSaveResult(
            success=unit.death_saves["success"] >= 3,
            fail=unit.death_saves["fail"] >= 3,
            current_success=unit.death_saves["success"],
            current_fail=unit.death_saves["fail"],
            message=message
        )

    @classmethod
    def stabilize_without_roll(cls, unit: CombatUnit):
        """不投骰稳定（治疗）"""
        if unit.is_unconscious and unit.current_hp > 0:
            unit.is_unconscious = False
            unit.conditions.remove("昏迷")
            if "倒地" in unit.conditions:
                unit.conditions.remove("倒地")
```

### 10.2 死亡豁免流程

```
┌─────────────────────────────────────────────────────────────────┐
│                    昏迷与死亡豁免流程                             │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  【HP降至0】                                                     │
│      │                                                          │
│      ▼                                                          │
│  ┌─────────────────┐                                            │
│  │ 临时生命值吸收  │ ← 先扣临时HP                                │
│  └────────┬────────┘                                            │
│           │                                                      │
│           ▼                                                      │
│  ┌─────────────────┐                                            │
│  │ 进入昏迷状态    │ ← HP=0, 倒在地上                            │
│  │ • 自动失败攻击  │                                            │
│  │ • 被攻击有劣势  │                                            │
│  │ • 暴露可攻击    │                                            │
│  └────────┬────────┘                                            │
│           │                                                      │
│           ▼                                                      │
│  ════════════════════════════════════════════════               │
│                    【回合开始：昏迷单位】                          │
│  ════════════════════════════════════════════════               │
│      │                                                          │
│      ▼                                                          │
│  ┌─────────────────┐                                            │
│  │ 自动投死亡豁免  │                                            │
│  │ • D20 vs DC 10  │                                            │
│  │ • +体质调整值   │                                            │
│  │ • 20=立即苏醒   │                                            │
│  │ • 1=2次失败     │                                            │
│  └────────┬────────┘                                            │
│           │                                                      │
│      ┌────┴────┐                                                │
│      │         │                                                │
│      ▼         ▼                                                │
│  【3次成功】  【3次失败】                                         │
│      │         │                                                │
│      ▼         ▼                                                │
│  ┌─────────────────┐    ┌─────────────────┐                    │
│  │ 稳定存活        │    │ 死亡            │                    │
│  │ • 恢复1HP       │    │ • 需要复活魔法   │                    │
│  │ • 仍倒在地上    │    │ • 需要复活道具   │                    │
│  │ • 需动作站起    │    │                  │                    │
│  └─────────────────┘    └─────────────────┘                    │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

---

## 十一、怪物职业化设计

### 11.1 怪物职业类型

```python
class MonsterRole(Enum):
    """怪物职业"""
    WARRIOR = "warrior"      # 战士型：近战主力
    RANGER = "ranger"        # 游侠型：远程输出
    MAGE = "mage"           # 法师型：法术攻击
    HEALER = "healer"       # 治疗型：恢复队友
    SUPPORT = "support"     # 辅助型：buff/debuff
    TANK = "tank"           # 坦克型：高HP高AC
    ASSASSIN = "assassin"   # 刺客型：高爆发脆皮
    ELITE = "elite"         # 精英型：综合能力
    BOSS = "boss"           # Boss型：传奇动作


class MonsterBehaviorScripts:
    """怪物行为脚本"""

    BEHAVIOR_TEMPLATES = {
        "warrior": {
            "description": "近战战士，优先攻击前排",
            "priority": ["front_row", "low_hp"],
            "actions": ["melee_attack", "challenge", "push"],
            "preferred_position": [1, 2],
        },
        "ranger": {
            "description": "远程射手，攻击任意位置",
            "priority": ["back_row", "squishy"],
            "actions": ["ranged_attack", "poison_arrow"],
            "preferred_position": [3, 4],
        },
        "mage": {
            "description": "法师，优先攻击后排脆皮",
            "priority": ["back_row", "caster"],
            "actions": ["spell_attack", "aoe_spell", "shield"],
            "preferred_position": [4],
        },
        "healer": {
            "description": "治疗者，保护队友",
            "priority": ["ally_low_hp", "self_protect"],
            "actions": ["heal_ally", "buff_ally", "stay_back"],
            "preferred_position": [3, 4],
        },
        "assassin": {
            "description": "刺客，高爆发优先击杀脆皮",
            "priority": ["back_row", "squishy", "surprise"],
            "actions": ["sneak_attack", "stealth", "backstab"],
            "preferred_position": [3, 4],
        },
        "boss": {
            "description": "首领，多阶段战斗",
            "priority": ["low_hp", "squishy", "random"],
            "actions": ["multi_attack", "special_ability", "legendary_action"],
            "preferred_position": [1],
            "legendary_actions": 3,
        }
    }

    @classmethod
    def get_behavior(cls, monster: MonsterUnit) -> Dict:
        """获取怪物行为"""
        role = MonsterRole(monster.monster_role)
        template = cls.BEHAVIOR_TEMPLATES.get(role.value, cls.BEHAVIOR_TEMPLATES["warrior"])

        return {
            "description": template["description"],
            "priority": template["priority"],
            "actions": template["actions"],
            "preferred_position": template["preferred_position"],
            "legendary_actions": template.get("legendary_actions", 0)
        }

    @classmethod
    async def decide_action(cls, monster: MonsterUnit,
                           combat_manager: CombatManager) -> Tuple[str, Dict]:
        """决定怪物动作（AI决策）"""

        behavior = cls.get_behavior(monster)

        # 评估局势
        situation = await cls._analyze_situation(monster, combat_manager)

        # 根据优先级选择目标
        target = await cls._select_target(monster, situation, behavior)

        # 根据当前状态选择动作
        action = await cls._select_action(monster, target, situation, behavior)

        return action, {"target": target, "situation": situation}

    @classmethod
    async def _analyze_situation(cls, monster: MonsterUnit,
                                 combat_manager: CombatManager) -> Dict:
        """分析当前局势"""
        allies = list(combat_manager.ally_units.values())

        return {
            "ally_count": len([a for a in allies if not a.is_dead]),
            "enemy_count": len([e for e in combat_manager.enemy_units.values() if not e.is_dead]),
            "lowest_hp_ally": min([a for a in allies if not a.is_dead],
                                  key=lambda x: x.current_hp / x.max_hp) if allies else None,
            "front_row_occupied": any(a.position <= 2 for a in allies if not a.is_dead),
            "monster_hp_ratio": monster.current_hp / monster.max_hp,
        }

    @classmethod
    async def _select_target(cls, monster: MonsterUnit,
                            situation: Dict,
                            behavior: Dict) -> Optional[CombatUnit]:
        """选择目标"""
        allies = list(situation.items())[0] if situation else []

        for priority in behavior["priority"]:
            if priority == "front_row":
                targets = [a for a in allies if a.position <= 2 and not a.is_dead]
            elif priority == "back_row":
                targets = [a for a in allies if a.position >= 3 and not a.is_dead]
            elif priority == "low_hp":
                targets = sorted([a for a in allies if not a.is_dead],
                                key=lambda x: x.current_hp)
            elif priority == "squishy":
                targets = [a for a in allies if a.class_name in ["法师", "术士", "吟游诗人"]]

            if targets:
                return targets[0]

        return None
```

### 11.2 预设怪物模板

```python
MONSTER_TEMPLATES = {
    "哥布林": {
        "role": "warrior",
        "cr": 0.25,
        "max_hp": 7,
        "armor_class": 15,
        "attack_bonus": 4,
        "damage": "1d6+2",
        "behavior": "aggressive",
    },
    "狼人": {
        "role": "assassin",
        "cr": 1,
        "max_hp": 11,
        "armor_class": 13,
        "attack_bonus": 5,
        "damage": "2d4+3",
        "behavior": "pack_hunter",
    },
    "骷髅法师": {
        "role": "mage",
        "cr": 1,
        "max_hp": 18,
        "armor_class": 12,
        "attack_bonus": 3,
        "damage": "1d10",
        "spell_list": ["魔法飞弹", "护盾术"],
        "behavior": "cowardly",
    },
    "食尸鬼": {
        "role": "warrior",
        "cr": 1,
        "max_hp": 22,
        "armor_class": 13,
        "attack_bonus": 5,
        "damage": "2d4+3",
        "special_abilities": ["paralytic_claw"],
        "behavior": "relentless",
    },
    "牛头人": {
        "role": "boss",
        "cr": 3,
        "max_hp": 47,
        "armor_class": 17,
        "attack_bonus": 6,
        "damage": "2d8+4",
        "special_abilities": ["charge", "reckless_attack"],
        "legendary_actions": 2,
        "behavior": "berserker",
    },
    "巨魔": {
        "role": "elite",
        "cr": 5,
        "max_hp": 84,
        "armor_class": 15,
        "attack_bonus": 7,
        "damage": "2d8+5",
        "special_abilities": ["regeneration"],
        "behavior": "aggressive",
    }
}
```

---

## 十二、战斗UI/文本生成

### 12.1 战斗状态显示

```python
class CombatDisplay:
    """战斗显示"""

    @classmethod
    def generate_battlefield_display(cls, combat_manager: CombatManager) -> str:
        """生成战场显示"""

        text = "⚔️ **战斗状态**\n"
        text += "━━━━━━━━━━━━━━━━━━━━\n\n"

        # 敌方站位
        text += "【敌方】\n"
        for pos in [1, 2, 3, 4]:
            unit = combat_manager.enemy_units.get(pos)
            if unit:
                hp_bar = cls._generate_hp_bar(unit.current_hp, unit.max_hp)
                status = "💀" if unit.is_dead else ("😵" if unit.is_unconscious else "⚔️")
                text += f"  {pos}号位 {status} {unit.name} {hp_bar}\n"
            else:
                text += f"  {pos}号位 [空]\n"

        text += "\n"

        # 我方站位
        text += "【我方】\n"
        for pos in [1, 2, 3, 4]:
            unit = combat_manager.ally_units.get(pos)
            if unit:
                hp_bar = cls._generate_hp_bar(unit.current_hp, unit.max_hp)
                status = "💀" if unit.is_dead else ("😵" if unit.is_unconscious else "🛡️")
                text += f"  {pos}号位 {status} {unit.name} {hp_bar}\n"
            else:
                text += f"  {pos}号位 [空]\n"

        # 当前回合信息
        if combat_manager.initiative_order:
            current = combat_manager.initiative_order[combat_manager.current_turn_index]
            text += f"\n**当前回合**: {current.name}\n"
            text += f"**回合数**: 第{combat_manager.round_number}轮\n"

        return text

    @staticmethod
    def _generate_hp_bar(current: int, maximum: int, length: int = 10) -> str:
        """生成HP条"""
        if maximum <= 0:
            return "[-----------]"

        ratio = current / maximum
        filled = int(ratio * length)
        empty = length - filled

        if ratio > 0.6:
            color = "🟢"
        elif ratio > 0.3:
            color = "🟡"
        else:
            color = "🔴"

        return f"{color}[{'█' * filled}{'░' * empty}] {current}/{maximum}"

    @classmethod
    def generate_action_menu(cls, unit: CombatUnit) -> str:
        """生成动作菜单"""
        text = f"**{unit.name}** - 选择动作\n"
        text += "━━━━━━━━━━━━━━━━━━━━\n"

        # 标准动作
        if not unit.action_used:
            text += "📌 **标准动作**:\n"
            text += "  1️⃣ 攻击 [attack]\n"
            text += "  2️⃣ 法术 [spell]\n"
            text += "  3️⃣ 防御 [defend]\n"
            text += "  4️⃣ 躲避 [dodge]\n"
            text += "  5️⃣ 换位 [swap]\n"
        else:
            text += "📌 标准动作已使用\n"

        # 附赠动作
        if not unit.bonus_action_used:
            text += "\n⚡ **附赠动作**:\n"
            text += "  6️⃣ 副手攻击 [offhand]\n"
            text += "  7️⃣ 药水 [potion]\n"
        else:
            text += "\n⚡ 附赠动作已使用\n"

        # 反应
        if unit.reaction_available:
            text += "\n🔄 **反应** 可用\n"
        else:
            text += "\n🔄 反应已使用\n"

        # 跳过
        text += "\n⏭️ 跳过回合 [skip]\n"

        return text
```

### 12.2 预设战斗文本模板

```python
COMBAT_TEXT_TEMPLATES = {
    "combat_start": [
        "⚔️ **战斗开始！**\n{alignment}\n{round_intro}",
        "🔥 **遭遇战！**\n{alignment}\n{round_intro}",
        "⚡ **危险降临！**\n{alignment}\n{round_intro}",
    ],
    "turn_start": [
        "**{unit}** 的回合 - 站位 {position}",
        "轮到 **{unit}** 行动 - {position}号位",
    ],
    "attack_hit": [
        "⚔️ **{attacker}** 命中 **{target}**！\n"
        "🎲 攻击: {attack_roll} vs AC {ac}\n"
        "💥 伤害: {damage}",
        "*{attacker}* 的武器划过，击中了 **{target}**！\n"
        "伤害: {damage}",
    ],
    "attack_miss": [
        "⚔️ **{attacker}** 的攻击未能命中 **{target}**！\n"
        "🎲 攻击: {attack_roll} vs AC {ac}",
        "*{target}* 闪避了 **{attacker}** 的攻击！",
    ],
    "attack_crit": [
        "💥 **暴击！** **{attacker}** 对 **{target}** 造成 {damage} 伤害！",
        "✨ **大成功！** **{attacker}** 重创 **{target}**！伤害: {damage}",
    ],
    "damage_taken": [
        "💔 **{target}** 受到 {damage} 点伤害！\n"
        "HP: {current_hp}/{max_hp}",
    ],
    "unconscious": [
        "😵 **{unit}** 倒下了！陷入昏迷状态！",
        "💀 **{unit}** 无法继续战斗！",
    ],
    "opportunity_attack": [
        "⚡ **借机攻击！** **{attacker}** 对正在移动的 **{target}** 发起攻击！\n"
        "💥 伤害: {damage}",
        "🔄 **{attacker}** 抓住了 **{target}** 的破绽！伤害: {damage}",
    ],
    "position_swap": [
        "🔄 **{unit}** 移动到 {new_position}号位",
        "↔️ **{unit}** 和 **{partner}** 交换了位置",
    ],
    "round_end": [
        "━━━ 第 {round} 轮结束 ━━━",
    ],
    "victory": [
        "🎉 **胜利！** 敌人全部被击败！\n"
        "获得奖励:\n"
        "  💰 金币: {gold}\n"
        "  ✨ 经验: {xp}\n"
        "  📦 掉落: {loot}",
        "🏆 **战斗胜利！** 所有敌人倒下！\n"
        "奖励: {gold} 金币, {xp} 经验",
    ],
    "defeat": [
        "☠️ **战斗失败...** 我方全灭...",
        "💔 **败北...** 队伍需要撤退...",
    ],
}
```

---

## 十三、LLM集成方案

### 13.1 LLM调用策略

```python
class LLMCombatIntegration:
    """LLM战斗集成"""

    # 关键场景触发LLM
    TRIGGER_SCENES = {
        "boss_intro": "BOSS战开场描述",
        "critical_hit": "暴击/大失败",
        "unconscious": "角色倒下",
        "victory": "战斗胜利",
        "defeat": "战斗失败",
        "round_climax": "每5轮的戏剧性描述",
        "special_ability": "使用特殊能力",
    }

    PROMPT_TEMPLATES = {
        "boss_intro": """
你是一位D&D 5e的DM。请为接下来的BOSS战写一段开场白。

BOSS信息:
- 名称: {boss_name}
- 挑战等级: {cr}
- 特点: {features}

场景氛围: {atmosphere}

要求:
- 50-100字
- 紧张刺激的氛围
- 符合D&D世界观
- 中文输出
""",
        "critical_hit": """
作为D&D 5e DM，请描述一场暴击场景。

攻击者: {attacker}
目标: {target}
伤害: {damage}
武器: {weapon}

要求:
- 30-50字
- 戏剧性描述
- 符合D&D风格
- 中文输出
""",
    }

    @classmethod
    async def generate_combat_text(cls, scene_type: str, context: Dict) -> str:
        """生成LLM战斗文本"""

        # 检查是否需要LLM
        if not cls._should_use_llm(scene_type, context):
            return ""  # 返回空，使用预设

        # 构建prompt
        prompt = cls.PROMPT_TEMPLATES.get(scene_type, "")
        if not prompt:
            return ""

        # 填充上下文
        formatted_prompt = prompt.format(**context)

        # 调用LLM
        try:
            response = await cls._call_llm(formatted_prompt)
            return response
        except Exception as e:
            logger.error(f"LLM调用失败: {e}")
            return ""  # 失败时使用预设

    @classmethod
    def _should_use_llm(cls, scene_type: str, context: Dict) -> bool:
        """判断是否使用LLM"""

        # 检查开关
        if not config.get("llm_enabled", True):
            return False

        # 特定场景强制LLM
        if scene_type in ["boss_intro", "victory", "defeat"]:
            return True

        # 随机触发（10%概率）
        if random.random() < 0.1:
            return True

        # 暴击/大失败高概率
        if scene_type == "critical_hit":
            return random.random() < 0.5

        return False

    @classmethod
    async def _call_llm(cls, prompt: str) -> str:
        """调用LLM API"""
        # 这里需要根据实际LLM接口实现
        # 示例使用OpenAI兼容API
        api_key = config.get("llm_api_key")
        endpoint = config.get("llm_endpoint", "https://api.openai.com/v1/chat/completions")

        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }

        payload = {
            "model": "gpt-3.5-turbo",
            "messages": [
                {"role": "system", "content": "你是一位D&D 5e的DM助手。"},
                {"role": "user", "content": prompt}
            ],
            "max_tokens": 200,
            "temperature": 0.8
        }

        async with aiohttp.ClientSession() as session:
            async with session.post(endpoint, json=payload, headers=headers) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    return data["choices"][0]["message"]["content"]
                else:
                    raise Exception(f"LLM API错误: {resp.status}")
```

---

## 十四、数据文件结构

### 14.1 怪物数据 JSON

```json
{
  "monsters": {
    "goblin": {
      "name_cn": "哥布林",
      "name_en": "Goblin",
      "role": "warrior",
      "cr": 0.25,
      "size": "小",
      "type": "类人怪物",
      "alignment": "中立邪恶",

      "stats": {
        "strength": 8,
        "dexterity": 14,
        "constitution": 10,
        "intelligence": 10,
        "wisdom": 8,
        "charisma": 8
      },

      "combat": {
        "max_hp": 7,
        "armor_class": 15,
        "speed": 30,
        "attack_bonus": 4,
        "damage": "1d6+2",
        "attack_range": "melee"
      },

      "behavior": {
        "script": "aggressive",
        "preferred_position": [1, 2],
        "target_priority": ["front_row", "low_hp"]
      },

      "abilities": ["暗处攻击"],

      "loot": {
        "xp": 50,
        "gold_range": [1, 10],
        "items": ["生锈匕首", "硬币"]
      }
    },

    "minotaur": {
      "name_cn": "牛头人",
      "name_en": "Minotaur",
      "role": "boss",
      "cr": 3,
      "size": "大型",
      "type": "怪物",
      "alignment": "中立邪恶",

      "stats": {
        "strength": 18,
        "dexterity": 11,
        "constitution": 16,
        "intelligence": 6,
        "wisdom": 16,
        "charisma": 9
      },

      "combat": {
        "max_hp": 47,
        "armor_class": 17,
        "speed": 40,
        "attack_bonus": 6,
        "damage": "2d8+4",
        "attack_range": "melee",
        "multiattack": true
      },

      "behavior": {
        "script": "berserker",
        "preferred_position": [1],
        "target_priority": ["front_row"],
        "special_abilities": ["冲锋", "鲁莽攻击"],
        "legendary_actions": 2
      },

      "abilities": ["冲锋", "蛮力冲撞", "追踪"],

      "loot": {
        "xp": 700,
        "gold_range": [15, 60],
        "items": ["巨斧", "牛角护符"]
      }
    }
  }
}
```

### 14.2 战斗配置 JSON

```json
{
  "combat_settings": {
    "turn_time_limit": 90,
    "short_rest_limit": 1,
    "rest_encounter_requirement": 1,

    "xp_multiplier": {
      "solo": 1.5,
      "small_party": 1.2,
      "full_party": 1.0
    },

    "difficulty_adjustment": {
      "easy": {"enemy_hp_mult": 0.75, "enemy_cr_mult": 0.8},
      "normal": {"enemy_hp_mult": 1.0, "enemy_cr_mult": 1.0},
      "hard": {"enemy_hp_mult": 1.5, "enemy_cr_mult": 1.2}
    }
  },

  "class_position_preference": {
    "front_row": ["战士", "野蛮人", "圣武士", "僧侣"],
    "middle_row": ["盗贼", "游侠", "德鲁伊"],
    "back_row": ["法师", "术士", "牧师", "吟游诗人", "奇械师"]
  }
}
```

---

## 十五、新增文件清单

| 序号 | 文件路径 | 职责 | 优先级 |
|------|----------|------|--------|
| 1 | `core/combat_manager.py` | 战斗管理器 | 🔴 高 |
| 2 | `core/position.py` | 站位系统 | 🔴 高 |
| 3 | `core/action_resolver.py` | 行动解析器 | 🔴 高 |
| 4 | `core/monster.py` | 怪物系统 | 🔴 高 |
| 5 | `core/death_save.py` | 死亡豁免 | 🔴 高 |
| 6 | `core/rest.py` | 休息系统 | 🟡 中 |
| 7 | `core/initiative.py` | 先攻系统 | 🔴 高 |
| 8 | `core/combat_display.py` | 战斗显示 | 🟡 中 |
| 9 | `data/monster_data.json` | 怪物数据 | 🔴 高 |
| 10 | `data/combat_config.json` | 战斗配置 | 🟡 中 |
| 11 | `core/llm_combat.py` | LLM集成 | 🟡 中 |

---

## 十六、实现优先级

### 第一阶段：核心战斗框架（v0.4.0-alpha）

| 序号 | 任务 | 优先级 | 依赖 |
|------|------|--------|------|
| 1 | 重构 `core/combat.py` → `combat_manager.py` | 🔴 高 | - |
| 2 | 实现站位系统 `position.py` | 🔴 高 | - |
| 3 | 实现先攻排序 `initiative.py` | 🔴 高 | 任务1 |
| 4 | 实现行动解析器 `action_resolver.py` | 🔴 高 | 任务2 |
| 5 | 实现死亡豁免 `death_save.py` | 🔴 高 | - |
| 6 | 添加战斗指令 `/dnd 战斗开始/攻击/换位` | 🔴 高 | 任务1-5 |

### 第二阶段：怪物系统（v0.4.0-beta）

| 序号 | 任务 | 优先级 | 依赖 |
|------|------|--------|------|
| 7 | 创建怪物数据 `monster_data.json` | 🔴 高 | - |
| 8 | 实现怪物类 `monster.py` | 🔴 高 | - |
| 9 | 实现怪物AI行为脚本 | 🔴 高 | 任务8 |
| 10 | 实现休息系统 `rest.py` | 🟡 中 | - |
| 11 | 添加法术施放指令 | 🟡 中 | 任务4 |

### 第三阶段：UI与LLM（v0.4.0）

| 序号 | 任务 | 优先级 | 依赖 |
|------|------|--------|------|
| 12 | 实现战斗显示 `combat_display.py` | 🟡 中 | 任务1 |
| 13 | 实现LLM集成 `llm_combat.py` | 🟡 中 | - |
| 14 | 创建战斗配置 `combat_config.json` | 🟡 中 | - |
| 15 | 完善文档和测试 | 🟡 中 | 任务1-14 |

---

## 十七、验收标准

### 17.1 功能验收

- [ ] `/dnd 战斗开始` 正确开启战斗
- [ ] 4号位站位系统正确显示和运行
- [ ] 攻击范围绑定于技能/武器（而非职业）
  - [ ] 近战武器/技能只能攻击1-2号位
  - [ ] 远程武器可攻击1-4号位
  - [ ] 法术可攻击1-4号位
  - [ ] 突进技能可攻击3-4号位
  - [ ] 战士冲锋可以攻击后排（突破近战限制）
  - [ ] 法师闪现可以攻击后排（突破近战限制）
- [ ] 空位穿透逻辑正确工作
  - [ ] 死亡单位位置保留（尸体占位）
  - [ ] 近战攻击1号位时空位自动穿透到2号位
  - [ ] 1、2号位都死亡时穿透到3号位
  - [ ] 近战无法直接攻击4号位（除非1-3号位全空）
  - [ ] 复活时角色回到原始位置号
- [ ] 换位动作正确执行
- [ ] 借机攻击在适当条件触发
- [ ] 倒地角色进入昏迷状态
- [ ] 死亡豁免正确计算
- [ ] 短休/长休正确恢复资源
- [ ] 怪物按预设行为脚本行动
- [ ] 预设战斗文本正确显示
- [ ] LLM在关键场景正确调用

### 17.2 技术验收

- [ ] 所有D&D数值计算正确
- [ ] 战斗状态正确持久化
- [ ] 回合倒计时正常工作
- [ ] 错误处理完善
- [ ] 代码注释完整
- [ ] 无Python错误

### 17.3 体验验收

- [ ] 战斗流程流畅
- [ ] 文本描述清晰
- [ ] 指令响应及时
- [ ] 单人/组队模式正常

---

**文档版本**: v1.0
**最后更新**: 2026-05-10
**维护者**: MagicalYu
**下一步行动**: 等待用户确认计划，开始第一阶段开发
