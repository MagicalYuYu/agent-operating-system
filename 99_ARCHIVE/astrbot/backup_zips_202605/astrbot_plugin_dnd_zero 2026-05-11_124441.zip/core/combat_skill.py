"""
D&D/Zero 战斗技能系统
技能定义、攻击范围、技能效果
"""
from dataclasses import dataclass, field
from typing import List, Optional, Dict, Tuple, Any
from .combat_position import AttackRange, MELEE_RANGE, RANGED_RANGE, PIERCE_RANGE


@dataclass
class Skill:
    """战斗技能"""
    skill_id: str
    name: str
    name_cn: str
    skill_type: str = "attack"

    range: int = 2
    range_start: int = 1

    damage: str = "1d6"
    damage_type: str = "physical"

    action_type: str = "action"

    spell_level: int = 0
    spell_save_dc: int = 0
    spell_save_ability: str = ""

    required_position: any = None

    target_ally: bool = False
    heal: str = ""

    effect: str = ""
    effect_type: str = ""

    description: str = ""

    requires_attack: bool = True
    half_damage_on_save: bool = True

    def get_attack_range(self) -> AttackRange:
        """获取攻击范围对象"""
        return AttackRange(range=self.range, start=self.range_start)

    def can_use(self, unit: 'CombatUnit', target_position: int,
                alive_count: int) -> Tuple[bool, str]:
        """检查是否可以使用"""
        attack_range = self.get_attack_range()

        if not attack_range.can_attack(target_position, alive_count):
            return False, f"目标位置不可达"

        if self.required_position is not None:
            if isinstance(self.required_position, list):
                if unit.position not in self.required_position:
                    return False, f"需要站在 {self.required_position} 号位"
            else:
                if unit.position != self.required_position:
                    return False, f"需要站在 {self.required_position} 号位"

        return True, ""


SKILL_TEMPLATES = {
    "sword_attack": {
        "name": "Sword Attack",
        "name_cn": "挥剑攻击",
        "skill_type": "attack",
        "range": 2,
        "range_start": 1,
        "damage": "1d8",
        "damage_type": "physical",
        "action_type": "action",
        "requires_attack": True,
        "description": "使用近战武器进行攻击"
    },
    "bow_attack": {
        "name": "Bow Attack",
        "name_cn": "弓箭射击",
        "skill_type": "attack",
        "range": 4,
        "range_start": 1,
        "damage": "1d6",
        "damage_type": "physical",
        "action_type": "action",
        "requires_attack": True,
        "description": "使用弓弩进行远程攻击"
    },
    "unarmed_strike": {
        "name": "Unarmed Strike",
        "name_cn": "徒手攻击",
        "skill_type": "attack",
        "range": 2,
        "range_start": 1,
        "damage": "1d4",
        "damage_type": "physical",
        "action_type": "action",
        "requires_attack": True,
        "description": "徒手搏斗"
    },
    "charge": {
        "name": "Charge",
        "name_cn": "战士冲锋",
        "skill_type": "attack",
        "range": 2,
        "range_start": 3,
        "damage": "2d6",
        "damage_type": "physical",
        "action_type": "action",
        "requires_attack": True,
        "description": "突进到后排进行攻击"
    },
    "taunt": {
        "name": "Taunt",
        "name_cn": "嘲讽",
        "skill_type": "effect",
        "range": 4,
        "range_start": 1,
        "action_type": "action",
        "required_position": 1,
        "effect": "taunt_all",
        "effect_type": "debuff",
        "description": "强制所有敌人攻击自己"
    },
    "shield_bash": {
        "name": "Shield Bash",
        "name_cn": "盾牌猛击",
        "skill_type": "attack",
        "range": 2,
        "range_start": 1,
        "damage": "1d6+str",
        "damage_type": "physical",
        "action_type": "action",
        "required_position": [1, 2],
        "requires_attack": True,
        "description": "用盾牌猛击敌人"
    },
    "healing_word": {
        "name": "Healing Word",
        "name_cn": "治愈真言",
        "skill_type": "heal",
        "range": 4,
        "range_start": 1,
        "heal": "1d4",
        "action_type": "bonus_action",
        "target_ally": True,
        "description": "治疗一个盟友"
    },
    "cure_wounds": {
        "name": "Cure Wounds",
        "name_cn": "疗伤术",
        "skill_type": "heal",
        "range": 2,
        "range_start": 1,
        "heal": "1d8",
        "action_type": "action",
        "target_ally": True,
        "description": "治疗目标"
    },
    "fireball": {
        "name": "Fireball",
        "name_cn": "火球术",
        "skill_type": "attack",
        "range": 4,
        "range_start": 1,
        "damage": "8d6",
        "damage_type": "fire",
        "action_type": "action",
        "spell_level": 3,
        "spell_save_dc": 15,
        "spell_save_ability": "dexterity",
        "requires_attack": False,
        "half_damage_on_save": True,
        "description": "区域内所有敌人进行敏捷豁免"
    },
    "lightning_bolt": {
        "name": "Lightning Bolt",
        "name_cn": "闪电束",
        "skill_type": "attack",
        "range": 4,
        "range_start": 1,
        "damage": "8d6",
        "damage_type": "lightning",
        "action_type": "action",
        "spell_level": 3,
        "spell_save_dc": 15,
        "spell_save_ability": "dexterity",
        "requires_attack": False,
        "half_damage_on_save": True,
        "description": "线型区域内所有敌人进行敏捷豁免"
    },
    "magic_missile": {
        "name": "Magic Missile",
        "name_cn": "魔法飞弹",
        "skill_type": "attack",
        "range": 4,
        "range_start": 1,
        "damage": "3d4+3",
        "damage_type": "force",
        "action_type": "action",
        "spell_level": 1,
        "requires_attack": True,
        "description": "发射魔法飞弹攻击目标"
    },
    "fire_bolt": {
        "name": "Fire Bolt",
        "name_cn": "火焰箭",
        "skill_type": "attack",
        "range": 4,
        "range_start": 1,
        "damage": "1d10",
        "damage_type": "fire",
        "action_type": "action",
        "spell_level": 0,
        "requires_attack": True,
        "description": "投掷火焰攻击目标"
    },
    "shield": {
        "name": "Shield",
        "name_cn": "护盾术",
        "skill_type": "buff",
        "range": 0,
        "range_start": 0,
        "action_type": "reaction",
        "spell_level": 1,
        "effect": "ac_bonus",
        "effect_type": "buff",
        "description": "AC获得+5加值"
    },
    "drag": {
        "name": "Drag",
        "name_cn": "拖拽",
        "skill_type": "effect",
        "range": 4,
        "range_start": 1,
        "action_type": "action",
        "effect": "pull",
        "effect_type": "crowd_control",
        "description": "将目标拉至3号位"
    },
    "offhand_attack": {
        "name": "Off-hand Attack",
        "name_cn": "副手攻击",
        "skill_type": "attack",
        "range": 2,
        "range_start": 1,
        "damage": "1d6",
        "damage_type": "physical",
        "action_type": "bonus_action",
        "requires_attack": True,
        "description": "副手武器攻击"
    },
    "dash": {
        "name": "Dash",
        "name_cn": "冲刺",
        "skill_type": "movement",
        "range": 2,
        "range_start": 3,
        "action_type": "action",
        "description": "突进到后排"
    },
    "swap_position": {
        "name": "Swap Position",
        "name_cn": "换位",
        "skill_type": "movement",
        "range": 0,
        "range_start": 0,
        "action_type": "movement",
        "effect": "swap",
        "description": "与队友交换位置"
    }
}


class SkillDatabase:
    """技能数据库"""

    @classmethod
    def get_skill(cls, skill_id: str) -> Optional[Skill]:
        """获取技能"""
        template = SKILL_TEMPLATES.get(skill_id)
        if not template:
            return None

        return Skill(
            skill_id=skill_id,
            name=template["name"],
            name_cn=template["name_cn"],
            skill_type=template.get("skill_type", "attack"),
            range=template.get("range", 2),
            range_start=template.get("range_start", 1),
            damage=template.get("damage", "1d6"),
            damage_type=template.get("damage_type", "physical"),
            action_type=template.get("action_type", "action"),
            spell_level=template.get("spell_level", 0),
            spell_save_dc=template.get("spell_save_dc", 0),
            spell_save_ability=template.get("spell_save_ability", ""),
            required_position=template.get("required_position"),
            target_ally=template.get("target_ally", False),
            heal=template.get("heal", ""),
            effect=template.get("effect", ""),
            effect_type=template.get("effect_type", ""),
            description=template.get("description", ""),
            requires_attack=template.get("requires_attack", True),
            half_damage_on_save=template.get("half_damage_on_save", True)
        )

    @classmethod
    def get_all_skills(cls) -> List[Skill]:
        """获取所有技能"""
        return [cls.get_skill(sid) for sid in SKILL_TEMPLATES.keys()]

    @classmethod
    def get_skills_by_action_type(cls, action_type: str) -> List[Skill]:
        """按动作类型获取技能"""
        skills = []
        for sid, template in SKILL_TEMPLATES.items():
            if template.get("action_type") == action_type:
                skill = cls.get_skill(sid)
                if skill:
                    skills.append(skill)
        return skills

    @classmethod
    def get_skills_by_class(cls, class_name: str) -> Dict[str, List[Skill]]:
        """按职业获取可用技能"""
        class_skills = {
            "战士": ["sword_attack", "charge", "taunt", "shield_bash", "offhand_attack"],
            "法师": ["magic_missile", "fireball", "lightning_bolt", "fire_bolt", "shield"],
            "盗贼": ["sword_attack", "offhand_attack", "unarmed_strike"],
            "牧师": ["cure_wounds", "healing_word", "shield"],
            "游侠": ["bow_attack", "magic_missile"],
            "野蛮人": ["sword_attack", "charge"],
            "德鲁伊": ["cure_wounds", "healing_word", "fireball"],
            "术士": ["magic_missile", "firebolt"],
            "吟游诗人": ["healing_word", "cure_wounds"],
            "圣武士": ["sword_attack", "cure_wounds", "shield"],
            "僧侣": ["unarmed_strike", "dash"]
        }

        skill_ids = class_skills.get(class_name, ["sword_attack", "unarmed_strike"])
        return [cls.get_skill(sid) for sid in skill_ids if cls.get_skill(sid)]

    @classmethod
    def get_default_attack(cls, class_name: str) -> str:
        """获取职业默认攻击技能"""
        default_attacks = {
            "战士": "sword_attack",
            "法师": "magic_missile",
            "盗贼": "sword_attack",
            "牧师": "cure_wounds",
            "游侠": "bow_attack",
            "野蛮人": "sword_attack",
            "德鲁伊": "cure_wounds",
            "术士": "magic_missile",
            "吟游诗人": "healing_word",
            "圣武士": "sword_attack",
            "僧侣": "unarmed_strike",
            "奇械师": "magic_missile"
        }

        return default_attacks.get(class_name, "sword_attack")
