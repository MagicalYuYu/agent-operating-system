"""
商店系统模块 - 管理商店商品和交易逻辑
"""
import json
import random
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional
from pathlib import Path


@dataclass
class ShopItem:
    """商店商品"""
    item_id: str
    name: str
    price: int
    item_type: str
    rarity: str = "common"
    description: str = ""
    effects: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ShopCategory:
    """商店分类"""
    category_id: str
    name: str
    items: List[ShopItem] = field(default_factory=list)


class ShopDatabase:
    """商店数据库"""

    def __init__(self, data_path: Optional[str] = None):
        self.data_path = data_path or self._get_default_data_path()
        self.categories: Dict[str, ShopCategory] = {}
        self.all_items: Dict[str, ShopItem] = {}
        self._load_data()

    def _get_default_data_path(self) -> str:
        """获取默认数据路径"""
        current_dir = Path(__file__).parent.parent
        return str(current_dir / "data" / "shop_data.json")

    def _load_data(self) -> None:
        """加载商店数据"""
        try:
            with open(self.data_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            self._parse_data(data)
        except FileNotFoundError:
            self._init_default_data()
        except json.JSONDecodeError as e:
            raise ValueError(f"商店数据 JSON 解析错误: {e}")

    def _init_default_data(self) -> None:
        """初始化默认商店数据"""
        self.categories = {
            "weapon": ShopCategory(
                category_id="weapon",
                name="🗡️ 武器"
            ),
            "armor": ShopCategory(
                category_id="armor",
                name="🛡️ 防具"
            ),
            "potion": ShopCategory(
                category_id="potion",
                name="🧪 药水"
            ),
            "scroll": ShopCategory(
                category_id="scroll",
                name="📜 卷轴"
            ),
            "misc": ShopCategory(
                category_id="misc",
                name="📦 杂货"
            )
        }

        self._init_default_items()

    def _init_default_items(self) -> None:
        """初始化默认商品"""
        default_items = {
            "weapon": [
                {"item_id": "weapon_dagger", "name": "匕首", "price": 50, "description": "轻便的近战武器", "rarity": "common"},
                {"item_id": "weapon_short_sword", "name": "短剑", "price": 100, "description": "标准的近战武器", "rarity": "common"},
                {"item_id": "weapon_long_sword", "name": "长剑", "price": 200, "description": "长剑，战士的最爱", "rarity": "common"},
                {"item_id": "weapon_great_sword", "name": "巨剑", "price": 400, "description": "需要双手使用的重型武器", "rarity": "uncommon"},
                {"item_id": "weapon_shortbow", "name": "短弓", "price": 80, "description": "基础的远程武器", "rarity": "common"},
                {"item_id": "weapon_longbow", "name": "长弓", "price": 150, "description": "高精度远程武器", "rarity": "uncommon"},
                {"item_id": "weapon_rapier", "name": "细剑", "price": 250, "description": "轻巧而锋利", "rarity": "uncommon"},
                {"item_id": "weapon_enchanted_sword", "name": "附魔长剑", "price": 500, "description": "+1 攻击加成的魔法武器", "rarity": "rare"},
            ],
            "armor": [
                {"item_id": "armor_padded", "name": "软甲", "price": 100, "description": "基础护甲", "rarity": "common"},
                {"item_id": "armor_leather", "name": "皮甲", "price": 150, "description": "轻便的皮制护甲", "rarity": "common"},
                {"item_id": "armor_studded", "name": "铆钉皮甲", "price": 200, "description": "防护更好的皮甲", "rarity": "uncommon"},
                {"item_id": "armor_chain", "name": "链甲", "price": 400, "description": "金属环编织的护甲", "rarity": "uncommon"},
                {"item_id": "armor_scale", "name": "鳞甲", "price": 500, "description": "鳞片覆盖的护甲", "rarity": "rare"},
                {"item_id": "armor_plate", "name": "板甲", "price": 1000, "description": "重型全身护甲", "rarity": "rare"},
                {"item_id": "armor_shield", "name": "盾牌", "price": 150, "description": "提供额外 +2 AC", "rarity": "common"},
            ],
            "potion": [
                {"item_id": "potion_small", "name": "小血瓶", "price": 20, "description": "恢复 1d4+1 HP", "rarity": "common"},
                {"item_id": "potion_medium", "name": "中血瓶", "price": 50, "description": "恢复 2d4+2 HP", "rarity": "uncommon"},
                {"item_id": "potion_large", "name": "大血瓶", "price": 100, "description": "恢复 4d4+4 HP", "rarity": "rare"},
                {"item_id": "potion_antidote", "name": "解毒药水", "price": 30, "description": "解除中毒状态", "rarity": "uncommon"},
                {"item_id": "potion_strength", "name": "蛮力药水", "price": 80, "description": "力量暂时 +2", "rarity": "rare"},
                {"item_id": "potion_invisibility", "name": "隐身药水", "price": 200, "description": "隐身 1 小时", "rarity": "very_rare"},
            ],
            "scroll": [
                {"item_id": "scroll_cure_wounds", "name": "治疗卷轴", "price": 30, "description": "施放治疗术", "rarity": "uncommon"},
                {"item_id": "scroll_shield", "name": "护盾卷轴", "price": 40, "description": "施放护盾术", "rarity": "uncommon"},
                {"item_id": "scroll_fireball", "name": "火球术卷轴", "price": 150, "description": "施放火球术", "rarity": "rare"},
                {"item_id": "scroll_lightning", "name": "闪电束卷轴", "price": 120, "description": "施放闪电束", "rarity": "rare"},
            ],
            "misc": [
                {"item_id": "misc_rope", "name": "绳索（50尺）", "price": 5, "description": "攀爬、捆绑必备", "rarity": "common"},
                {"item_id": "misc_torch", "name": "火把", "price": 1, "description": "照明 1 小时", "rarity": "common"},
                {"item_id": "misc_rations", "name": "口粮（5天）", "price": 10, "description": "野外生存必备", "rarity": "common"},
                {"item_id": "misc_thieves_tools", "name": "陷阱工具", "price": 50, "description": "探测和解除陷阱", "rarity": "uncommon"},
                {"item_id": "misc_grappling_hook", "name": "抓钩", "price": 10, "description": "攀爬工具", "rarity": "common"},
                {"item_id": "misc_lantern", "name": "灯笼", "price": 15, "description": "长时间照明", "rarity": "common"},
                {"item_id": "misc_backpack", "name": "背包", "price": 20, "description": "增加背包容量", "rarity": "common"},
            ]
        }

        for category_id, items in default_items.items():
            for item_data in items:
                item = ShopItem(
                    item_id=item_data["item_id"],
                    name=item_data["name"],
                    price=item_data["price"],
                    item_type=category_id,
                    rarity=item_data.get("rarity", "common"),
                    description=item_data.get("description", "")
                )
                self.all_items[item.item_id] = item
                if category_id in self.categories:
                    self.categories[category_id].items.append(item)

    def _parse_data(self, data: dict) -> None:
        """解析商店数据"""
        for category_id, category_data in data.get("categories", {}).items():
            items = []
            for item_data in category_data.get("items", []):
                item = ShopItem(
                    item_id=item_data.get("item_id", ""),
                    name=item_data.get("name", ""),
                    price=item_data.get("price", 0),
                    item_type=category_id,
                    rarity=item_data.get("rarity", "common"),
                    description=item_data.get("description", ""),
                    effects=item_data.get("effects", {})
                )
                self.all_items[item.item_id] = item
                items.append(item)

            self.categories[category_id] = ShopCategory(
                category_id=category_id,
                name=category_data.get("name", ""),
                items=items
            )

    def get_category(self, category_id: str) -> Optional[ShopCategory]:
        """获取指定分类"""
        return self.categories.get(category_id)

    def get_all_categories(self) -> List[ShopCategory]:
        """获取所有分类"""
        return list(self.categories.values())

    def get_item(self, item_id: str) -> Optional[ShopItem]:
        """根据 ID 获取商品"""
        return self.all_items.get(item_id)

    def get_item_by_name(self, name: str) -> Optional[ShopItem]:
        """根据名称获取商品"""
        for item in self.all_items.values():
            if item.name == name or name in item.name:
                return item
        return None

    def get_items_by_category(self, category_id: str) -> List[ShopItem]:
        """获取指定分类的所有商品"""
        category = self.categories.get(category_id)
        if not category:
            return []
        return category.items

    def search_items(self, keyword: str) -> List[ShopItem]:
        """搜索商品"""
        results = []
        for item in self.all_items.values():
            if keyword.lower() in item.name.lower() or keyword.lower() in item.description.lower():
                results.append(item)
        return results

    def can_afford(self, player_gold: int, item_price: int) -> bool:
        """检查玩家是否能购买"""
        return player_gold >= item_price

    def buy_item(self, player_gold: int, item_name: str) -> Dict[str, Any]:
        """购买商品

        Args:
            player_gold: 玩家当前金币
            item_name: 商品名称

        Returns:
            购买结果
        """
        item = self.get_item_by_name(item_name)
        if not item:
            return {
                "success": False,
                "message": f"商店没有「{item_name}」这件商品"
            }

        if not self.can_afford(player_gold, item.price):
            return {
                "success": False,
                "message": f"金币不足！「{item.name}」需要 {item.price} 金币，你只有 {player_gold} 金币"
            }

        return {
            "success": True,
            "message": f"成功购买「{item.name}」！花费 {item.price} 金币",
            "item": {
                "item_id": item.item_id,
                "name": item.name,
                "item_type": item.item_type,
                "rarity": item.rarity,
                "description": item.description
            },
            "cost": item.price
        }


class ShopSystem:
    """商店系统"""

    def __init__(self, shop_database: Optional[ShopDatabase] = None):
        self.db = shop_database or ShopDatabase()

    def get_shop_menu(self) -> str:
        """获取商店主菜单"""
        categories = self.db.get_all_categories()

        category_lines = []
        for category in categories:
            count = len(category.items)
            category_lines.append(f"  {category.name}（{count} 件商品）")

        categories_text = "\n".join(category_lines)

        return f"""
{'='*60}
              🛒 南区集市 · 商店
{'='*60}

欢迎光临南区集市！这里有各种商品出售...

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

{categories_text}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

💡 发送 /dnd 商店 分类 <类型> 查看商品
   例如：/dnd 商店 分类 武器

💰 发送 /dnd 商店 购买 <物品名> 购买物品
   例如：/dnd 商店 购买 短剑
"""

    def get_category_menu(self, category_id: str) -> str:
        """获取分类商品菜单

        Args:
            category_id: 分类 ID

        Returns:
            分类菜单文本
        """
        category = self.db.get_category(category_id)
        if not category:
            valid_categories = [c.category_id for c in self.db.get_all_categories()]
            return f"❌ 无效的分类！\n\n有效分类：{', '.join(valid_categories)}"

        rarity_emojis = {
            "common": "⚪",
            "uncommon": "🟢",
            "rare": "🔵",
            "very_rare": "🟣",
            "legendary": "🟡"
        }

        item_lines = []
        for item in category.items:
            emoji = rarity_emojis.get(item.rarity, "⚪")
            price_text = f"{item.price} 💰"
            item_lines.append(f"  {emoji} {item.name} - {price_text}\n     {item.description}")

        items_text = "\n\n".join(item_lines)

        return f"""
{'='*60}
              {category.name}
{'='*60}

{items_text}

{'='*60}
"""

    def get_item_detail(self, item_name: str) -> str:
        """获取商品详情

        Args:
            item_name: 商品名称

        Returns:
            商品详情文本
        """
        item = self.db.get_item_by_name(item_name)
        if not item:
            return f"❌ 未找到商品「{item_name}」"

        rarity_emojis = {
            "common": "⚪ 普通",
            "uncommon": "🟢 优秀",
            "rare": "🔵 稀有",
            "very_rare": "🟣 非常稀有",
            "legendary": "🟡 传说"
        }

        rarity_text = rarity_emojis.get(item.rarity, item.rarity)

        return f"""
{'='*60}
              🛒 {item.name}
{'='*60}

📦 类型：{item.item_type}
⭐ 品质：{rarity_text}
💰 价格：{item.price} 金币

📝 描述：
  {item.description}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

💡 发送 /dnd 商店 购买 {item.name} 购买此商品
"""

    def process_purchase(self, player_gold: int, item_name: str) -> Dict[str, Any]:
        """处理购买请求

        Args:
            player_gold: 玩家金币
            item_name: 商品名称

        Returns:
            购买结果
        """
        result = self.db.buy_item(player_gold, item_name)

        if result["success"]:
            result["remaining_gold"] = player_gold - result["cost"]

        return result

    def get_shop_dialogue(self) -> str:
        """获取商店对话"""
        dialogues = [
            "哟，客人来了！看看有什么需要的？",
            "这可是好东西，用得着的！",
            "价格公道，童叟无欺！",
            "新到的货，昨天刚到！",
            "挑花了眼？让我给你推荐推荐！"
        ]
        return random.choice(dialogues)
