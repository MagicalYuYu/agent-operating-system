# DND/TRPG 插件 Demo 版本实施计划

> **项目名称**: astrbot_plugin_dnd_zero  
> **版本**: v0.1.0 Demo  
> **创建日期**: 2026-05-09  
> **状态**: 实施中

---

## 📋 一、实施范围

### 核心功能（Demo v0.1.0）

| 模块 | 功能 | 优先级 | 状态 |
|------|------|--------|------|
| **数据层** | 5etools中文站数据加载 | ⭐⭐⭐⭐⭐ | 🔄 进行中 |
| **D20系统** | 掷骰核心引擎 | ⭐⭐⭐⭐⭐ | 🔄 进行中 |
| **角色系统** | 创建、属性、职业、种族 | ⭐⭐⭐⭐⭐ | 🔄 进行中 |
| **检定系统** | 攻击、技能、豁免 | ⭐⭐⭐⭐⭐ | 🔄 进行中 |
| **战斗系统** | 回合制战斗流程 | ⭐⭐⭐⭐ | 🔄 进行中 |
| **指令系统** | /dnd 命令集 | ⭐⭐⭐⭐⭐ | 🔄 进行中 |

---

## 🎯 二、技术架构

### 2.1 项目结构

```
astrbot_plugin_dnd_zero/
├── main.py                      # 插件主入口 ⭐
├── core/                        # 核心逻辑
│   ├── __init__.py
│   ├── dice.py                 # D20掷骰引擎 ⭐
│   ├── character.py            # 角色系统 ⭐
│   ├── skill.py                # 技能检定 ⭐
│   ├── combat.py               # 战斗系统 ⭐
│   └── spell.py                # 法术系统
├── data/                        # 数据层
│   ├── loader.py               # 5etools数据加载器 ⭐
│   ├── srd/                    # SRD数据
│   │   ├── classes.json
│   │   ├── races.json
│   │   └── spells/
│   └── cache/                  # 本地缓存
├── features/                    # 功能模块
│   ├── party.py                # 组队系统
│   └── quest.py                # 冒险系统
├── hooks/                      # 钩子
│   └── llm_dm.py               # LLM DM集成
└── utils/                      # 工具
    ├── __init__.py
    └── formatter.py            # 格式化工具
```

### 2.2 核心技术栈

| 组件 | 选择 | 理由 |
|------|------|------|
| **主语言** | Python 3.10+ | AstrBot框架要求 |
| **HTTP客户端** | httpx | 异步、推荐使用 |
| **数据格式** | JSON | 轻量、易解析 |
| **数据源** | 5etools中文站 | 中文、免费、完整 |

---

## 🔧 三、核心模块实现

### 3.1 D20掷骰引擎 (`core/dice.py`)

```python
class DiceRoller:
    """D20系统掷骰引擎"""
    
    @staticmethod
    def roll_d20() -> int:
        """标准D20掷骰"""
        return random.randint(1, 20)
    
    @staticmethod
    def roll_attack(attack_bonus: int) -> AttackResult:
        """攻击检定"""
        roll = DiceRoller.roll_d20()
        is_crit = (roll == 20)
        total = roll + attack_bonus
        
        return AttackResult(
            roll=roll,
            bonus=attack_bonus,
            total=total,
            critical=is_crit,
            fumble=(roll == 1)
        )
    
    @staticmethod
    def roll_damage(dice_count: int, dice_type: int, modifier: int = 0) -> DamageResult:
        """伤害掷骰"""
        rolls = [random.randint(1, dice_type) for _ in range(dice_count)]
        total = sum(rolls) + modifier
        
        return DamageResult(
            rolls=rolls,
            modifier=modifier,
            total=total,
            crit=(dice_count > 1)  # 多骰子时为暴击伤害
        )
```

### 3.2 角色系统 (`core/character.py`)

```python
@dataclass
class AbilityScores:
    """属性值"""
    strength: int = 10
    dexterity: int = 10
    constitution: int = 10
    intelligence: int = 10
    wisdom: int = 10
    charisma: int = 10
    
    def get_modifier(self, ability: str) -> int:
        """计算属性调整值"""
        value = getattr(self, ability)
        return (value - 10) // 2

@dataclass
class Character:
    """角色"""
    name: str
    player_id: str
    level: int = 1
    experience: int = 0
    
    # 属性
    abilities: AbilityScores = field(default_factory=AbilityScores)
    
    # 职业与种族
    class_name: str = ""
    subclass: str = ""
    race: str = ""
    
    # 战斗属性
    hit_points: int = 10
    max_hit_points: int = 10
    armor_class: int = 10
    
    # 熟练项
    proficiency_bonus: int = 2
    saving_throws: List[str] = field(default_factory=list)
    skills: List[str] = field(default_factory=list)
    
    # 装备与法术
    equipment: List[Equipment] = field(default_factory=list)
    spells: List[str] = field(default_factory=list)
```

### 3.3 技能检定 (`core/skill.py`)

```python
class SkillChecker:
    """技能检定系统"""
    
    SKILL_ABILITY_MAP = {
        "athletics": "strength",
        "acrobatics": "dexterity",
        "sleight_of_hand": "dexterity",
        "stealth": "dexterity",
        "arcana": "intelligence",
        "history": "intelligence",
        "investigation": "intelligence",
        "nature": "intelligence",
        "religion": "intelligence",
        "animal_handling": "wisdom",
        "insight": "wisdom",
        "medicine": "wisdom",
        "perception": "wisdom",
        "survival": "wisdom",
        "deception": "charisma",
        "intimidation": "charisma",
        "performance": "charisma",
        "persuasion": "charisma"
    }
    
    def roll_skill_check(
        self,
        character: Character,
        skill: str,
        advantage: bool = False,
        disadvantage: bool = False,
        dc: int = None
    ) -> SkillCheckResult:
        """执行技能检定"""
        # 获取属性调整值
        ability = self.SKILL_ABILITY_MAP.get(skill.lower())
        ability_mod = character.abilities.get_modifier(ability)
        
        # 熟练加值
        proficiency = character.proficiency_bonus if skill in character.skills else 0
        
        # 掷骰
        roll1 = DiceRoller.roll_d20()
        roll2 = DiceRoller.roll_d20() if advantage or disadvantage else None
        
        if advantage and not disadvantage:
            roll = max(roll1, roll2)
        elif disadvantage and not advantage:
            roll = min(roll1, roll2)
        else:
            roll = roll1
        
        total = roll + ability_mod + proficiency
        
        # 判断结果
        success = (dc is None) or (total >= dc)
        
        return SkillCheckResult(
            skill=skill,
            roll=roll,
            ability_mod=ability_mod,
            proficiency=proficiency,
            total=total,
            dc=dc,
            success=success,
            natural_20=(roll == 20),
            natural_1=(roll == 1)
        )
```

### 3.4 战斗系统 (`core/combat.py`)

```python
class CombatSystem:
    """D&D 5e 战斗系统"""
    
    def __init__(self, data_loader: FiveEToolsLoader):
        self.data = data_loader
    
    def calculate_ac(self, character: Character) -> int:
        """计算护甲等级"""
        base = 10
        dex_mod = character.abilities.get_modifier("dexterity")
        armor_bonus = sum(eq.bonus_ac for eq in character.equipment if eq.type == "armor")
        
        return base + dex_mod + armor_bonus
    
    def process_attack(
        self,
        attacker: Character,
        defender: Character,
        weapon: Equipment,
        advantage: bool = False,
        disadvantage: bool = False
    ) -> CombatResult:
        """处理攻击流程"""
        # 攻击检定
        attack_roll = DiceRoller.roll_attack(weapon.attack_bonus)
        
        # 优势/劣势
        if advantage or disadvantage:
            roll1 = DiceRoller.roll_d20()
            roll2 = DiceRoller.roll_d20()
            if advantage and not disadvantage:
                attack_roll.roll = max(roll1, roll2)
            elif disadvantage and not advantage:
                attack_roll.roll = min(roll1, roll2)
        
        # 命中判定
        defender_ac = self.calculate_ac(defender)
        hit = attack_roll.roll == 20 or attack_roll.roll == 1 or attack_roll.total >= defender_ac
        
        if not hit:
            return CombatResult.MISS
        
        # 伤害计算
        damage_result = DiceRoller.roll_damage(
            weapon.damage_count,
            weapon.damage_die,
            weapon.damage_bonus
        )
        
        # 暴击
        if attack_roll.roll == 20:
            crit_damage = DiceRoller.roll_damage(
                weapon.damage_count,
                weapon.damage_die
            )
            damage_result.total += crit_damage.total
        
        # 应用伤害
        defender.hit_points -= damage_result.total
        
        return CombatResult.HIT(
            damage=damage_result.total,
            attack_roll=attack_roll,
            critical=(attack_roll.roll == 20),
            remaining_hp=defender.hit_points
        )
```

---

## 📡 四、指令系统设计

### 4.1 命令列表

| 命令 | 功能 | 示例 |
|------|------|------|
| `/dnd help` | 显示帮助菜单 | `/dnd help` |
| `/dnd create` | 创建角色 | `/dnd create` |
| `/dnd status` | 查看角色状态 | `/dnd status` |
| `/dnd roll` | 掷骰 | `/dnd roll d20` |
| `/dnd skill` | 技能检定 | `/dnd skill athletics` |
| `/dnd attack` | 攻击 | `/dnd attack goblin` |
| `/dnd cast` | 施法 | `/dnd cast fireball` |

### 4.2 实现示例

```python
@filter.command_group("dnd")
def dnd(self):
    """DND指令组"""
    pass

@dnd.command("create")
@filter.event_message_type(filter.EventMessageType.GROUP_MESSAGE)
async def create_character(self, event: AstrMessageEvent):
    """创建角色"""
    user_id = event.get_sender_id()
    
    # 交互式角色创建
    yield event.plain_result("🎭 欢迎创建角色！")
    yield event.plain_result("请选择种族：1. 人类 2. 精灵 3. 矮人")
    
    # ... 完整交互逻辑

@dnd.command("roll")
@filter.event_message_type(filter.EventMessageType.GROUP_MESSAGE)
async def roll_dice(self, event: AstrMessageEvent, dice: str = "d20"):
    """掷骰"""
    match = re.match(r'(\d*)d(\d+)', dice)
    if not match:
        yield event.plain_result("❌ 无效的骰子格式，请使用如 d20, 2d6 等格式")
        return
    
    count = int(match.group(1) or 1)
    sides = int(match.group(2))
    
    rolls = [random.randint(1, sides) for _ in range(count)]
    total = sum(rolls)
    
    result_text = f"🎲 掷 {count}d{sides}: [{', '.join(map(str, rolls))}] = {total}"
    yield event.plain_result(result_text)
```

---

## 📦 五、数据加载器实现

### 5.1 FiveEToolsLoader (`data/loader.py`)

```python
class FiveEToolsLoader:
    """5etools中文站数据加载器"""
    
    BASE_URL = "https://raw.githubusercontent.com/tjliqy/5etools-mirror-2.github.io/cn2.0/data"
    
    def __init__(self, cache_dir: Path):
        self.cache_dir = cache_dir
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self._cache = {}
    
    async def load_json(self, filename: str, force_refresh: bool = False) -> dict:
        """加载JSON数据（带缓存）"""
        cache_file = self.cache_dir / filename
        
        # 检查缓存
        if not force_refresh and cache_file.exists():
            with open(cache_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        
        # 从网络加载
        async with httpx.AsyncClient(timeout=30.0) as client:
            url = f"{self.BASE_URL}/{filename}"
            response = await client.get(url)
            data = response.json()
        
        # 保存缓存
        with open(cache_file, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        
        return data
    
    async def get_classes(self) -> dict:
        """获取职业数据"""
        return await self.load_json("classes.json")
    
    async def get_races(self) -> dict:
        """获取种族数据"""
        return await self.load_json("races.json")
    
    async def get_spells(self, level: int = None) -> dict:
        """获取法术数据"""
        if level is not None:
            return await self.load_json(f"spells/spelllist-{level}.json")
        else:
            return await self.load_json("spells.json")
    
    async def get_backgrounds(self) -> dict:
        """获取背景数据"""
        return await self.load_json("backgrounds.json")
    
    async def get_items(self) -> dict:
        """获取物品数据"""
        return await self.load_json("items.json")
```

---

## 🔄 六、实施步骤

### 阶段1：数据基础设施（今日完成）

| 步骤 | 任务 | 预估时间 | 状态 |
|------|------|---------|------|
| 1.1 | 创建 `data/` 目录结构 | 10分钟 | 🔄 |
| 1.2 | 实现 `data/loader.py` | 30分钟 | 🔄 |
| 1.3 | 测试数据加载器 | 20分钟 | 🔄 |

### 阶段2：核心逻辑（今日完成）

| 步骤 | 任务 | 预估时间 | 状态 |
|------|------|---------|------|
| 2.1 | 实现 `core/dice.py` | 30分钟 | 🔄 |
| 2.2 | 实现 `core/character.py` | 45分钟 | 🔄 |
| 2.3 | 实现 `core/skill.py` | 30分钟 | 🔄 |
| 2.4 | 实现 `core/combat.py` | 45分钟 | 🔄 |

### 阶段3：插件集成（今日完成）

| 步骤 | 任务 | 预估时间 | 状态 |
|------|------|---------|------|
| 3.1 | 更新 `main.py` | 30分钟 | 🔄 |
| 3.2 | 实现 `/dnd` 指令集 | 45分钟 | 🔄 |
| 3.3 | 测试完整流程 | 30分钟 | 🔄 |

---

## ✅ 七、验收标准

### 功能验收

- [ ] `/dnd help` - 显示帮助菜单 ✅
- [ ] `/dnd roll d20` - D20掷骰 ✅
- [ ] `/dnd create` - 角色创建流程 ✅
- [ ] `/dnd status` - 查看角色状态 ✅
- [ ] `/dnd skill athletics` - 技能检定 ✅
- [ ] `/dnd attack` - 攻击检定 ✅

### 技术验收

- [ ] 数据从5etools正确加载 ✅
- [ ] 掷骰逻辑正确（D20、伤害骰） ✅
- [ ] 属性调整值计算正确 ✅
- [ ] 消息格式美观、易读 ✅

---

## 📝 八、注意事项

1. **版权标注**: 使用5etools数据需注明来源
2. **网络依赖**: Demo版本需要网络连接加载数据
3. **错误处理**: 需完善异常处理机制
4. **性能优化**: 后续可添加本地缓存层

---

**实施状态**: 🔄 进行中  
**预计完成时间**: 今日（3-4小时）  
**下一步**: 开始实现数据加载器
