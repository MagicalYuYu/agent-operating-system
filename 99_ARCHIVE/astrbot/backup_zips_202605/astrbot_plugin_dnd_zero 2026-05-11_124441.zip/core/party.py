"""
冒险小队系统模块 - 管理组队逻辑
"""
import uuid
from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional
from datetime import datetime


@dataclass
class PartyMember:
    """小队成员"""
    player_id: str
    player_name: str
    role: str = "member"
    joined_at: str = ""


@dataclass
class Party:
    """冒险小队"""
    party_id: str
    party_name: str
    leader_id: str
    members: List[PartyMember] = field(default_factory=list)
    created_at: str = ""
    max_members: int = 4


class PartySystem:
    """冒险小队系统"""

    def __init__(self):
        self.parties: Dict[str, Party] = {}
        self.player_party_map: Dict[str, str] = {}
        self.pending_invitations: Dict[str, List[Dict[str, Any]]] = {}

    def create_party(self, leader_id: str, leader_name: str, party_name: Optional[str] = None) -> Dict[str, Any]:
        """创建冒险小队

        Args:
            leader_id: 队长 ID
            leader_name: 队长名称
            party_name: 小队名称（可选）

        Returns:
            创建结果
        """
        if leader_id in self.player_party_map:
            existing_party_id = self.player_party_map[leader_id]
            if existing_party_id in self.parties:
                return {
                    "success": False,
                    "message": "你已经在一个小队中了，无法创建新小队"
                }

        party_id = str(uuid.uuid4())[:8].upper()
        party_name = party_name or f"小队 #{party_id}"

        party = Party(
            party_id=party_id,
            party_name=party_name,
            leader_id=leader_id,
            members=[
                PartyMember(
                    player_id=leader_id,
                    player_name=leader_name,
                    role="leader",
                    joined_at=datetime.now().strftime("%Y-%m-%d %H:%M")
                )
            ],
            created_at=datetime.now().strftime("%Y-%m-%d %H:%M")
        )

        self.parties[party_id] = party
        self.player_party_map[leader_id] = party_id

        return {
            "success": True,
            "message": f"🎉 冒险小队「{party_name}」创建成功！",
            "party_id": party_id,
            "party_name": party_name
        }

    def invite_player(self, party_id: str, inviter_id: str, target_id: str, target_name: str) -> Dict[str, Any]:
        """邀请玩家加入小队

        Args:
            party_id: 小队 ID
            inviter_id: 邀请者 ID
            target_id: 目标玩家 ID
            target_name: 目标玩家名称

        Returns:
            邀请结果
        """
        party = self.parties.get(party_id)
        if not party:
            return {
                "success": False,
                "message": "小队不存在"
            }

        if party.leader_id != inviter_id:
            return {
                "success": False,
                "message": "只有队长可以邀请新成员"
            }

        if len(party.members) >= party.max_members:
            return {
                "success": False,
                "message": f"小队已满员（{party.max_members}/{party.max_members}）"
            }

        if target_id in self.player_party_map:
            return {
                "success": False,
                "message": f"{target_name} 已经在另一个小队中了"
            }

        if target_id not in self.pending_invitations:
            self.pending_invitations[target_id] = []

        invitation = {
            "party_id": party_id,
            "party_name": party.party_name,
            "inviter_id": inviter_id,
            "target_id": target_id,
            "target_name": target_name,
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M")
        }

        self.pending_invitations[target_id].append(invitation)

        return {
            "success": True,
            "message": f"已向 {target_name} 发送入队邀请！\n等待对方接受..."
        }

    def accept_invitation(self, player_id: str, player_name: str) -> Dict[str, Any]:
        """接受邀请加入小队

        Args:
            player_id: 玩家 ID
            player_name: 玩家名称

        Returns:
            加入结果
        """
        invitations = self.pending_invitations.get(player_id, [])
        if not invitations:
            return {
                "success": False,
                "message": "没有待处理的邀请"
            }

        invitation = invitations[-1]
        party_id = invitation["party_id"]
        party = self.parties.get(party_id)

        if not party:
            return {
                "success": False,
                "message": "小队已解散"
            }

        if len(party.members) >= party.max_members:
            return {
                "success": False,
                "message": "小队已满员"
            }

        member = PartyMember(
            player_id=player_id,
            player_name=player_name,
            role="member",
            joined_at=datetime.now().strftime("%Y-%m-%d %H:%M")
        )
        party.members.append(member)
        self.player_party_map[player_id] = party_id

        self.pending_invitations[player_id] = []

        return {
            "success": True,
            "message": f"🎉 成功加入「{party.party_name}」！\n\n你现在的队友：\n" + "\n".join([f"• {m.player_name}（{m.role}）" for m in party.members]),
            "party": self._party_to_dict(party)
        }

    def leave_party(self, player_id: str) -> Dict[str, Any]:
        """离开小队

        Args:
            player_id: 玩家 ID

        Returns:
            离开结果
        """
        party_id = self.player_party_map.get(player_id)
        if not party_id:
            return {
                "success": False,
                "message": "你不在任何小队中"
            }

        party = self.parties.get(party_id)
        if not party:
            del self.player_party_map[player_id]
            return {
                "success": False,
                "message": "小队已解散"
            }

        if party.leader_id == player_id:
            if len(party.members) > 1:
                new_leader = party.members[1]
                party.leader_id = new_leader.player_id
                new_leader.role = "leader"
                party.members.remove(party.members[0])
            else:
                del self.parties[party_id]

            del self.player_party_map[player_id]

            if party_id in self.parties:
                return {
                    "success": True,
                    "message": "你已离开小队，队长已移交给其他成员"
                }
            else:
                return {
                    "success": True,
                    "message": "小队已解散"
                }
        else:
            for member in party.members:
                if member.player_id == player_id:
                    party.members.remove(member)
                    break

            del self.player_party_map[player_id]

            return {
                "success": True,
                "message": "你已离开小队"
            }

    def get_party_status(self, player_id: str) -> Dict[str, Any]:
        """获取小队状态

        Args:
            player_id: 玩家 ID

        Returns:
            小队状态
        """
        party_id = self.player_party_map.get(player_id)
        if not party_id:
            return {
                "in_party": False,
                "message": "你不在任何小队中"
            }

        party = self.parties.get(party_id)
        if not party:
            del self.player_party_map[player_id]
            return {
                "in_party": False,
                "message": "小队已解散"
            }

        return {
            "in_party": True,
            "party": self._party_to_dict(party)
        }

    def get_party_menu(self) -> str:
        """获取冒险小队菜单"""
        return f"""
{'='*60}
              👥 冒险小队
{'='*60}

在 D&D 的世界里，冒险者们通常以小队的形式
踏上征程。一个人能走很快，但一个团队能走很远...

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  • /dnd 冒险小队 创建 - 创建新的冒险小队
  • /dnd 冒险小队 邀请 <玩家> - 邀请玩家加入
  • /dnd 冒险小队 接受 - 接受入队邀请
  • /dnd 冒险小队 离开 - 离开当前小队
  • /dnd 冒险小队 状态 - 查看小队状态

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

💡 冒险小队最多容纳 4 名成员
   队长可以邀请其他冒险者加入
"""

    def _party_to_dict(self, party: Party) -> Dict[str, Any]:
        """将 Party 对象转换为字典"""
        return {
            "party_id": party.party_id,
            "party_name": party.party_name,
            "leader_id": party.leader_id,
            "members": [
                {
                    "player_id": m.player_id,
                    "player_name": m.player_name,
                    "role": m.role,
                    "joined_at": m.joined_at
                }
                for m in party.members
            ],
            "member_count": len(party.members),
            "max_members": party.max_members,
            "created_at": party.created_at
        }

    def format_party_info(self, party_data: Dict[str, Any]) -> str:
        """格式化小队信息显示"""
        party_name = party_data.get("party_name", "未知小队")
        members = party_data.get("members", [])
        member_count = party_data.get("member_count", 0)
        max_members = party_data.get("max_members", 4)

        member_lines = []
        for member in members:
            role_emoji = "👑" if member.get("role") == "leader" else "⚔️"
            member_lines.append(f"  {role_emoji} {member.get('player_name', '未知')}（{member.get('role', 'member')}）")

        members_text = "\n".join(member_lines) if member_lines else "  暂无成员"

        return f"""
{'='*60}
              👥 {party_name}
{'='*60}

成员列表（{member_count}/{max_members}）：

{members_text}

{'='*60}

💡 发送 /dnd 冒险小队 邀请 <玩家> 邀请新成员
   发送 /dnd 冒险小队 离开 离开当前小队
"""
