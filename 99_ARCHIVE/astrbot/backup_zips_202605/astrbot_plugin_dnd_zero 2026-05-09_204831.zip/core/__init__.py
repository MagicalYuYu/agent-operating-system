"""
D&D 5e TRPG 核心模块
"""
from .dice import DiceRoller, DiceRollResult, D20RollResult, AbilityCalculator, AdvantageType
from .character import (
    Character, CharacterClass, CharacterRace, CharacterBackground,
    AbilityScores, Ability, Skills, Equipment, CharacterFactory
)
from .skill import SkillChecker, SkillCheckResult, SavingThrowResult, AttackResult
from .combat import CombatSystem, CombatResult, DamageResult, CombatEncounter, CombatAction
from .spell import (
    Spell, Spellcasting, SpellSlot, SpellDatabase, SpellCaster,
    SpellLevel, SpellSchool, CastingTime, SpellRange, SpellDuration
)

__all__ = [
    'DiceRoller',
    'DiceRollResult',
    'D20RollResult',
    'AbilityCalculator',
    'AdvantageType',
    'Character',
    'CharacterClass',
    'CharacterRace',
    'CharacterBackground',
    'AbilityScores',
    'Ability',
    'Skills',
    'Equipment',
    'CharacterFactory',
    'SkillChecker',
    'SkillCheckResult',
    'SavingThrowResult',
    'AttackResult',
    'CombatSystem',
    'CombatResult',
    'DamageResult',
    'CombatEncounter',
    'CombatAction',
    'Spell',
    'Spellcasting',
    'SpellSlot',
    'SpellDatabase',
    'SpellCaster',
    'SpellLevel',
    'SpellSchool',
    'CastingTime',
    'SpellRange',
    'SpellDuration'
]
