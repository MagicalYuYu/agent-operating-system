"""
D&D 5e TRPG 核心模块
"""
from .dice import DiceRoller, DiceRollResult, D20RollResult, AbilityCalculator, AdvantageType
from .character import (
    Character, CharacterClass, CharacterRace, CharacterBackground,
    AbilityScores, Ability, Skills, Equipment, CharacterFactory
)
from .skill import SkillChecker, SkillCheckResult, SavingThrowResult, AttackResult
from .combat import CombatSystem, CombatResult, DamageResult, CombatEncounter, CombatAction
from .combat_position import (
    PositionManager, AttackRange, ActionType, ConditionType,
    MELEE_RANGE, RANGED_RANGE, PIERCE_RANGE
)
from .combat_unit import (
    CombatUnit, PlayerUnit, MonsterUnit,
    MONSTER_TEMPLATES, create_monster
)
from .combat_skill import (
    Skill, SkillDatabase, SKILL_TEMPLATES
)
from .combat_manager import (
    CombatManager, CombatActionResult,
    AttackResult as CombatAttackResult, DamageResult as CombatDamageResult
)
from .combat_integration import (
    CombatAdapter, MonsterCombatIntegration, SkillCombatIntegration,
    SpellCombatIntegration, ItemCombatIntegration
)
from .battle_arena import (
    BattleArena, BattleArenaMonster, Difficulty,
    WATERDEEP_ARENA_MONSTERS, ARENA_INSTANCE
)
from .spell import (
    Spell, Spellcasting, SpellSlot, SpellDatabase, SpellCaster,
    SpellLevel, SpellSchool, CastingTime, SpellRange, SpellDuration
)
from .classes import ClassDatabase, DNDClass
from .races import RaceDatabase, DNRace, Subrace
from .backgrounds import BackgroundDatabase, Background
from .character_creator import CharacterCreator, CharacterCreationState, CreationStep, PointBuyCalculator
from .town import TownSystem, TownLocation, TownData
from .npc import NPCDatabase, NPC, NPCDialogue
from .menu import MenuSystem
from .daily import DailySystem, DailyReward
from .backpack import BackpackSystem, BackpackItem
from .shop import ShopSystem, ShopDatabase, ShopItem, ShopCategory
from .party import PartySystem, Party, PartyMember

__all__ = [
    # 骰子系统
    'DiceRoller',
    'DiceRollResult',
    'D20RollResult',
    'AbilityCalculator',
    'AdvantageType',

    # 角色系统
    'Character',
    'CharacterClass',
    'CharacterRace',
    'CharacterBackground',
    'AbilityScores',
    'Ability',
    'Skills',
    'Equipment',
    'CharacterFactory',

    # 技能检定
    'SkillChecker',
    'SkillCheckResult',
    'SavingThrowResult',
    'AttackResult',

    # 旧战斗系统（兼容）
    'CombatSystem',
    'CombatResult',
    'DamageResult',
    'CombatEncounter',
    'CombatAction',

    # 新战斗系统 - 位置与范围
    'PositionManager',
    'AttackRange',
    'ActionType',
    'ConditionType',
    'MELEE_RANGE',
    'RANGED_RANGE',
    'PIERCE_RANGE',

    # 新战斗系统 - 单位
    'CombatUnit',
    'PlayerUnit',
    'MonsterUnit',
    'MONSTER_TEMPLATES',
    'create_monster',

    # 新战斗系统 - 技能
    'Skill',
    'SkillDatabase',
    'SKILL_TEMPLATES',

    # 新战斗系统 - 管理器
    'CombatManager',
    'CombatActionResult',

    # 新战斗系统 - 集成
    'CombatAdapter',
    'MonsterCombatIntegration',
    'SkillCombatIntegration',
    'SpellCombatIntegration',
    'ItemCombatIntegration',

    # 战斗训练场
    'BattleArena',
    'BattleArenaMonster',
    'Difficulty',
    'WATERDEEP_ARENA_MONSTERS',
    'ARENA_INSTANCE',

    # 法术系统
    'Spell',
    'Spellcasting',
    'SpellSlot',
    'SpellDatabase',
    'SpellCaster',
    'SpellLevel',
    'SpellSchool',
    'CastingTime',
    'SpellRange',
    'SpellDuration',

    # 职业种族背景
    'ClassDatabase',
    'DNDClass',
    'RaceDatabase',
    'DNRace',
    'Subrace',
    'BackgroundDatabase',
    'Background',

    # 角色创建
    'CharacterCreator',
    'CharacterCreationState',
    'CreationStep',
    'PointBuyCalculator',

    # 城镇系统
    'TownSystem',
    'TownLocation',
    'TownData',
    'NPCDatabase',
    'NPC',
    'NPCDialogue',
    'MenuSystem',
    'DailySystem',
    'DailyReward',

    #背包商店
    'BackpackSystem',
    'BackpackItem',
    'ShopSystem',
    'ShopDatabase',
    'ShopItem',
    'ShopCategory',

    # 队伍系统
    'PartySystem',
    'Party',
    'PartyMember'
]
